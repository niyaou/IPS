--�ļ�ϵͳ��Ϣ
DROP TABLE IF EXISTS file_storage_information;
CREATE TABLE IF NOT EXISTS file_storage_information(
filename varchar(255)  not null,
filepath varchar(255) not null,
date timestamp,
filesize double,
filetype varchar(255),
fileformat varchar(255),
owner varchar(255),
group varchar(255),
target varchar(255),
thumbs int,
primary key (filename,filepath)
);
