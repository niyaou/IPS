package com.desay.pangoo.filesystem;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.pangoo.filesystem.feign.AuthRequest;

import feign.Feign;

@RunWith(SpringRunner.class)
@SpringBootTest
public class FeiginTest {
    @Autowired
    AuthRequest authRequest;

    @Test
    public void date(){
//        AuthRequest authRequest = Feign.builder()
//                .target(AuthRequest.class, "http://PANGOO-USER/");
//        ResponseDTO<TokenDTO> token = authRequest.tokenAuthorize("");
    }
}
