package com.desay.pangoo.filesystem.controller;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.bytedeco.javacv.FFmpegFrameGrabber;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.desay.cd.common.hdfs.HdfsUtils;
import com.desay.cd.utils.DateUtil;
import com.desay.cd.utils.RespUtil;
import com.desay.pangoo.filesystem.service.FileStorageService;
import com.desay.pangoo.filesystem.threadpool.FixedThreadPoolUtil;
import com.desay.pangoo.filesystem.threadpool.PoolTask;
import com.desay.pangoo.filesystem.utils.FileUtil;
import com.desay.pangoo.filesystem.utils.IDGenerator;
import com.desay.pangoo.filesystem.utils.VideoImage;
import com.google.gson.Gson;

import io.netty.util.concurrent.Future;
import net.coobird.thumbnailator.Thumbnailator;

/**
 * 附件上传
 */
@Controller
@RequestMapping("fileupload/")
public class FileULoadController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());


	@Autowired
	FileStorageService fileserver;
	
	@Resource(name = "asyncServiceExecutor")
	private ThreadPoolTaskExecutor executor;

	@RequestMapping(value = "/async", method = RequestMethod.GET)
	public String async(){
		//使用Future方式执行多任务
        //生成一个集合


        for (int i =0 ;i<1000; i++) {
            //并发处理
              executor.execute(new Runnable() {
				
				@Override
				public void run() {
					System.out.println(Thread.currentThread());
					
				}
			});
            }
        return "200";
        }

	/**
	 * 上传文件
	 **/
	@RequestMapping(value = "/fileupload", method = RequestMethod.POST)
	public void uploadFile(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model) {
		Map<String, Object> result = new HashMap<>();
		String dailyFileDirName = StringUtils.EMPTY;
		String user = (String) request.getSession().getAttribute("LOGIN");
		String market = request.getParameter("market");
		String group = (String) request.getSession().getAttribute("MEMBEROF");
		logger.info(market);
		try {
			dailyFileDirName = DateUtil.getDate(new Date()) + "/";
		} catch (ParseException e1) {
			logger.error(e1.getMessage() + "\n错误解析索引:" + e1.getErrorOffset());
		}
		// 文件保存路径
		String savePath = request.getServletContext().getRealPath("/html/uploadFile/" + dailyFileDirName);

		try {
			Iterator<String> names = request.getFileNames();
			while (names.hasNext()) {
				String fileName = names.next();
				MultipartFile part = request.getFile(fileName);
				String mimetype = request.getServletContext().getMimeType( part.getOriginalFilename());
				String taskId;
				String oriFileName = part.getOriginalFilename();
				taskId = writeToHdfs(part.getInputStream(), savePath, oriFileName, user, market, group,mimetype,part.getSize());
				if (taskId != null) {
					result.put("taskId", taskId);
				}
			}
		} catch (Exception e) {
			model.put("errorMsg", e.getMessage());
		}
		logger.info("发送数据" + (new Gson()).toJson(result));
		RespUtil.returnResult(request, response, result);
	}
	
	
	/**
	 * 上传文件
	 **/
	@RequestMapping(value = "/fileuploadBroken", method = RequestMethod.POST)
	public void uploadFileBroken(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model) {
		Map<String, Object> result = new HashMap<>();
		String dailyFileDirName = StringUtils.EMPTY;
		String market = request.getParameter("market");
		String chunk = request.getParameter("chunk");
		String chunks = request.getParameter("chunks");
		String name = request.getParameter("name");
		try {
			dailyFileDirName = DateUtil.getDate(new Date()) + "/";
		} catch (ParseException e1) {
			logger.error(e1.getMessage() + "\n错误解析索引:" + e1.getErrorOffset());
		}
		
		// 文件保存路径
		String savePath = request.getServletContext().getRealPath("/html/uploadFile/" + dailyFileDirName);

		try {
			Iterator<String> names = request.getFileNames();
			while (names.hasNext()) {
				String fileName = names.next();
				MultipartFile part = request.getFile(fileName);
				String mimetype = request.getServletContext().getMimeType( part.getOriginalFilename());
				String taskId;
				String oriFileName = part.getOriginalFilename();
				logger.info("断点续传发送数据--------" +fileName+"     chunk: "+chunk+"     chunks: "+chunks+"     name: "+name);
				String write=writeFileSyn(part, FileUtil.currentWorkDir,(name+chunk+"_chuck.part"));
				result.put("write", write);
//				taskId = writeToHdfs(part.getInputStream(), savePath, oriFileName, user, market, group,mimetype,part.getSize());
//				if (taskId != null) {
//					result.put("taskId", taskId);
//				}

//                  if(Integer.parseInt(chunks)-Integer.parseInt(chunk)==1) {
//      				
//     				 FileUtil fileUtil = new FileUtil();
//     				 	int blockFileSize=1024 * 1024 * 10;
//                	// 合并成新文件
//  			        fileUtil.mergePartFiles(FileUtil.currentWorkDir, ".part",
//  			                blockFileSize, FileUtil.currentWorkDir + name);
//                  }
			        
			}
		} catch (Exception e) {
			model.put("errorMsg", e.getMessage());
		}
//		logger.info("发送数据" + (new Gson()).toJson(result));
		RespUtil.returnResult(request, response, result);
	}

	private String genUidName(String originalName) {
		int idx = originalName.lastIndexOf(".");
		// 文件后缀
		String extention = "";
		if (idx > 0) {
			extention = originalName.substring(idx);
		}
		String namePrefix = originalName.substring(0, idx);
		String uid = IDGenerator.getInstance().GenUUID();
		return namePrefix + uid + extention;
	}

	/**
	 * 保存上传的图片
	 *
	 * @param part
	 * @param savePath
	 * @return
	 * @throws IOException
	 */
	private String writeFileSyn(MultipartFile part, String savePath, String fileName) {
		System.out.println(Thread.currentThread());
//		int size = (int) part.getSize();
//		InputStream iStream;
//		try {
//			iStream = part.getInputStream();
//		} catch (IOException e) {
//			e.printStackTrace();
//			return null;
//		}
//		File fileDir = new File(savePath);
//		if (!fileDir.exists()) {
//			fileDir.mkdirs();
//		}
//		File file = new File(savePath + File.separator + fileName);
//		if (!file.exists()) {
//			try {
//				boolean r = file.createNewFile();
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//		FileOutputStream out;
//		try {
//			out = new FileOutputStream(file);
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//			return null;
//		}
//		int c;
//		byte buffer[] = new byte[size];
//		try {
//			while ((c = iStream.read(buffer)) != -1) {
//				for (int i = 0; i < c; i++)
//					out.write(buffer[i]);
//			}
//			out.close();
//		} catch (Exception e) {
//			logger.debug(e.getMessage());
////			return null;
//		}
//		return savePath + fileName;
		
		
//	}
		
		
		
		
		
		
//        executor.execute(new Runnable() {
//			
//			@Override
//			public void run() {
//				System.out.println(Thread.currentThread());
//				int size = (int) part.getSize();
//				InputStream iStream;
//				try {
//					iStream = part.getInputStream();
//				} catch (IOException e) {
//					e.printStackTrace();
//					return ;
//				}
//				File fileDir = new File(savePath);
//				if (!fileDir.exists()) {
//					fileDir.mkdirs();
//				}
//				File file = new File(savePath + File.separator + fileName);
//				if (!file.exists()) {
//					try {
//						boolean r = file.createNewFile();
//					} catch (IOException e) {
//						e.printStackTrace();
//					}
//				}
//				FileOutputStream out;
//				try {
//					out = new FileOutputStream(file);
//				} catch (FileNotFoundException e) {
//					e.printStackTrace();
//					return ;
//				}
//				int c;
//				byte buffer[] = new byte[size];
//				try {
//					while ((c = iStream.read(buffer)) != -1) {
//						for (int i = 0; i < c; i++)
//							out.write(buffer[i]);
//					}
//					out.close();
//				} catch (Exception e) {
//					logger.debug(e.getMessage());
////					return null;
//				}
////				return savePath + fileName;
//				
//				
//			}
//		});
//        return "";
        
		PoolTask pt = new PoolTask() {

			@Override
			public void runSubTask() {
	     	System.out.println(Thread.currentThread());
				int size = (int) part.getSize();
				InputStream iStream;
				try {
					iStream = part.getInputStream();
				} catch (IOException e) {
					e.printStackTrace();
					return ;
				}
				File fileDir = new File(savePath);
				if (!fileDir.exists()) {
					fileDir.mkdirs();
				}
				File file = new File(savePath + File.separator + fileName);
				if (!file.exists()) {
					try {
						boolean r = file.createNewFile();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				FileOutputStream out;
				try {
					out = new FileOutputStream(file);
				} catch (FileNotFoundException e) {
					e.printStackTrace();
					return ;
				}
				int c;
				byte buffer[] = new byte[size];
				try {
					while ((c = iStream.read(buffer)) != -1) {
						for (int i = 0; i < c; i++)
							out.write(buffer[i]);
					}
					out.close();
				} catch (Exception e) {
					logger.debug(e.getMessage());
					return ;
				}
				return ;
				
			 }
			};
			String taskId = FixedThreadPoolUtil.getInstance().submitTask(pt);

			return taskId;
	}

	


	public ByteArrayOutputStream saveThumbls(String name) {
		File file;
		try {
			file = ResourceUtils.getFile(name);
			 InputStream targetStream = 
				        new DataInputStream(new FileInputStream(file));
			BufferedInputStream audio = new BufferedInputStream(targetStream);
			BufferedImage buff=ImageIO.read(audio) ;
			BufferedImage out=Thumbnailator.createThumbnail(buff, 100,100);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write(out, "png", baos);
			return baos;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
		  
	}
	
	private String writeToHdfs(InputStream stream, final String savePath, String fileName, String username, String market, String userGroup,String mimetype,long size) {
		String hdfsDir = "/test/upload/";
		String hdfsPath = "/test/upload/" + fileName;

		PoolTask pt = new PoolTask() {
			@Override
			public void runSubTask() {
				HdfsUtils u = new HdfsUtils();
				try {
					BufferedInputStream zipTest = new BufferedInputStream(stream);
					zipTest.mark(0);
					if(mimetype.contains("video")) {
						FFmpegFrameGrabber ff = new FFmpegFrameGrabber(zipTest);
						ByteArrayOutputStream f = VideoImage.getFrame(ff, 50, "test2.png");
						if (f != null) {
							fileserver.saveThumbls(hdfsDir, fileName, username, market, userGroup, f,mimetype,size);
						}
						zipTest.reset();
					}else if(mimetype.contains("image")){
						BufferedImage buff=ImageIO.read(stream) ;
						BufferedImage out=Thumbnailator.createThumbnail(buff, 100,100);
						ByteArrayOutputStream baos = new ByteArrayOutputStream();
						ImageIO.write(out, "png", baos);
						fileserver.saveThumbls(hdfsDir, fileName, username, market, userGroup,baos,mimetype,size);
						baos.close();
						ByteArrayOutputStream orign = new ByteArrayOutputStream();
						ImageIO.write(buff, "png", orign);
						zipTest =new BufferedInputStream( new ByteArrayInputStream(orign.toByteArray()));
					}else if(mimetype.contains("audio")){
						fileserver.saveThumbls(hdfsDir, fileName, username, market, userGroup,saveThumbls("classpath:static/img/audio.png"),mimetype,size);
					}else if(mimetype.contains("text")){
						fileserver.saveThumbls(hdfsDir, fileName, username, market, userGroup,saveThumbls("classpath:static/img/text.png"),mimetype,size);
					}else if(mimetype.contains("application")){
						fileserver.saveThumbls(hdfsDir, fileName, username, market, userGroup,saveThumbls("classpath:static/img/application.png"),mimetype,size);
					}else {
						fileserver.saveDocuments(hdfsDir, fileName, username, market, userGroup, mimetype, size);
					}
					u.uploadFile(zipTest, hdfsPath);
					zipTest.close();
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		};
		String taskId = FixedThreadPoolUtil.getInstance().submitTask(pt);

		logger.info("上传文件到hdfs,路径:" + hdfsPath);
		return taskId;
	}

	/**
	 * 保存上传的文件
	 *
	 * @param part
	 * @param savePath
	 * @return 任务id
	 * @throws IOException
	 */
	private String writeFileAsync(MultipartFile part, final String savePath, String fileName) throws IOException {
		final int size = (int) part.getSize();
		final InputStream iStream = part.getInputStream();
		PoolTask pt = new PoolTask() {
			@Override
			public void runSubTask() {
				try {
					File fileDir = new File(savePath);
					if (!fileDir.exists())
						fileDir.mkdirs();
					File file = new File(savePath + File.separator + fileName);
					if (!file.exists())
						file.createNewFile();
					FileOutputStream out = new FileOutputStream(file);
					int c;
					byte buffer[] = new byte[size];
					while ((c = iStream.read(buffer)) != -1) {
						for (int i = 0; i < c; i++)
							out.write(buffer[i]);
					}
					out.close();
				} catch (Exception e) {
					logger.info(e.getMessage());
				}
			}
		};
		String taskId = FixedThreadPoolUtil.getInstance().submitTask(pt);
		logger.info(savePath + File.separator + fileName);
		return taskId;
	}

}
