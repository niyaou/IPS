package com.desay.pangoo.filesystem.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/cp")
public class CommonPartials {

	@RequestMapping("/content")
	public String mainZb(HttpServletRequest request, ModelMap ModelMap) {
		return ("/partials/center");
	}

}
