package com.desay.pangoo.filesystem.websocket;

import java.io.IOException;

public class VideoPushUser {
    private PushProgressSocket[] sockets;

    public PushProgressSocket[] getSockets() {
        return sockets;
    }

    public void setSockets(PushProgressSocket[] sockets) {
        this.sockets = sockets;
    }

    public void sendMessage(String msg){
        for (PushProgressSocket b :sockets){
            try {
                b.sendMessage(msg);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
