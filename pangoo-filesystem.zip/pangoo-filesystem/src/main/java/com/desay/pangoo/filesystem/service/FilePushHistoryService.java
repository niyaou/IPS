package com.desay.pangoo.filesystem.service;

import com.desay.pangoo.filesystem.entity.FilePushHistory;

import java.util.List;

public interface FilePushHistoryService {
    int savePushHistory(FilePushHistory f);

    List<FilePushHistory> queryByUserId(String userId);

    int updatePushHistory(FilePushHistory f);
}
