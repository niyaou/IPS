package com.desay.pangoo.filesystem.controller;

import com.desay.cd.common.file.FilePushUtils;
import com.desay.cd.common.hdfs.HdfsUtils;
import com.desay.pangoo.filesystem.entity.FilePushHistory;
import com.desay.pangoo.filesystem.entity.FileStorageInformation;
import com.desay.pangoo.filesystem.service.FilePushHistoryService;
import com.desay.pangoo.filesystem.service.FileStorageService;
import com.desay.pangoo.filesystem.utils.Validator;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Controller
@RequestMapping("/video")
public class VideoController {
    private static Logger logger = LoggerFactory.getLogger(VideoController.class);
    private static final Pattern RANGE_PATTERN = Pattern.compile("bytes=(?<start>\\d*)-(?<end>\\d*)");
    private final FileStorageService fileserver;
    private final FilePushHistoryService filePushService;

    @Autowired
    public VideoController(FileStorageService fileserver, FilePushHistoryService filePushService) {
        this.fileserver = fileserver;
        this.filePushService = filePushService;
    }

    @RequestMapping(value = "/search")
    public ModelAndView search(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
        return new ModelAndView("video/search");
    }
    
    @RequestMapping(value = "/explore")
    public ModelAndView explore(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
        return new ModelAndView("video/explore");
    }


    @RequestMapping(value = "/query")
    @ResponseBody
    public ModelAndView query(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
        String market = request.getParameter("market");
        logger.info("标签" + market);
        List a = fileserver.queryByMarket(market);
        model.put("listData", a);
        return new ModelAndView("video/videolist");
    }
    

    @RequestMapping(value = "/formatquery")
    @ResponseBody
    public ModelAndView formatQuery(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
        String format = request.getParameter("format");
        logger.info("标签" + format);
        List a = fileserver.queryByFileFormat(format);
        model.put("listData", a);
        return new ModelAndView("video/videoexplore");
    }

    @RequestMapping(value = "/pushStream")
    @ResponseBody
    public int pushStream(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
        FilePushHistory f = new FilePushHistory();
        Object username = request.getSession().getAttribute("LOGIN");
        f.setUserId((String)username);
        String path = request.getParameter("filePath");
        f.setPushTime(new Timestamp(System.currentTimeMillis()));
        f.setPushFileHdfsPath(path);
        ArrayList<String> a = new ArrayList<>();
        a.add(path);
        List<String> serverPath = FilePushUtils.pushHdfs2Server(a);
        f.setPushFileServerPath(serverPath.get(0));
        filePushService.savePushHistory(f);
        return 1;
    }

    @RequestMapping(value = "/pushStreamView")
    public ModelAndView pushStreamView(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
        return new ModelAndView("video/pushstream");
    }

    @RequestMapping(value = "/uploadstream")
    public ModelAndView uploadStream(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
        return new ModelAndView("video/uploadprogress");
    }

    @RequestMapping(value = "/usermanage")
    public ModelAndView groupManage(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
        return new ModelAndView("video/usermanage");
    }

    @RequestMapping(value = "/updatefile")
    @ResponseBody
    public int updateFile(HttpServletRequest request, HttpServletResponse response) {
        FileStorageInformation f = new FileStorageInformation();
        String filename = request.getParameter("filename");
        String filepath = request.getParameter("filepath");
        String usergroup = request.getParameter("usergroup");
        String market = request.getParameter("market");
        f.setFilename(filename);
        f.setFilepath(filepath);
        f.setUsergroup(usergroup);
        f.setTarget(market);
        return fileserver.updateFile(f);
    }


    @RequestMapping(value = "/index")
    public ModelAndView index(@RequestParam(value = "path") String path, @RequestParam(value = "name") String name,
                              HttpServletRequest request, HttpServletResponse response, ModelMap model) {
        model.put("videoPath", path);
        model.put("videoName", name);
        return new ModelAndView("video/videoplay");
    }

    @RequestMapping(value = "/play")
    public void play1(@RequestParam(value = "path") String path, @RequestParam(value = "name") String name,
                      HttpServletRequest request, HttpServletResponse response, ModelMap model) {
        HdfsUtils u = new HdfsUtils();
        FileSystem fs = u.getFileSystem();
        int fileLength;
        String pathUrl;
        String videoFileName = "Rec 00012820f5ec-dbd0-41aa-84c1-c41a0f914146.mp4";
        if (Validator.getInstance().notEmpty(path) && Validator.getInstance().notEmpty(name)) {
            pathUrl = path + name;
            videoFileName = name;
        } else {
            pathUrl = "/test/upload/" + videoFileName;
        }
        logger.info(pathUrl);
        org.apache.hadoop.fs.Path p = new org.apache.hadoop.fs.Path(pathUrl);
        try {
            fileLength = (int) fs.getContentSummary(p).getLength();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
        int start = 0;
        int end = fileLength - 1;
        String range = request.getHeader("Range");
        range = range == null ? "" : range;
        Matcher matcher = RANGE_PATTERN.matcher(range);
        if (matcher.matches()) {
            String startGroup = matcher.group("start");
            start = startGroup.isEmpty() ? start : Integer.valueOf(startGroup);
            start = start < 0 ? 0 : start;
            String endGroup = matcher.group("end");
            end = endGroup.isEmpty() ? end : Integer.valueOf(endGroup);
            end = end > fileLength - 1 ? fileLength - 1 : end;
        }
        int contentLength = end - start + 1;
        response.setHeader("Content-Disposition", String.format("inline;filename=\"%s\"", videoFileName));
        response.setHeader("Content-Range", String.format("bytes %s-%s/%s", start, end, fileLength));
        response.setHeader("Content-Length", String.format("%s", contentLength));
        response.setHeader("Content-type", "video/mp4");
        response.setStatus(HttpServletResponse.SC_PARTIAL_CONTENT);
        try {
            FSDataInputStream in = fs.open(p);
            in.seek(start);
            OutputStream output = response.getOutputStream();
            IOUtils.copyBytes(in, output, contentLength, false);
            in.close();
            output.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
