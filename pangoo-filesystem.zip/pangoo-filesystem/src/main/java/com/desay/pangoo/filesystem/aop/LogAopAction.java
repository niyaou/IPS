package com.desay.pangoo.filesystem.aop;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.desay.cd.utils.DateUtil;
import com.desay.pangoo.filesystem.annotation.LogAnnotation;
import com.desay.pangoo.filesystem.entity.Log;
import com.desay.pangoo.filesystem.utils.LoggerUtil;

@Aspect
@Component
public class LogAopAction {
	private final Logger logger = LoggerFactory.getLogger("optlogger");

	@Pointcut("execution(public * com.desay.pangoo.filesystem.controller..*(..))")
	private void pointCutMethod() {
	}

	/**
	 * 记录操作日志
	 */
	@After("pointCutMethod()") // 使用上面定义的切入点
	public void recordLog(JoinPoint joinPoint) {
		Long start = System.currentTimeMillis();
		Log log = new Log();
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
				.getRequest();
		// 下面开始获取 ip，targetType，remark，action
		// 请求的参数
		String param = getParam(joinPoint);
		// 请求的参数
		String methodName = (joinPoint.getTarget().getClass().getName() + "." + joinPoint.getSignature().getName()
				+ "()");
		try {
			Map<String, String> map = getLogMark(joinPoint);
			log.setAction(map.get(LoggerUtil.LOG_ACTION));
			log.setTargetType(map.get(LoggerUtil.LOG_TARGET_TYPE));
			log.setRemark(map.get(LoggerUtil.LOG_REMARK));
			log.setIp(LoggerUtil.getCliectIp(request));
			log.setUser((String) request.getSession().getAttribute("LOGIN"));
			log.setUrl(request.getRequestURI());
			log.setMethodName(methodName);
			log.setParam(param);
			log.setCreateTime(new Date());
			logger.trace(JSON.toJSONStringWithDateFormat(log, DateUtil.FORMAT_DATE_TIME,
					SerializerFeature.WriteMapNullValue));
		} catch (ClassNotFoundException c) {
			logger.error(c.getMessage());
		} catch (Exception e) {
			logger.error("插入日志异常", e.getMessage());
		}
		Long end = System.currentTimeMillis();
		logger.info("记录日志消耗时间:" + (end - start) / 1000);
	}

	private Map<String, String> getLogMark(JoinPoint joinPoint) throws ClassNotFoundException {
		Map<String, String> map = new HashMap<>();
		String methodName = joinPoint.getSignature().getName();
		String targetName = joinPoint.getTarget().getClass().getName();
		Class targetClass = Class.forName(targetName);
		Method[] methods = targetClass.getMethods();
		for (Method method : methods) {
			if (method.getName().equals(methodName)) {
				LogAnnotation logAnnotation = method.getAnnotation(LogAnnotation.class);
				if (null != logAnnotation) {
					map.put(LoggerUtil.LOG_TARGET_TYPE, logAnnotation.targetType());
					map.put(LoggerUtil.LOG_ACTION, logAnnotation.action());
					map.put(LoggerUtil.LOG_REMARK, logAnnotation.remark());
				}
			}
		}
		return map;
	}

	/**
	 * 方法参数
	 * 
	 * @param joinPoint
	 * @return
	 */
	private String getParam(JoinPoint joinPoint) {
		StringBuilder params = new StringBuilder();
		if (joinPoint.getArgs() != null && joinPoint.getArgs().length > 0) {
			for (int i = 0; i < joinPoint.getArgs().length; i++) {
				params.append(joinPoint.getArgs()[i]).append(";");
			}
		}
		return params.toString();
	}

	// 操作类型，用于区分操作
	private static String getServiceMthodType(JoinPoint joinPoint) {
		String targetName = joinPoint.getTarget().getClass().getName();
		String methodName = joinPoint.getSignature().getName();
		Object[] arguments = joinPoint.getArgs();
		Class targetClass = null;
		try {
			targetClass = Class.forName(targetName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		assert targetClass != null;
		Method[] methods = targetClass.getMethods();
		String type = "b";
		for (Method method : methods) {
			if (method.getName().equals(methodName)) {
				Class[] clazzs = method.getParameterTypes();
				if (clazzs.length == arguments.length) {
					type = method.getAnnotation(LogAnnotation.class).targetType();
					break;
				}
			}
		}
		return type;
	}
}
