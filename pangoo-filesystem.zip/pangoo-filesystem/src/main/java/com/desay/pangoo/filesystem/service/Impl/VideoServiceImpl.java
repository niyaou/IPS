package com.desay.pangoo.filesystem.service.Impl;

import com.desay.pangoo.filesystem.entity.VideoFileEntity;
import com.desay.pangoo.filesystem.mapper.VideoMapper;
import com.desay.pangoo.filesystem.service.VideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Service
@Primary
public class VideoServiceImpl implements VideoService {
    private final VideoMapper mapper;

    @Autowired
    public VideoServiceImpl(VideoMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public List<VideoFileEntity> query(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
        return mapper.selectAll();
    }
}
