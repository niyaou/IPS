package com.desay.pangoo.filesystem.controller;

import com.desay.cd.common.hdfs.HdfsUtils;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

@Controller
@RequestMapping("/fileDownload")
public class FileDownloadController {
    private Logger logger = LoggerFactory.getLogger(FileDownloadController.class);

    @RequestMapping(value = "/download", method = RequestMethod.GET)
    @ResponseBody
    public  ResponseEntity<InputStreamResource> downloadFile(@RequestParam("fileName") String name, @RequestParam("filePath") String path, HttpServletRequest request, HttpServletResponse res) {
        String totalPath = path + name;
        HdfsUtils u = new HdfsUtils();
        FSDataInputStream inputStream;
        //            inputStream = u.getFileSystem().open(new Path(totalPath));
		inputStream = (FSDataInputStream) u.downloadFile(totalPath.trim());
		BufferedInputStream buff=new BufferedInputStream(inputStream);
        String encodeName;
        try {
            encodeName = java.net.URLEncoder.encode(name.trim(), "UTF8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null ;
        }
        String contentType = null;
 
        contentType = request.getServletContext().getMimeType(encodeName);
        if(contentType == null) {
            contentType = "application/octet-stream";
        }
        res.setContentType(contentType);
        res.setHeader("Content-disposition", "attachment; filename=\""+encodeName+"\"");
        logger.info("文件名:" + encodeName);
        logger.info("文件名:" + contentType);
      
        InputStreamResource resource = new InputStreamResource(buff);
        return  ResponseEntity.ok()
        .contentType(MediaType.parseMediaType(contentType))
        .header(HttpHeaders.CONTENT_DISPOSITION+"attachment; filename=\"" +encodeName + "\"")
        .body(resource);
        
//        byte[] buff = new byte[4096];
//        BufferedInputStream bis = null;
//        OutputStream os;
//        try {
//            os = res.getOutputStream();
//            bis = new BufferedInputStream(inputStream);
//            int readBytes;
//            while((readBytes = bis.read(buff)) != -1)  {
//               os.write(buff, 0, Math.min(readBytes, buff.length));
//            }
//            os.flush();
//            inputStream.close();
//            os.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//            return ;
//        } finally {
//            if (bis != null) {
//                try {
//                    bis.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
    }
}
