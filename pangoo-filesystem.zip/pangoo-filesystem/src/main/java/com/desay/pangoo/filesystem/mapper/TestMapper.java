package com.desay.pangoo.filesystem.mapper;

import java.util.List;

import com.desay.pangoo.filesystem.entity.Test;

import feign.Param;
import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.common.MySqlMapper;
import tk.mybatis.mapper.common.base.select.SelectMapper;

public interface TestMapper extends Mapper<Test>,MySqlMapper<Test>,SelectMapper<Test> {

	
//	List findByUserName(@org.apache.ibatis.annotations.Param("login")String login);
	
}
