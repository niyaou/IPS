package com.desay.pangoo.filesystem.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.desay.pangoo.filesystem.entity.FileStorageInformation;
import com.desay.pangoo.filesystem.entity.Test;
import com.desay.pangoo.filesystem.mapper.FileStorageMapper;
import com.desay.pangoo.filesystem.mapper.TestMapper;
import com.desay.pangoo.filesystem.service.TestService;

import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;

@Service
@Primary
public class TestServiceImpl implements TestService {

	@Autowired
	private TestMapper aMapper;
	
	@Autowired
	private FileStorageMapper fMapper;

	@Override
	public boolean SaveA(Test a) {
		Example example=new Example(Test.class);
		Criteria criteria = example.createCriteria();
		return aMapper.insert(a) > 0;
	}

	@Override
	public int saveFile(FileStorageInformation f) {
		Example example=new Example(FileStorageInformation.class);
		Criteria criteria = example.createCriteria();
		return  fMapper.insert(f);
	}

}
