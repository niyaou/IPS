package com.desay.pangoo.filesystem.service.Impl;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.Expression;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.util.TextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.desay.cd.utils.RespUtil;
import com.desay.cd.utils.tree.IRelation;
import com.desay.cd.utils.tree.TreeNode;
import com.desay.pangoo.filesystem.entity.FileStorageInformation;
import com.desay.pangoo.filesystem.entity.MarkLevel;
import com.desay.pangoo.filesystem.mapper.FileStorageMapper;
import com.desay.pangoo.filesystem.service.FileStorageService;
import com.sun.jersey.core.impl.provider.entity.XMLJAXBElementProvider.Text;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.entity.Example.Criteria;
import org.apache.commons.codec.binary.Base64;

/**
 * 文件存储类
 * @author uidq1343
 *
 */
@Service
@Primary
public class FileStorageImpl implements FileStorageService {
    @Autowired
    private FileStorageMapper fMapper;

    @Override
    public int saveFile(FileStorageInformation f) {
        Example example = new Example(FileStorageInformation.class);
        Criteria criteria = example.createCriteria();
        return fMapper.insert(f);
    }


    @Override
    public int updateFile(FileStorageInformation f) {
        System.out.println(f.toString());
        Example example = new Example(FileStorageInformation.class);
        Criteria criteria = example.createCriteria();
        int i = 0;
        try {
            i = fMapper.updateByPrimaryKeySelective(f);
        } catch (Exception e) {

            i = -1;
        }
        return i;
    }



    @Override
    public int saveThumbls(String path, String name, String username, String market, String userGroup, ByteArrayOutputStream f,String minitype,long filesize) {
        FileStorageInformation info = new FileStorageInformation();
        info.setFilename(name);
        info.setFilepath(path);
        info.setFilesize((double) filesize / (1024*1024));
        info.setOwner(username);
        info.setFiletype(minitype);
        info.setFileformat(name.split("\\.")[1]);
        info.setThumbs(f.toByteArray());
        info.setTarget(market);
        info.setUsergroup(userGroup);
        System.out.print("[ insert file ]");
        return fMapper.insert(info);
    }
    
    

    @Override
    public List<FileStorageInformation> queryByMarket(String marks) {
        if (TextUtils.isEmpty(marks)) {
            return null;
        }
        Example example = new Example(FileStorageInformation.class);
        Criteria criteria = example.createCriteria();
        for (String mark : marks.split(",")) {
            criteria.orLike("target", "%" + mark + "%");
        }
        List<FileStorageInformation> listBean = fMapper.selectByExample(example);
        for (FileStorageInformation item : listBean) {
        	if(item.getThumbs()==null) {
        		continue;
        	}
            byte[] imgBytesAsBase64 = Base64.encodeBase64((byte[]) item.getThumbs());
            String imgDataAsBase64 = new String(imgBytesAsBase64);
            String imgAsBase64 = "data:image/png;base64," + imgDataAsBase64;
            item.setThumbs(imgAsBase64);
            System.out.println(item.getThumbs());
        }

        return listBean;

    }


	@Override
	public List<FileStorageInformation> queryByFileFormat(String format) {
		 if (TextUtils.isEmpty(format)) {
	            return null;
	        }
		    System.out.println(format);
	        Example example = new Example(FileStorageInformation.class);
	        Criteria criteria = example.createCriteria();
	        criteria.orLike("filetype", "%" + format + "%");
	        List<FileStorageInformation> listBean = fMapper.selectByExample(example);
	        for (FileStorageInformation item : listBean) {
	        	if(item.getThumbs()==null) {
	        		continue;
	        	}
	            byte[] imgBytesAsBase64 = Base64.encodeBase64((byte[]) item.getThumbs());
	            String imgDataAsBase64 = new String(imgBytesAsBase64);
	            String imgAsBase64 = "data:image/png;base64," + imgDataAsBase64;
	            item.setThumbs(imgAsBase64);
	            System.out.println(item.getThumbs());
	        }
	        return listBean;
	}


	@Override
	public int saveDocuments(String path, String name, String username, String market, String userGroup,
			String minitype,long filesize) {
        FileStorageInformation info = new FileStorageInformation();
        info.setFilename(name);
        info.setFilepath(path);
        info.setFilesize((double) filesize / (1024*1024));
        info.setOwner(username);
        info.setFiletype(minitype);
        info.setFileformat(name.split("\\.")[1]);
        info.setTarget(market);
        info.setUsergroup(userGroup);
        System.out.print("[ insert file ]");
        return fMapper.insert(info);
	}

}
