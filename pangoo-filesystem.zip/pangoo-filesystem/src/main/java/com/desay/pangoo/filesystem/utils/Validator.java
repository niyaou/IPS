package com.desay.pangoo.filesystem.utils;

public class Validator {
    private Validator() {
    }

    public static Validator getInstance() {
        return Singleton.INSTANCE.getInstance();
    }

    private enum Singleton {
        INSTANCE;
        private Validator singleton;

        //JVM会保证此方法绝对只调用一次
        Singleton() {
            singleton = new Validator();
        }

        public Validator getInstance() {
            return singleton;
        }
    }
    public Boolean notEmpty(String s){
        return s != null && !s.equals("");
    }
}
