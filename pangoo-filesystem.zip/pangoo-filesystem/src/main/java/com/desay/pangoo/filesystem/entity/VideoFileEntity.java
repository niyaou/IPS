package com.desay.pangoo.filesystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "file_storage_information")
public class VideoFileEntity {
    @Id
    @Column(name = "filename")
    private String fileName;
    @Id
    @Column(name = "filepath")
    private String filePath;
    @Column(name = "filedate")
    private String fileDate;
    @Column(name = "filesize")
    private String fileSize;
    @Column(name = "filetype")
    private String fileType;
    @Column(name = "fileformat")
    private String fileFormat;
    @Column(name = "owner")
    private String owner;
    @Column(name = "usergroup")
    private String userGroup;
    @Id
    @Column(name = "target")
    private String target;
    @Column(name = "thumbs")
    private String thumbs;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
    @Column(name = "id", unique = true, nullable = false, length = 36)
    public String getFilePath() {
        return filePath;
    }

    public String getFileDate() {
        return fileDate;
    }

    public void setFileDate(String fileDate) {
        this.fileDate = fileDate;
    }

    public String getFileSize() {
        return fileSize;
    }

    public void setFileSize(String fileSize) {
        this.fileSize = fileSize;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getFileFormat() {
        return fileFormat;
    }

    public void setFileFormat(String fileFormat) {
        this.fileFormat = fileFormat;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getUserGroup() {
        return userGroup;
    }

    public void setUserGroup(String userGroup) {
        this.userGroup = userGroup;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getThumbs() {
        return thumbs;
    }

    public void setThumbs(String thumbs) {
        this.thumbs = thumbs;
    }


}
