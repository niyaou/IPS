package com.desay.pangoo.filesystem.mapper;

import com.desay.pangoo.filesystem.entity.FileMark;

import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.common.MySqlMapper;
import tk.mybatis.mapper.common.base.select.SelectMapper;

public interface FileMarkMapper extends Mapper<FileMark>,MySqlMapper<FileMark>,SelectMapper<FileMark> {

}
