package com.desay.pangoo.filesystem.websocket;

import com.desay.pangoo.filesystem.utils.JsonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.websocket.*;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;

public abstract class WebSocketBase {
    //静态变量，用来记录当前在线连接数。应该把它设计成线程安全的。
    private static int onlineCount = 0;
    //与某个客户端的连接会话，需要通过它来给客户端发送数据
    protected Session session;
    //concurrent包的线程安全Set，用来存放每个客户端对应的MyWebSocket对象。
    private static CopyOnWriteArraySet<WebSocketBase> webSocketSet = new CopyOnWriteArraySet<>();
    private static Logger logger = LoggerFactory.getLogger(WebSocketBase.class);
    //用户登录id
    String userId;

    abstract void onMessageImpl(String message, Session session, String userId);

    @OnMessage
    public void onMessage(String message, Session session) {
        Map<String, String> param = ParseParamUtil.getInstance().parseParam(session.getQueryString());
        String userId = param.get("login");
        logger.info("收到消息，来自:" + userId);
        logger.info("来自客户端的消息:" + message);
        onMessageImpl(message, session, userId);
    }

    abstract void onOpenImpl(Session session, EndpointConfig config);

    @OnOpen
    public void onOpen(Session session, EndpointConfig config) {
        Map<String, String> param = ParseParamUtil.getInstance().parseParam(session.getQueryString());
        this.userId = param.get("login");
        this.session = session;
        //加入set中
        webSocketSet.add(this);
        //在线数加1
        addOnlineCount();
        logger.info("有新连接加入！当前在线人数为" + getOnlineCount());
        try {
            ServerToClientMsgEntity e = new ServerToClientMsgEntity();
            e.setMsgType("log");
            e.setMsgData("连接建立成功");
            String json = JsonUtils.objectToJson(e);
            sendMessage(json);
        } catch (IOException e) {
            logger.error("IO异常");
        }
        onOpenImpl(session, config);
    }

    abstract void onCloseImpl();

    @OnClose
    public void onClose() {
        webSocketSet.remove(this);  //从set中删除
        subOnlineCount();           //在线数减1
        logger.info("有一连接关闭！当前在线人数为" + getOnlineCount());
        onCloseImpl();
    }

    private static synchronized void addOnlineCount() {
        WebSocketBase.onlineCount++;
    }

    private static synchronized void subOnlineCount() {
        WebSocketBase.onlineCount--;
    }

    private static synchronized int getOnlineCount() {
        return onlineCount;
    }

    protected void sendMessage(String message) throws IOException {
        logger.info("发送消息" + message);
        this.session.getBasicRemote().sendText(message);
    }

    abstract void onErrorImpl(Session session, Throwable error);

    /**
     * 发生错误时调用
     */
    @OnError
    public void onError(Session session, Throwable error) {
        logger.info("发生错误");
        error.printStackTrace();
        onErrorImpl(session, error);
    }
}
