package com.desay.pangoo.filesystem.service.Impl;


import com.desay.pangoo.filesystem.entity.FilePushHistory;
import com.desay.pangoo.filesystem.mapper.FilePushMapper;
import com.desay.pangoo.filesystem.service.FilePushHistoryService;
import org.apache.http.util.TextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import java.util.List;

@Service
@Primary
public class FilePushHistoryServiceImpl implements FilePushHistoryService {
    @Autowired
    private FilePushMapper fMapper;

    @Override
    public int savePushHistory(FilePushHistory f) {
        return fMapper.insert(f);
    }

    @Override
    public int updatePushHistory(FilePushHistory f) {
        return fMapper.updateByPrimaryKey(f);
    }

    @Override
    public List<FilePushHistory> queryByUserId(String userId) {
        if (TextUtils.isEmpty(userId)) {
            return null;
        }
        Example example = new Example(FilePushHistory.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("userId", userId);
        return fMapper.selectByExample(example);
    }
}
