package com.desay.pangoo.filesystem.utils;

import java.util.UUID;

public class IDGenerator {
    private IDGenerator() {
    }

    public static IDGenerator getInstance() {
        return Singleton.INSTANCE.getInstance();
    }

    private enum Singleton {
        INSTANCE;
        private IDGenerator singleton;

        //JVM会保证此方法绝对只调用一次
        Singleton() {
            singleton = new IDGenerator();
        }

        public IDGenerator getInstance() {
            return singleton;
        }
    }

    public static String GenUUID() {
        return UUID.randomUUID().toString();
    }
}
