package com.desay.pangoo.filesystem.feign;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.cd.DTO.UserInfoDTO;

@FeignClient("PANGOO-AUTHCENTOR")
public interface AuthRequest {

    /***
     * 账户密码认证
     * @param username
     * @param clientId
     * @param password
     * @return
     */
//     @RequestMapping(value = "/pwdAuthorize", method = RequestMethod.POST)
//     ResponseDTO<UserInfoDTO> pwdAuthorize(@RequestParam(value = "username") String username, @RequestParam(value = "clientId") String clientId, @RequestParam(value = "password") String password);

	/**
	 * 使用ldap作为验证登录的接口
	 * @param username
	 * @param clientId
	 * @param password
	 * @return
	 */
     @RequestMapping(value = "/pwdAuthorizeldap", method = RequestMethod.POST)
     ResponseDTO<UserInfoDTO> pwdAuthorize(@RequestParam(value = "username") String username, @RequestParam(value = "clientId") String clientId, @RequestParam(value = "password") String password);

     /**
      * token认证
      * @param token
      * @return
      */
     @RequestMapping(value = "/tokenAuthorize", method = RequestMethod.GET)
     ResponseDTO<TokenDTO> tokenAuthorize(@RequestParam(value = "token") Object token);

     /**
      * 退出登录
      * @param token
      * @return
      */
     @RequestMapping(value = "/logOutBytoken", method = RequestMethod.POST)
     ResponseDTO<TokenDTO> logOut(@RequestParam(value = "token") Object token);

     /***
      * 获取公钥
      * @return
      */
     @RequestMapping(value = "/getPublicKey", method = RequestMethod.GET)
     ResponseDTO<String> getPublicKey();

}
