package com.desay.pangoo.filesystem.service;

import com.desay.pangoo.filesystem.entity.VideoFileEntity;
import org.springframework.ui.ModelMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

public interface VideoService {
    List<VideoFileEntity> query(HttpServletRequest request, HttpServletResponse response, ModelMap model);
}
