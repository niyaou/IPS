package com.desay.pangoo.filesystem.service;

import java.io.ByteArrayOutputStream;
import java.util.List;


import com.desay.pangoo.filesystem.entity.FileStorageInformation;
public interface FileStorageService {
	
	int saveFile(FileStorageInformation f);
	int saveThumbls(String path,String name,String username,String market,String userGroup,ByteArrayOutputStream f,String minitype,long filesize);
	int saveDocuments(String path,String name,String username,String market,String userGroup,String minitype,long filesize);
	int updateFile(FileStorageInformation f);
	List<FileStorageInformation> queryByMarket(String market ) ;
	List<FileStorageInformation> queryByFileFormat(String format ) ;
	
}
