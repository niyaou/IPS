package com.desay.pangoo.filesystem.websocket;

import javax.websocket.Session;
import java.util.TimerTask;

public class UserTimeTask {
    private TimerTask t;
    private Session s;
    private String userId;
    public TimerTask getT() {
        return t;
    }

    public void setT(TimerTask t) {
        this.t = t;
    }

    public Session getS() {
        return s;
    }

    public void setS(Session s) {
        this.s = s;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
