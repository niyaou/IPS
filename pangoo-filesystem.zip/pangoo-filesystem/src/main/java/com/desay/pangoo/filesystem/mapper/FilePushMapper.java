package com.desay.pangoo.filesystem.mapper;

import com.desay.pangoo.filesystem.entity.FilePushHistory;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.common.MySqlMapper;
import tk.mybatis.mapper.common.base.select.SelectMapper;

import java.util.List;

public interface FilePushMapper extends Mapper<FilePushHistory>, MySqlMapper<FilePushHistory>, SelectMapper<FilePushHistory> {
    public List findByMarket(@Param("userId") String userId);
}
