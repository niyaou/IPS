package com.desay.pangoo.filesystem.entity;
import java.sql.Timestamp;
import java.time.Instant;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.alibaba.fastjson.JSONObject;

/**
 * 文件信息类
 * @author uidq1343
 *
 */

@Entity
@Table(name = "file_storage_information")
public class FileStorageInformation {
	/***/
	@Id
	private String filename; 
	/***/
	@Id
	private String filepath; 
	/***/
	private Timestamp filedate; 
	/***/
	private Double filesize; 
	/***/
	private String filetype; 
	/***/
	private String fileformat; 
	/***/
	private String owner; 
	/***/
	private String usergroup; 
	/***/

	private String target; 
	/***/
	private Object thumbs; 
	/**
	 * 实例化
	 */
	public FileStorageInformation() {
		super();
	}
	/**
	 * 实例化
	 * 
	 * @param obj
	 */
	public FileStorageInformation(JSONObject obj) {
		this();
		if (obj.get("filename") instanceof String) {
			this.setFilename((String) obj.get("filename"));
		}
		if (obj.get("filepath") instanceof String) {
			this.setFilepath((String) obj.get("filepath"));
		}
		this.setFiledate(obj.get("filedate"));
		if (obj.get("filesize") instanceof Number) {
			this.setFilesize(((Number) obj.get("filesize")).doubleValue());
		}
		if (obj.get("filetype") instanceof String) {
			this.setFiletype((String) obj.get("filetype"));
		}
		if (obj.get("fileformat") instanceof String) {
			this.setFileformat((String) obj.get("fileformat"));
		}
		if (obj.get("owner") instanceof String) {
			this.setOwner((String) obj.get("owner"));
		}
		if (obj.get("usergroup") instanceof String) {
			this.setUsergroup((String) obj.get("usergroup"));
		}
		if (obj.get("target") instanceof String) {
			this.setTarget((String) obj.get("target"));
		}
		this.setThumbs(obj.get("thumbs"));
	}
	
	/**
	 * 将当前对象转换为JsonObject
	 * 
	 * @return
	 */
	public JSONObject toJson() {
		JSONObject result = new JSONObject();
		if (this.getFilename() != null) {
			result.put("filename",this.getFilename());
		}
		if (this.getFilepath() != null) {
			result.put("filepath",this.getFilepath());
		}
		if (this.getFiledate() != null) {
			result.put("filedate",this.getFiledate());
		}
		if (this.getFilesize() != null) {
			result.put("filesize",this.getFilesize());
		}
		if (this.getFiletype() != null) {
			result.put("filetype",this.getFiletype());
		}
		if (this.getFileformat() != null) {
			result.put("fileformat",this.getFileformat());
		}
		if (this.getOwner() != null) {
			result.put("owner",this.getOwner());
		}
		if (this.getUsergroup() != null) {
			result.put("usergroup",this.getUsergroup());
		}
		if (this.getTarget() != null) {
			result.put("target",this.getTarget());
		}
		if (this.getThumbs() != null) {
			result.put("thumbs",this.getThumbs());
		}
		return result;
	}
	
	
	/**
	 * 获取filename
	 * 
	 * @return
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * 设置filename
	 * 
	 * @param filename
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}
	
	/**
	 * 获取filepath
	 * 
	 * @return
	 */
	public String getFilepath() {
		return filepath;
	}

	/**
	 * 设置filepath
	 * 
	 * @param filepath
	 */
	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}
	
	/**
	 * 获取filedate
	 * 
	 * @return
	 */
	public Timestamp getFiledate() {
		return filedate;
	}

	/**
	 * 设置filedate
	 * 
	 * @param object
	 */
	public void setFiledate(Object object) {
		this.filedate = (Timestamp) object;
	}
	
	/**
	 * 获取filesize
	 * 
	 * @return
	 */
	public Double getFilesize() {
		return filesize;
	}

	/**
	 * 设置filesize
	 * 
	 * @param filesize
	 */
	public void setFilesize(Double filesize) {
		this.filesize = filesize;
	}
	
	/**
	 * 获取filetype
	 * 
	 * @return
	 */
	public String getFiletype() {
		return filetype;
	}

	/**
	 * 设置filetype
	 * 
	 * @param filetype
	 */
	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}
	
	/**
	 * 获取fileformat
	 * 
	 * @return
	 */
	public String getFileformat() {
		return fileformat;
	}

	/**
	 * 设置fileformat
	 * 
	 * @param fileformat
	 */
	public void setFileformat(String fileformat) {
		this.fileformat = fileformat;
	}
	
	/**
	 * 获取owner
	 * 
	 * @return
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * 设置owner
	 * 
	 * @param owner
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}
	
	/**
	 * 获取usergroup
	 * 
	 * @return
	 */
	public String getUsergroup() {
		return usergroup;
	}

	/**
	 * 设置usergroup
	 * 
	 * @param usergroup
	 */
	public void setUsergroup(String usergroup) {
		this.usergroup = usergroup;
	}
	
	/**
	 * 获取target
	 * 
	 * @return
	 */
	public String getTarget() {
		return target;
	}

	/**
	 * 设置target
	 * 
	 * @param target
	 */
	public void setTarget(String target) {
		this.target = target;
	}
	
	/**
	 * 获取thumbs
	 * 
	 * @return
	 */
	public Object getThumbs() {
		return thumbs;
	}

	/**
	 * 设置thumbs
	 * 
	 * @param thumbs
	 */
	public void setThumbs(Object thumbs) {
		this.thumbs = thumbs;
	}

	@Override
	public String toString() {
		return "FileStorageInformation [filename=" + filename + " , filepath=" + filepath + " , filedate=" + filedate + " , filesize=" + filesize + " , filetype=" + filetype + " , fileformat=" + fileformat + " , owner=" + owner + " , usergroup=" + usergroup + " , target=" + target + " , thumbs=" + thumbs + "  ]";
	
	}
}
