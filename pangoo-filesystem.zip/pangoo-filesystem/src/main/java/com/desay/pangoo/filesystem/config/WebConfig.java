package com.desay.pangoo.filesystem.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * 
 * @author uidq1163
 *
 */
@Configuration
public class WebConfig extends WebMvcConfigurerAdapter{
    
//    //拦截器
//    @Override
//    public void addInterceptors(InterceptorRegistry registry){
//        registry.addInterceptor(new LogInterceptor()).addPathPatterns("/**");
//        super.addInterceptors(registry);
//    }
}
