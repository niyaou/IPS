package com.desay.pangoo.filesystem.controller.mark;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.desay.cd.utils.RespUtil;
import com.desay.pangoo.filesystem.service.MarkSettingService;

/**
 * 
 * @author 标签库管理
 *
 */

@Controller
@RequestMapping("/marksetting")
public class MarkSettingController {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	MarkSettingService menuSettingService;

	/**
	 * 初始化进入设置界面
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping("/index")
	public String init(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
		try {
			menuSettingService.index(request, response, model);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return ("/mark/markshow");
	}
	
	/**
	 * 标签分类Tree
	 * 
	 * @param request
	 * @param model
	 * @return
	 */
	@RequestMapping("/wzflGroup")
	public String wzflGroup(HttpServletRequest request, ModelMap model) {
		return ("/mark/marksettingZtree");
	}

	@RequestMapping("/queryTree")
	public void queryTree(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
		try {
			menuSettingService.queryTree(request, response, model);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	@RequestMapping("/addAndEdit")
	public String addAndEdit(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
		try {
			menuSettingService.addAndEdit(request, response, model);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return ("/mark/marksetting");
	}
	
	@RequestMapping("/save")
	public void save(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
		Map<String, Object> result = new HashMap<>();
		result.put("success", false);
		try {
			menuSettingService.save(request, response, result);
			result.put("success", true);
		} catch (Exception e) {
			logger.error(e.getMessage());
			result.put("errorMsg", e.getMessage());
		}
		RespUtil.returnResult(request, response, result);
	}
}
