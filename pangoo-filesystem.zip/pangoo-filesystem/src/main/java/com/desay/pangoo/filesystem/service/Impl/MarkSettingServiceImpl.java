package com.desay.pangoo.filesystem.service.Impl;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.desay.cd.utils.CollectionUtil;
import com.desay.cd.utils.RespUtil;
import com.desay.cd.utils.tree.IRelation;
import com.desay.cd.utils.tree.TreeNode;
import com.desay.cd.utils.tree.TreeTool;
import com.desay.pangoo.filesystem.entity.MarkLevel;
import com.desay.pangoo.filesystem.exception.BizException;
import com.desay.pangoo.filesystem.mapper.MarkLevelMapper;
import com.desay.pangoo.filesystem.service.MarkSettingService;
import com.desay.pangoo.filesystem.utils.IDGenerator;

@Service
@Primary
public class MarkSettingServiceImpl implements MarkSettingService{

	@Autowired
	MarkLevelMapper markLevelMapper;

	/**
	 * 首页
	 */
	public void index(HttpServletRequest request, HttpServletResponse response, ModelMap ModelMap) throws Exception {

		// 获取所有菜单信息
		List<MarkLevel> listBean = markLevelMapper.selectAll();
		// 父子关系处理
		IRelation<MarkLevel> relation = new IRelation<MarkLevel>() {
			@Override
			public boolean isFatherAndSon(MarkLevel father, MarkLevel son) {
				return father.getId().equals(son.getParentId());
			}
		};
		List<TreeNode<MarkLevel>> treeNodes = new TreeTool<MarkLevel>(listBean, relation).getTreeNodes();
		LinkedHashSet<String> groupInfos = new LinkedHashSet<String>();
		for (TreeNode<MarkLevel> treeNode : treeNodes) {
			groupInfos.add(getGroupInfoJsonObj(treeNode).toString());
		}
		ModelMap.put("groupInfos", groupInfos.toString());
	}

	/**
	 * 首页
	 */
	@Transactional
	public void index(HttpServletRequest request, HttpServletResponse response, ModelMap ModelMap,
			HashMap<String, Boolean> codes) throws Exception {

		// 获取所有菜单信息
		List<MarkLevel> listBean = markLevelMapper.selectAll();
		// 父子关系处理
		IRelation<MarkLevel> relation = new IRelation<MarkLevel>() {
			@Override
			public boolean isFatherAndSon(MarkLevel father, MarkLevel son) {
				return father.getId().equals(son.getParentId());
			}
		};
		List<TreeNode<MarkLevel>> treeNodes = new TreeTool<MarkLevel>(listBean, relation).getTreeNodes();
		LinkedHashSet<String> groupInfos = new LinkedHashSet<String>();
		for (TreeNode<MarkLevel> treeNode : treeNodes) {
			groupInfos.add(getGroupInfoJsonObj(treeNode, codes).toString());
		}
		ModelMap.put("groupInfos", groupInfos.toString());
	}

	/**
	 * JSONObject 数据格式设定(requset用)
	 * 
	 * @param treeNode
	 * @return
	 * @throws JSONException
	 */
	private JSONObject getGroupInfoJsonObj(TreeNode<MarkLevel> treeNode) throws Exception {
		JSONObject jsonObj = new JSONObject();
		MarkLevel MarkLevel = treeNode.getSelf();
		jsonObj.put("id", MarkLevel.getId());
		jsonObj.put("name", MarkLevel.getMarkName());
		jsonObj.put("pId", String.valueOf(MarkLevel.getParentId()));
		jsonObj.put("index_x", MarkLevel.getIndexX());
		jsonObj.put("isParent", treeNode.getChildren() != null && treeNode.getChildren().size() > 0);
		return jsonObj;
	}

	private JSONObject getGroupInfoJsonObj(TreeNode<MarkLevel> treeNode, HashMap<String, Boolean> codes)
			throws Exception {
		JSONObject jsonObj = new JSONObject();
		MarkLevel MarkLevel = treeNode.getSelf();
		jsonObj.put("id", MarkLevel.getId());
		jsonObj.put("name", MarkLevel.getMarkName());
		jsonObj.put("pId", String.valueOf(MarkLevel.getParentId()));
		jsonObj.put("index_x", MarkLevel.getIndexX());
		jsonObj.put("isParent", treeNode.getChildren() != null && treeNode.getChildren().size() > 0);
		if (codes.get(MarkLevel.getMarkName()) != null) {
			if (codes.get(MarkLevel.getMarkName())) {
				jsonObj.put("checked", true);
			}
		}
		return jsonObj;
	}

	public void queryTree(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception {
		Map<String, Object> result = new HashMap<>();
		result.put("success", false);
		   Date date = new Date();
		   DateFormat df2 = DateFormat.getDateTimeInstance();//可以精确到时分秒
		// 获取所有菜单信息
		List<MarkLevel> listBean = markLevelMapper.selectAll();
		date = new Date();
		// 父子关系处理
		IRelation<MarkLevel> relation = new IRelation<MarkLevel>() {
			@Override
			public boolean isFatherAndSon(MarkLevel father, MarkLevel son) {
				return father.getId().equals(son.getParentId());
			}
		};
		List<TreeNode<MarkLevel>> treeNodes = new TreeTool<MarkLevel>(listBean, relation).getTreeNodes();
		List<Map<String, Object>> groupInfos = new ArrayList<Map<String, Object>>();
		for (TreeNode<MarkLevel> treeNode : treeNodes) {
			groupInfos.add(getGroupInfo(treeNode));
		}
		result.put("success", true);
		result.put("groupInfos", groupInfos);
		RespUtil.returnResult(request, response, result);
		
	}

	/**
	 * Map 数据格式设定(ajax用)
	 * 
	 * @param treeNode
	 * @return
	 */
	private Map<String, Object> getGroupInfo(TreeNode<MarkLevel> treeNode) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		MarkLevel lessonLevel = treeNode.getSelf();
		map.put("id", lessonLevel.getId().toString());
		map.put("name", lessonLevel.getMarkName());
		map.put("pId", String.valueOf(lessonLevel.getParentId()));
		map.put("index_x", lessonLevel.getIndexX());
		map.put("isParent", treeNode.getChildren() != null && treeNode.getChildren().size() > 0);
		return map;
	}

	/**
	 * 新增和修改返回界面
	 */
	public void addAndEdit(HttpServletRequest request, HttpServletResponse response, ModelMap ModelMap) {
		// 主键id
		String zjid = request.getParameter("zjid");
		ModelMap.put("zjid", zjid);
		// 新增标识：-1
		if ("-1".equals(zjid)) {
			// 上级id
			String parentId = request.getParameter("parentId");
			if (StringUtils.isNotEmpty(parentId)) {
				// 上级名称
				MarkLevel MarkLevel = new MarkLevel();
				MarkLevel.setId(parentId);
				MarkLevel MarkLevelParentId = markLevelMapper.selectOne(MarkLevel);
				if (MarkLevelParentId != null) {
					// 上级id
					ModelMap.put("parentId", parentId);
					// 上级名称
					ModelMap.put("parentName", MarkLevelParentId.getMarkName());
				} else {
					// 上级id
					ModelMap.put("parentId", "");
					// 上级名称
					ModelMap.put("parentName", "");
				}
			} else {
				// 上级id
				ModelMap.put("parentId", "");
				// 上级名称
				ModelMap.put("parentName", "");
			}
		} else {
			MarkLevel markLevel = new MarkLevel();
			markLevel.setId(zjid);
			markLevel = markLevelMapper.selectOne(markLevel);
			// 菜单名称
			ModelMap.put("menuName", markLevel.getMarkName());
			// 上级id
			String parentId = markLevel.getParentId();
			ModelMap.put("parentId", parentId);
			if (StringUtils.isNotEmpty(parentId)) {
				// 上级名称
				MarkLevel markLevelParent = new MarkLevel();
				markLevelParent.setId(parentId);
				markLevelParent=markLevelMapper.selectOne(markLevelParent);

				if (markLevelParent != null) {
					ModelMap.put("parentName", markLevelParent.getMarkName());
				} else {
					ModelMap.put("parentName", "");
				}
			} else {
				// 上级名称
				ModelMap.put("parentName", "");
			}
		}
	}

	/**
	 * 添加保存
	 */
	@Transactional(value = "masterTransactionManager")
	public void save(HttpServletRequest request, HttpServletResponse response, Map<String, Object> result)
			throws BizException {
		// 主键id
		String zjid = request.getParameter("zjid");
		// 上级id
		String parentId = request.getParameter("parentId");
		// 名称
		String menuName = request.getParameter("menuName");
		// 新增
		if ("-1".equals(zjid)) {
			// 判断数据是否重复
			MarkLevel markLevel = new MarkLevel();
			markLevel.setMarkName(menuName);
			List<MarkLevel> list = markLevelMapper.select(markLevel);
			// 数据重复，不能修改
			if (CollectionUtil.isNotEmpty(list)) {
				if (!zjid.equals(list.get(0).getId())) {
					result.put("hasData", true);
					throw new BizException("hasData");
				}
			}
			// 上级id
			markLevel.setParentId(parentId);
			// 名称
			markLevel.setMarkName(menuName);
			// 创建时间
			markLevel.setCreateTime(new Date());
			markLevel.setId(IDGenerator.GenUUID());
			// 保存
			markLevelMapper.insert(markLevel);
			// 返回值
			result.put("zjid", markLevel.getId());
		} else {
			// 编辑
			MarkLevel MarkLevel = markLevelMapper.selectByPrimaryKey((String)zjid);
			// 参数
			// 上级id
			MarkLevel.setParentId(parentId);
			// 名称
			MarkLevel.setMarkName(menuName);
			// 创建时间
			MarkLevel.setCreateTime(new Date());
			// 更新
			markLevelMapper.updateByPrimaryKey(MarkLevel);
			result.put("zjid", MarkLevel.getId());
		}
	}
}
