package com.desay.pangoo.filesystem;

import com.desay.pangoo.filesystem.config.DynamicDataSourceRegister;
import com.desay.pangoo.filesystem.websocket.PushProgressSocket;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@EnableEurekaClient
@EnableFeignClients
@Import(DynamicDataSourceRegister.class)
public class FileSystemApplication {
    public static void main(String[] args) {
        ConfigurableApplicationContext configurableApplicationContext = SpringApplication.run(FileSystemApplication.class, args);
        //解决WebSocket不能注入的问题
        PushProgressSocket.setApplicationContext(configurableApplicationContext);
    }
}
