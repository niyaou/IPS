package com.desay.pangoo.filesystem.websocket;

import com.desay.pangoo.filesystem.threadpool.FixedThreadPoolUtil;
import com.desay.pangoo.filesystem.utils.JsonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.websocket.EndpointConfig;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint(value = "/uploadFileSocket")
@Component
public class UploadFileSocket extends WebSocketBase {
    private static Logger logger = LoggerFactory.getLogger(UploadFileSocket.class);

    @Override
    void onMessageImpl(String message, Session session, String userId) {
        logger.info("收到文件上传socket消息" + message);
        ClientToServerMsgEntity c = JsonUtils.jsonToPojo(message, ClientToServerMsgEntity.class);
        if (c == null) {
            return;
        }
        if (c.getMsgType().equals("cancel")) {
            String taskId = c.getData();
            FixedThreadPoolUtil.getInstance().cancelTask(taskId);
        }
    }

    @Override
    void onOpenImpl(Session session, EndpointConfig config) {

    }

    @Override
    void onCloseImpl() {

    }

    @Override
    void onErrorImpl(Session session, Throwable error) {

    }
}
