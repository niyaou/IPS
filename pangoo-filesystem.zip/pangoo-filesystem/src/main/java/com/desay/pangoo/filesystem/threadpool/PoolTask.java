package com.desay.pangoo.filesystem.threadpool;

import com.desay.pangoo.filesystem.utils.IDGenerator;

import java.util.concurrent.ScheduledFuture;

public abstract class PoolTask implements Runnable {
    private String taskId;
    private ScheduledFuture future;
    public abstract void runSubTask();

    protected PoolTask(){
        this.taskId = IDGenerator.getInstance().GenUUID();
    }
    @Override
    public void run() {
        runSubTask();
        FixedThreadPoolUtil.getInstance().taskFinish(taskId);
    }

    public String getTaskId() {
        return taskId;
    }

    public ScheduledFuture getFuture() {
        return future;
    }

    public void setFuture(ScheduledFuture f) {
        this.future = f;
    }
}
