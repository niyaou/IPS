package com.desay.pangoo.filesystem.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.cd.DTO.UserInfoDTO;
import com.desay.cd.common.auth.ConstantUtils;
import com.desay.cd.utils.RespUtil;
import com.desay.pangoo.filesystem.annotation.LogAnnotation;
import com.desay.pangoo.filesystem.feign.AuthRequest;

import feign.FeignException;

/**
 * 管理系统
 *
 */
@Controller
public class LoginController {
	private String LOGIN="LOGIN";
	private String MEMBEROF="MEMBEROF";
	@Autowired
	AuthRequest authRequest;

	@RequestMapping("index")
	public String index(HttpServletRequest request, HttpServletResponse response, ModelMap ModelMap) {
		return "index";
	}

	@RequestMapping("login")
	public String login(HttpServletRequest request, HttpServletResponse response, ModelMap ModelMap) {
		request.setAttribute("contextPath", request.getContextPath());
		ModelMap.put("backurl", request.getAttribute("backurl"));
		return "login";
	}

	@RequestMapping("/")
	public String main(HttpServletRequest request, HttpServletResponse response, ModelMap ModelMap) {
		Object token = request.getSession().getAttribute(ConstantUtils.SESSION_TOKEN);
		boolean resut = token == null ? false : isLogined(token);
		request.setAttribute("contextPath", request.getContextPath());
		if (!resut) {
			return "login";
		}else {
			return "main";
		}
	}

	@RequestMapping("logout")
	public void logout(HttpServletRequest request, HttpServletResponse response, ModelMap ModelMap) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("success", true);
		try {
			Object token = request.getSession().getAttribute(ConstantUtils.SESSION_TOKEN);
			if (token != null) {
				try {
					authRequest.logOut(token);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			map.put("message", e.getMessage());
		}
		RespUtil.returnResult(request, response, map);
	}

	@RequestMapping("/getPublicKey")
	@LogAnnotation(action="获取公钥",targetType="",remark="密码认证")
	public Object getPublicKey(HttpServletRequest request, HttpServletResponse response, ModelMap ModelMap) {
		ResponseDTO<String> date = authRequest.getPublicKey();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		return new ResponseEntity(date, headers, HttpStatus.OK);
	}

	@RequestMapping("/dologin")
	@LogAnnotation(action="用户登录认证",targetType="",remark="")
	public Object loginPost(@RequestParam(value = "login", required = true) String login,
			@RequestParam(value = "pwd", required = true) String loginPassword, HttpServletRequest request,
			HttpServletResponse response) {
		ResponseDTO<UserInfoDTO> user = authRequest.pwdAuthorize(login, "W0201806130001", loginPassword);
		if (user.getCode()==200) {
			request.getSession().setAttribute(LOGIN, user.getData().getLogin());
			request.getSession().setAttribute(ConstantUtils.SESSION_TOKEN, user.getData().getToken());
			request.getSession().setAttribute(MEMBEROF, user.getData().getMemberof());
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		return new ResponseEntity(user, headers, HttpStatus.OK);
	}
	
	boolean isLogined(Object sessionid) {
		boolean result = false;
		try {
			ResponseDTO<TokenDTO> token = authRequest.tokenAuthorize(sessionid);
			if (token != null && token.getCode() == 200) {
				result = true;
			}

		} catch (FeignException e) {
			e.printStackTrace();
			// TODO: 认证失败
		}
		return result;

	}
}
