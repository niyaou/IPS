package com.desay.pangoo.filesystem.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.ModelMap;

public interface MarkSettingService {

	void index(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception;

	void queryTree(HttpServletRequest request, HttpServletResponse response, ModelMap model)throws Exception;

	void addAndEdit(HttpServletRequest request, HttpServletResponse response, ModelMap model);

	void save(HttpServletRequest request, HttpServletResponse response, Map<String, Object> result);

}
