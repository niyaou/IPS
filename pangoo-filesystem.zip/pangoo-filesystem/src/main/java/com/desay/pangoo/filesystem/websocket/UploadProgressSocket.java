package com.desay.pangoo.filesystem.websocket;

import com.desay.pangoo.filesystem.utils.JsonUtils;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.*;

@ServerEndpoint(value = "/uploadProgress")
@Component
public class UploadProgressSocket extends WebSocketBase{
    private Map<String, Integer> progressPercentageMap = new HashMap<>();
    private static Timer timer = null;
    private static Map<String, UserTimeTask> uploadIdTimerTaskMap = Collections.synchronizedMap(new HashMap<>());
    private static Map<String, Vector<String>> userIdFileUploadIdMap = Collections.synchronizedMap(new HashMap<String, Vector<String>>());

    /**
     * 连接建立成功调用的方法
     */
    public void onOpenImpl(Session session, EndpointConfig config) {
        if (userIdFileUploadIdMap.containsKey(userId)) {
            Vector<String> ids = userIdFileUploadIdMap.get(userId);
            Vector<String> removeList = new Vector<>();
            for (String id : ids) {
                if (uploadIdTimerTaskMap.containsKey(id)) {
                    UserTimeTask u =  uploadIdTimerTaskMap.get(id);
                    if (u != null){
                        u.setS(session);
                    }
                } else {
                    removeList.add(id);
                }
            }
            for (String id : removeList) {
                ids.remove(id);
            }
        }
    }

    /**
     * 连接关闭调用的方法
     */
    public void onCloseImpl() {
        if (userIdFileUploadIdMap.containsKey(userId)) {
            for (String pushId : userIdFileUploadIdMap.get(userId)) {
                if (uploadIdTimerTaskMap.containsKey(pushId)) {
                    uploadIdTimerTaskMap.get(pushId).setS(null);
                }
            }
        }
    }

    /**
     * 收到客户端消息后调用的方法
     *
     * @param message 客户端发送过来的消息
     */
    public void onMessageImpl(String message, Session session,String userId) {
        ClientToServerMsgEntity c = JsonUtils.jsonToPojo(message, ClientToServerMsgEntity.class);
        if (c == null) {
            return;
        }
        if (c.getMsgType().equals("upload")) {
            if (timer != null) {
                timer.purge();
            } else {
                timer = new Timer();
            }
            String fileName = c.getData() + System.currentTimeMillis();
            Vector<String> v = userIdFileUploadIdMap.getOrDefault(userId, new Vector<>());
            if (v.contains(fileName)) {
                return;
            }
            v.add(fileName);
            userIdFileUploadIdMap.put(userId, v);
            setProgressPercentage(fileName, 0);
            UserTimeTask u = uploadIdTimerTaskMap.get(fileName);
            if (u != null) {
                if (u.getT() != null) {
                    u.getT().cancel();
                }
            }
            UserTimeTask ut = new UserTimeTask();
            ut.setUserId(userId);
            ut.setT(new TimerTask() {
                @Override
                public void run() {
                    setProgressPercentage(fileName, getProgressPercentage(fileName) + 1);
                    try {
                        PushProgress p = new PushProgress();
                        p.setFileName(fileName);
                        p.setProgress("进度:" + getProgressPercentage(fileName) + "%");
                        PushProgress[] progresses = {p};
                        ServerToClientMsgEntity e = new ServerToClientMsgEntity();
                        e.setMsgType("data");
                        e.setMsgData(JsonUtils.objectToJson(progresses));
                        String msg = JsonUtils.objectToJson(e);
                        System.out.println(msg);
                        if (ut.getS() != null) {
                            ut.getS().getBasicRemote().sendText(msg);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (getProgressPercentage(fileName) == 100) {
                        progressPercentageMap.remove(fileName);
                        uploadIdTimerTaskMap.remove(fileName);
                        userIdFileUploadIdMap.get(ut.getUserId()).remove(fileName);
                        cancel();
                    }
                }
            });
            ut.setS(this.session);
            uploadIdTimerTaskMap.put(fileName, ut);
            timer.schedule(ut.getT(), 0, 100);
        } else if (c.getMsgType().equals("stop")) {
            if (timer != null) {
                timer.cancel();
                timer = null;
            }
            progressPercentageMap.clear();
            uploadIdTimerTaskMap.clear();
            userIdFileUploadIdMap.getOrDefault(userId, new Vector<>()).clear();
        } else {
            if (c.getMsgType().equals("cancelSelect")) {
                String fileName = c.getData();
                Vector<String> v = userIdFileUploadIdMap.getOrDefault(userId, new Vector<>());
                if (v.contains(fileName)) {
                    v.remove(fileName);
                }
                progressPercentageMap.remove(fileName);
                UserTimeTask u = uploadIdTimerTaskMap.get(fileName);
                if (u != null) {
                    TimerTask t = u.getT();
                    if (t != null) {
                        t.cancel();
                    }
                }
                uploadIdTimerTaskMap.remove(fileName);
            }
        }
    }

    /**
     * 发生错误时调用
     */
    public void onErrorImpl(Session session, Throwable error) {
    }

    private Integer getProgressPercentage(String fileName) {
        return progressPercentageMap.getOrDefault(fileName, 0);
    }

    private void setProgressPercentage(String fileName, int progressPercentage) {
        this.progressPercentageMap.put(fileName, progressPercentage);
    }

    public void setTimer(Timer timer) {
        UploadProgressSocket.timer = timer;
    }

    public Timer getTimer() {
        return timer;
    }
}
