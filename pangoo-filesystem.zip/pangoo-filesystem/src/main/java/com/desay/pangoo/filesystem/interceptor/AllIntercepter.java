package com.desay.pangoo.filesystem.interceptor;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.desay.cd.DTO.ResponseDTO;
import com.desay.cd.DTO.TokenDTO;
import com.desay.cd.common.auth.ConstantUtils;
import com.desay.cd.utils.PageUtil;
import com.desay.cd.utils.RespUtil;
import com.desay.pangoo.filesystem.feign.AuthRequest;
import com.desay.pangoo.filesystem.utils.ReqUtil;

import feign.FeignException;

public class AllIntercepter extends HandlerInterceptorAdapter {
	@Autowired
	AuthRequest authRequest;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		request.setAttribute("contextPath", request.getContextPath());
		return allowVisit(request, response);
	}

	// 是否允许访问
	private boolean allowVisit(HttpServletRequest request, HttpServletResponse response) {
		Object token = request.getSession().getAttribute(ConstantUtils.SESSION_TOKEN);
		boolean resut = token == null ? false : isLogined(token);
		if (!resut) {
			try {
				request.setAttribute("backurl", request.getRequestURI().toString());
				request.setAttribute("contextPath", request.getContextPath());
				// request.getRequestDispatcher("/login").forward(request, response);
				StringBuilder builder = new StringBuilder();
				builder.append("<script>");
				builder.append("top.location.href='" + ReqUtil.getIP(request.getRequestURL().toString()) + "';");
				builder.append("</script>");
				RespUtil.returnResult(request, response, builder.toString());
				return false;
			} catch (Exception e) {
				e.printStackTrace();
			}
			return false;
		}
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		setPagination(request);
	}

	private void setPagination(HttpServletRequest request) throws UnsupportedEncodingException {
		if (request.getAttribute(PageUtil.PAGE_COUNT_STRING) != null) {
			Integer pageSize = PageUtil.getRangSize(request);
			Integer pageIndex = PageUtil.getPageIndex(request);
			Integer pageCount = PageUtil.getPageCount(request);
			PageUtil pageUtil = new PageUtil(pageCount, pageIndex, pageSize);
			request.setAttribute("pageUtil", pageUtil);
			String href = request.getRequestURI();
			String paramJson = PageUtil.getRequestParamJson(request);
			request.setAttribute("paramJson", paramJson);
			href = href.substring(href.lastIndexOf("/") + 1);// + "?" + params;
			request.setAttribute("paginationHref", href);
		}
	}

	boolean isLogined(Object sessionid) {
		boolean result = false;
		try {
			ResponseDTO<TokenDTO> token = authRequest.tokenAuthorize(sessionid);
			if (token != null && token.getCode() == 200) {
				result = true;
			}

		} catch (FeignException e) {
			e.printStackTrace();
			// TODO: 认证失败
		}
		return result;

	}
}
