package com.desay.pangoo.filesystem.websocket;

public class ClientToServerMsgEntity {
    private String msgType;
    private String data;

    public String getMsgType() {
        return msgType;
    }

    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
