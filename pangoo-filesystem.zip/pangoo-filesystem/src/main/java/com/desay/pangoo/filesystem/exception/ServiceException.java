package com.desay.pangoo.filesystem.exception;

/**
 * 服务异常
 * 
 * @author uidq1163
 *
 */
@SuppressWarnings("serial")
public class ServiceException extends Exception {

	private ExceptionEnum exceptionEnum;

	public ServiceException(ExceptionEnum exceptionEnum) {
		super();
		this.exceptionEnum = exceptionEnum;
	}

	public ServiceException(ExceptionEnum exceptionEnum, String message) {
		super(message);
		this.exceptionEnum = exceptionEnum;
	}

	public ServiceException(ExceptionEnum exceptionEnum, Throwable cause) {
		super(cause);
		this.exceptionEnum = exceptionEnum;
	}

	public ServiceException(ExceptionEnum exceptionEnum, String message, Throwable cause) {
		super(message, cause);
		this.exceptionEnum = exceptionEnum;
	}

	public String getErrorCode() {
		return exceptionEnum.getCode();
	}
}
