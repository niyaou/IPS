package com.desay.pangoo.filesystem.websocket;

import com.desay.cd.common.file.FilePushUtils;
import com.desay.pangoo.filesystem.entity.FilePushHistory;
import com.desay.pangoo.filesystem.service.FilePushHistoryService;
import com.desay.pangoo.filesystem.utils.JsonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.websocket.EndpointConfig;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.*;


@ServerEndpoint(value = "/pushProgress")
@Component
public class PushProgressSocket extends WebSocketBase {
    @Autowired
    private FilePushHistoryService filePushService;
    private static ApplicationContext applicationContext;

    public static void setApplicationContext(ApplicationContext applicationContext) {
        PushProgressSocket.applicationContext = applicationContext;
    }

    private static Logger logger = LoggerFactory.getLogger(PushProgressSocket.class);
    //与某个客户端的连接会话，需要通过它来给客户端发送数据
    private Timer timer = null;

    @Override
    void onOpenImpl(Session session, EndpointConfig config) {
        filePushService = applicationContext.getBean(FilePushHistoryService.class);
    }

    @Override
    void onCloseImpl() {
    }

    @Override
    void onMessageImpl(String message, Session session, String userId) {
        ClientToServerMsgEntity c = JsonUtils.jsonToPojo(message, ClientToServerMsgEntity.class);
        if (c == null) {
            return;
        }
        switch (c.getMsgType()) {
            case "push":
                timer = new Timer();
                List<FilePushHistory> flist = filePushService.queryByUserId(userId);
                UserTimeTask ut = new UserTimeTask();
                ut.setUserId(userId);
                ut.setT(new TimerTask() {
                    @Override
                    public void run() {
                        List<FilePushHistory> finishedList = new ArrayList<>();
                        List<FilePushHistory> unfinishedList = new ArrayList<>();
                        HashMap<String, String> unfinishedFileMap = new HashMap<>();
                        for (FilePushHistory f : flist) {
                            if (null != f.getPushProgress() && f.getPushProgress().equals("100")) {
                                finishedList.add(f);
                            } else {
                                unfinishedFileMap.put(f.getPushFileHdfsPath(), f.getPushFileServerPath());
                                unfinishedList.add(f);
                            }
                        }
                        Map<String, Double> unfinishedProgressMap = FilePushUtils.getHdfsPushProgress(unfinishedFileMap);
                        boolean allFinish = true;
                        ArrayList<PushProgress> progresses = new ArrayList<>();
                        for (Map.Entry<String, Double> entry : unfinishedProgressMap.entrySet()) {
                            if (entry.getValue() != 100) {
                                allFinish = false;
                            }
                            PushProgress p = new PushProgress();
                            p.setFileName(entry.getKey());
                            p.setProgress("进度:" + entry.getValue() + "%");
                            progresses.add(p);
                        }
                        for (FilePushHistory entry : finishedList) {
                            PushProgress p = new PushProgress();
                            p.setFileName(entry.getPushFileHdfsPath());
                            p.setProgress("进度:" + 100.0 + "%");
                            progresses.add(p);
                        }
                        try {
                            ServerToClientMsgEntity e = new ServerToClientMsgEntity();
                            e.setMsgType("data");
                            e.setMsgData(JsonUtils.objectToJson(progresses));
                            String msg = JsonUtils.objectToJson(e);
                            logger.info(msg);
                            if (ut.getS() != null) {
                                ut.getS().getBasicRemote().sendText(msg);
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        if (allFinish) {
                            for (FilePushHistory fph : unfinishedList) {
                                fph.setPushProgress("100");
                                logger.info("设置:" + fph.getUserId() + fph.getPushTime().toString());
                                filePushService.updatePushHistory(fph);
                            }
                            cancel();
                        }
                    }
                });
                ut.setS(this.session);
                timer.schedule(ut.getT(), 0, 2000);
                break;
            case "stop":
                if (timer != null) {
                    timer.cancel();
                    timer = null;
                }
                break;
            default:
                break;
        }
    }

    @Override
    void onErrorImpl(Session session, Throwable error) {

    }

    public Timer getTimer() {
        return timer;
    }
}