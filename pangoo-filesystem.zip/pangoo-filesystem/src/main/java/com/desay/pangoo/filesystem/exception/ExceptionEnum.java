package com.desay.pangoo.filesystem.exception;


/**
 * 异常枚举
 * @author Luo.Guilin
 * 前4位模块描述,后4位异常描述
 * 0000表示程序异常相关的
 */ 
public enum ExceptionEnum {

	UsernameOrPasswordError("00010005", "用户名或密码错误");
	
	/**
	 * 异常代码
	 */
	private String code;
	/**
	 * 描述信息
	 */
	private String description;
	
	private ExceptionEnum(String code, String description){
		this.code = code;
		this.description = description;
	}


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

    public static ExceptionEnum getEnumByKey(String key) {
    	ExceptionEnum[] values =ExceptionEnum.values();
        for (ExceptionEnum state : values) {
            if (state.code.equals(key)) {
                return state;
            }
        }
        throw new IllegalArgumentException("can not find enum!key=" + key);
    }
	
}
