package com.desay.pangoo.filesystem.service;

import com.desay.pangoo.filesystem.entity.FileStorageInformation;
import com.desay.pangoo.filesystem.entity.Test;

public interface TestService {
	boolean SaveA(Test a);
	
	int saveFile(FileStorageInformation f);
}
