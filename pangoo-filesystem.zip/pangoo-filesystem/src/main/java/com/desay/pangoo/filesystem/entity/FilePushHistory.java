package com.desay.pangoo.filesystem.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Timestamp;

@Entity
@Table(name = "file_push_history")
public class FilePushHistory {
    @Id
    private String userId;
    @Id
    private Timestamp pushTime;
    private String pushFileHdfsPath;
    private String pushFileServerPath;
    private String pushProgress;

    public String getPushProgress() {
        return pushProgress;
    }

    public void setPushProgress(String pushProgress) {
        this.pushProgress = pushProgress;
    }


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Timestamp getPushTime() {
        return pushTime;
    }

    public void setPushTime(Timestamp pushTime) {
        this.pushTime = pushTime;
    }

    public String getPushFileHdfsPath() {
        return pushFileHdfsPath;
    }

    public void setPushFileHdfsPath(String pushFileHdfsPath) {
        this.pushFileHdfsPath = pushFileHdfsPath;
    }

    public String getPushFileServerPath() {
        return pushFileServerPath;
    }

    public void setPushFileServerPath(String pushFileServerPath) {
        this.pushFileServerPath = pushFileServerPath;
    }


}
