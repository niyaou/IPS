package com.desay.pangoo.filesystem.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@ImportResource(locations = { "classpath:application-bean.xml" })
@Configuration
public class MvcConfig {
}
