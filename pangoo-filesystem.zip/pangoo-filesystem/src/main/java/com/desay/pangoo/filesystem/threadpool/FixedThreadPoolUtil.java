package com.desay.pangoo.filesystem.threadpool;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class FixedThreadPoolUtil {
//    private ScheduledExecutorService fixedThreadPool = new ScheduledThreadPoolExecutor(15);
    private ThreadPoolExecutor fixedThreadPool = new ThreadPoolExecutor(1,5,30,TimeUnit.SECONDS,new SynchronousQueue<Runnable>());
    
    private Map<String, PoolTask> tasks = new HashMap<>();

    public String submitTask(PoolTask r) {
        ScheduledFuture f = fixedThreadPool.schedule(r, 0, TimeUnit.SECONDS);
        r.setFuture(f);
        tasks.put(r.getTaskId(), r);
        return r.getTaskId();
        
        
    }

    public void taskFinish(String taskId) {
        tasks.remove(taskId);
    }

    public void cancelTask(String taskId) {
        PoolTask t = tasks.get(taskId);
        if (null != t) {
            t.getFuture().cancel(true);
        }
    }

    private FixedThreadPoolUtil() {
    }

    public static FixedThreadPoolUtil getInstance() {
        return Singleton.INSTANCE.getInstance();
    }

    private enum Singleton {
        INSTANCE;

        private FixedThreadPoolUtil singleton;

        //JVM会保证此方法绝对只调用一次
        Singleton() {
            singleton = new FixedThreadPoolUtil();
        }

        public FixedThreadPoolUtil getInstance() {
            return singleton;
        }
    }
}
