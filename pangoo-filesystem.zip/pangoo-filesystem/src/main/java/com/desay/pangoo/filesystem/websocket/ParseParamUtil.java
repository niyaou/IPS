package com.desay.pangoo.filesystem.websocket;

import java.util.HashMap;
import java.util.Map;

public class ParseParamUtil {
    private ParseParamUtil() {
    }

    public static ParseParamUtil getInstance() {
        return Singleton.INSTANCE.getInstance();
    }

    private enum Singleton {
        INSTANCE;

        private ParseParamUtil singleton;

        //JVM会保证此方法绝对只调用一次
        Singleton() {
            singleton = new ParseParamUtil();
        }

        public ParseParamUtil getInstance() {
            return singleton;
        }
    }

    /**
     * 解析参数,参数格式: a=x;b=y;c=z
     *
     * @param s 参数串
     * @return 参数名和参数值的map
     */
    public Map<String, String> parseParam(String s) {
        Map<String, String> m = new HashMap<>();
        String[] paramPairs = s.split(";");
        for (String param : paramPairs) {
            String[] elems = param.split("=");
            if (elems.length != 2) {
                continue;
            }
            m.put(elems[0], elems[1]);
        }
        return m;
    }
}
