package com.desay.pangoo.filesystem.mapper;

import com.desay.pangoo.filesystem.entity.VideoFileEntity;
import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.common.MySqlMapper;
import tk.mybatis.mapper.common.base.select.SelectMapper;

public interface VideoMapper extends Mapper<VideoFileEntity>, MySqlMapper<VideoFileEntity>, SelectMapper<VideoFileEntity> {
}
