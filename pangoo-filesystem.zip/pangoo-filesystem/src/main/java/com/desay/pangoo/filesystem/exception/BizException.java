package com.desay.pangoo.filesystem.exception;

@SuppressWarnings("serial")
public class BizException extends RuntimeException {

	private String message;
	private ExceptionEnum exceptionEnum;
	private Exception exception;

	public BizException(String message) {
		this.message = message;
	}

	public BizException(Exception exception) {
		super();
		this.exception = exception;
	}

	public Exception getException() {
		return this.exception;
	}

	@Override
	public String getMessage() {
		return this.message;
	}

	public ExceptionEnum getExceptionEnum() {
		return this.exceptionEnum;
	}

	public BizException(ExceptionEnum exceptionEnum) {
		super();
		this.exceptionEnum = exceptionEnum;
	}

	public BizException(ExceptionEnum exceptionEnum, String message) {
		super(message);
		this.message = message;
		this.exceptionEnum = exceptionEnum;
	}

	public BizException(ExceptionEnum exceptionEnum, Throwable cause) {
		super(cause);
		this.exceptionEnum = exceptionEnum;
	}

	public BizException(ExceptionEnum exceptionEnum, String message, Throwable cause) {
		super(message, cause);
		this.message = message;
		this.exceptionEnum = exceptionEnum;
	}

	public String getErrorCode() {
		if (exceptionEnum != null) {
			return exceptionEnum.getCode();
		} else {
			return "";
		}
	}

}
