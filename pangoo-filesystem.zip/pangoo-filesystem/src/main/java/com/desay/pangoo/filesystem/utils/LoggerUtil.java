package com.desay.pangoo.filesystem.utils;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import com.desay.pangoo.filesystem.entity.Log;

public class LoggerUtil {
	public static final String LOG_TARGET_TYPE = "targetType";
	public static final String LOG_ACTION = "action";
	public static final String LOG_REMARK = "remark";
	public static final String LOG_OPERATE = "operate";

	public LoggerUtil() {
	}

	public static Log getLog(HttpServletRequest request) {
		// 1.依次获取每个属性信息 userId,operator,action,remark,ip,targetType
		Log log = new Log();
		log.setIp(LoggerUtil.getCliectIp(request));
		log.setOperator("operator");
		log.setUser("");
		log.setRemark("消息发布");
		return log;
	}

	/**
	 * 获取客户端ip地址
	 * 
	 * @param request
	 * @return
	 */
	public static String getCliectIp(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		return ip.equals("0:0:0:0:0:0:0:1") ? "127.0.0.1" : ip;
	}
}
