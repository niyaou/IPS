package com.desay.pangoo.filesystem.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.desay.pangoo.filesystem.entity.FileStorageInformation;

import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.common.MySqlMapper;
import tk.mybatis.mapper.common.base.select.SelectMapper;

/**
 * 
 * @author uidq1343
 *
 */
public interface FileStorageMapper extends  Mapper<FileStorageInformation>,MySqlMapper<FileStorageInformation>,SelectMapper<FileStorageInformation>{

	
	
	public List findByMarket(@Param("market")String market);
}
