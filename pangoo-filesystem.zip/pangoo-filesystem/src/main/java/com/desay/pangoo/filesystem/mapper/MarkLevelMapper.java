package com.desay.pangoo.filesystem.mapper;

import com.desay.pangoo.filesystem.entity.MarkLevel;

import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.common.MySqlMapper;
import tk.mybatis.mapper.common.base.select.SelectMapper;

public interface MarkLevelMapper extends Mapper<MarkLevel>,MySqlMapper<MarkLevel>,SelectMapper<MarkLevel> {

}
