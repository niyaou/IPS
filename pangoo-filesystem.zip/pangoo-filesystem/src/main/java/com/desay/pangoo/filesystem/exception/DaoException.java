package com.desay.pangoo.filesystem.exception;

@SuppressWarnings("serial")
public class DaoException extends Exception {

	private Exception siException;
	private String sql = null;
	
	public DaoException(Exception exception, String sql){
		this.siException = exception;
		this.sql = sql;
		System.err.println("DaoException:"+sql);
	}
	
	@Override
	public synchronized Throwable getCause() {
		// TODO Auto-generated method stub
		return siException.getCause();
	}
	
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return siException.getMessage();
	}
	
	@Override
	public StackTraceElement[] getStackTrace() {
		// TODO Auto-generated method stub
		return siException.getStackTrace();
	}

	public Exception getSiException() {
		return siException;
	}

	public String getSql() {
		return sql;
	}

}
