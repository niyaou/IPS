var Template = {
		/**
		 * templateString	模板字符串
		 * regex			正则表达式
		 * jsonArgs			json数组
		 */
		formatStringWithRegex : function(templateString,regex,jsonArgs){
			var result = new Array();
			if(!$.isArray(jsonArgs)){
				var _jsonArgs = jsonArgs;
				jsonArgs = [];
				jsonArgs.push(_jsonArgs);
			}
			jsonArgs.forEach(function(jsonData){
				var _result = templateString.replace(regex,function(matchs,key){
					return jsonData[key];
				});
				result.push(_result);
			});
			
			return result.join();
		},
		/**
		 * templateString	模板字符串	替换{index}
		 * args				格式化所用参数数组
		 * 此函数也可变种为所需参数在函数内部用arguments获取
		 * arguments虽然有length等属性但并不是数组却是一个object
		 */
		messageFormat : function(templateString,args){
			//console.log(arguments.length);
			if(!templateString){
				return "";
			}
			if(!args){
				return templateString;
			}
			return templateString.replace(/\{(\d+)\}/g,function(matchs,index){
				return args[index];
			});
		},
	};