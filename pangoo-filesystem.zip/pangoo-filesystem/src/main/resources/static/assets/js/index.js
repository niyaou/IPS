var index = {};

index.init = function() {
	// 禁用顶部右键菜单
	  $('body').bind('contextmenu', function() {
	    return false;
	  });
		var loadPags = [];
		loadPags.push({label:"工作总台",url:"seller/test"});
		loadPags.push({label:"事项管理",url:"dzdb/?m=szdb"});
		loadPags.push({label:"消息管理",url:"tc/message/?m=history"});
		loadPags.push({label:"组织文库",url:"tc/knowledge/user/",params:{m:"clibrary"}});
		loadPags.push({label:"小工具",url:"tc_suite/tools.html"});
		loadPags.push({label:"前途云服务",url:"tw/tservices/",params:{urlPage:"pageIn"}});
		loadPags.push({label:"前途云社区",url:"tp/sns/index",params:{urlPage:"pageIn"}});
		
		//------------页签跳转------------
		$("#toTask").bind("click",function(){
			TC.ui.openResource(loadPags[1]);
		});

		$("#toCommunity").bind("click",function(){
			TC.ui.openResource(loadPags[2]);
		});
		var tabConfig = {
				tabDiv : $("#tabs"),
				tabMenu : [ {
					title : "新建事项",
					url : "tc/task/?m=new",
					icon : ""
				}, {
					title : "我的事项",
					url : "tc/task/",
					icon : ""
				}, {
					title : "工作圈子",
					url : "tc/community/${curUser.id }/?m=visit",
					icon : ""
				} ],
				homePage : loadPags[0]
			};
			TC.ui.TCtab.initTab(tabConfig);
};

