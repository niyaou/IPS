"use strict"; // 启用严格模式
(function(w, d) {
    var _TC = w.TC || {};

    //所有取top的地方都应改为TC.topWin
    _TC.topWin = getTopWin(w);
    function getTopWin(win){
      var doamin =win.domain;
      var baseUrl = "/" + win.location.pathname.split("/")[1] + "/";
      var host = win.location.host+"/";
      if(win.parent && win.parent != win){
        try{
            var parentDomain = win.parent.domain;
            var parentBaseUrl = "/" + win.parent.location.pathname.split("/")[1] + "/";
            if(doamin != parentDomain || baseUrl != parentBaseUrl){
              return win;
            }else{
              return getTopWin(win.parent);
            }
        }catch(e){
          return win;
        }
      }else{
        return win;
      }
    }

    /**
     * @method  TC.module
     * @param  {String} className 类的名称
     * @param  {Funtion or Object} fun  回调函数或者对象
     * @deprecated    模块扩展方法 or  获取类的实例  建议在进行扩展的时候在顶层window内进行
     * @example   调用方式  TC.module("tc.ui",function(){this.a="";})   var ui = TC.module("tc.ui");
     * @return {Object}  当前被扩展的对象
     */
    _TC.module = function(className, fun) {
        if (Object.prototype.toString.call(className) === "[object String]") {
            var mclass = _TC;
            var classTemp = className.split(".");
            classTemp.splice(0, 1);
            if (classTemp && (classTemp.length > 0)) {
                for (var i = 0; i < classTemp.length; i++) {
                    if (Object.prototype.toString.call(fun) === "[object Object]") {
                        if (i >= classTemp.length - 1) {
                            mclass[classTemp[i]] = fun;
                            break;

                        }
                    }
                    mclass = mclass[classTemp[i]] || (function() {
                        mclass[classTemp[i]] = {};
                        return mclass[classTemp[i]];
                    }());



                }
            }
            if (Object.prototype.toString.call(fun) === "[object Function]") {
                fun.call(mclass, w, d, _TC);
            }
            return mclass;
        }
    };


    _TC.module('tc', function(win) {

        /**
         * @method  TC.init
         * @param  {Function} fun   系统初始化需要执行的方法
         * @deprecated    系统初始化方法
         * @example   调用方式  TC.init(function(){this.a="";})
         * @return {Object}  TC
         */
        if (win == _TC.topWin) {
            this.init = function(fun) {
            };
        } else {
            this.init = function() {};
        }
        this.topDoc = _TC.topWin.document;
    });
    /**
     * @module  系统配置模块
     * @Extends Object
     * @class  TC.config
     * @deprecated   属于前端框架的常量包装对象
     * @return {[Object]}
     */
    _TC.module('tc.config', function(win, doc, t) {
        /**
         * @attribute 系统的基本路径
         * @readOnly
         * @type {String}
         */
        if (win != _TC.topWin && _TC.topWin.TC) {
            _TC.module("tc.config", _TC.topWin.TC.config);
            return false;
        }
        this.baseUrl = "/" + doc.location.pathname.split("/")[1] + "/";
        this.host =this.baseUrl+ doc.location.host+"/";
        //top window
    });

    /**
     * 前端控制臺
     * @param  {[type]} win [description]
     * @param  {[type]} doc [description]
     * @param  {[type]} t   [description]
     * @return {[type]}     [description]
     */
//    if($.browser.mozilla){
//      try{
//        _TC.module("tc.console", console);
//      }catch(e){
//
//      }
//    }

    /**
     * @module  前台数据缓存模块
     * @Extends Object
     * @class  TC.data
     * @deprecated   前台数据缓存
     * @return {[Object]}
     */
    _TC.module('tc.data', function(win, doc, t) {
        if (win != _TC.topWin &&  _TC.topWin.TC) {
            _TC.module("tc.data", _TC.topWin.TC.data);
            return false;
        }
        this.cache = {};
        this.cache["RescourceTypeEnum"] = {
            OrgCorporation: "10000001",
            OrgDepartment: "10000002",
            OrgPerson: "10000003",
            OrgPost: "10000004",
            OrgLevel: "10000005",
            OrgRole: "10000006",
            OrgRolePurview: "10000007",
            OrgTeam: "10000008",
            OrgBusinessLine: "10000009",
            OrgOutCorporation: "10000010",
            OrgOutPerson: "10000011",
            OrgReciprocalRole: "10000012",
            Task: "10010001",
            SpaceFile: "10020001",
            SpacePartition: "10020002",
            Collaboration: "10030001",
            ColAffair: "10030003",
            URL: "20000000",
            Template: "10040001",
            RichTextPortlet: "10050001",
            Knowledge: "10060001",
            OnlineMessage: "10070001"
        };
        /**
         * @method  TC.data.insert
         * @param  {String} key    缓存标示
         * @param  {Object} value 缓存内容  可以是任意类型
         * @deprecated    添加数据缓存  按照json格式书写，键必须是字符串类型的，值可以是任意类型(不支持null很underfied)
         * @example    TC.data.insert("id","123445");
         * @return {Boolean}       成功true失败false
         */
        this.insert = function(key, value) {
            if (Object.prototype.toString.call(key) === "[object String]") {
                if (value && (key != null)) {
                    this.cache[key] = value;
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        };
        /**
         * @method  TC.data.update
         * @param  {String} key    缓存标示
         * @param  {Object} value 缓存内容  可以是任意类型
         * @deprecated    更新数据缓存  按照json格式书写，键必须是字符串类型的，值可以是任意类型(不支持null很undefined)
         * @example    TC.data.update("id","123445");
         * @return {Boolean}       成功true失败false
         */
        this.update = function(key, value) {
            if (Object.prototype.toString.call(key) === "[object String]") {
                if (value && (key != null)) {
                    this.cache[key] = value;
                }
            }
        };
        /**
         * @method  TC.data.remove
         * @param  {String} key    缓存标示
         * @deprecated    删除数据   键必须是字符串类型
         * @example    TC.data.remove("id");
         * @return {Boolean}       成功true失败false
         */
        this.remove = function(key) {
            var result = false;
            if (Object.prototype.toString.call(key) === "[object String]") {
                this.cache[key] = undefined;
                result = true;
            }
            return result;
        };
        /**
         * @method  TC.data.select
         * @param  {String} key    缓存标示
         * @param  {Funtion} fun  获取数据后的回调方法
         * @deprecated    查询数据   键必须是字符串类型
         * @example    TC.data.select("id",function(obj){这里面执行回调}) 回调参数为被查询的值;
         * @return {Object}       需要的值
         */
        this.select = function(key, fun) {
            if (Object.prototype.toString.call(key) === "[object String]") {
                var result = this.cache[key];
                if (result && Object.prototype.toString.call(fun) === "[object Function]") {
                    fun.call(result, result);
                }
                return result;
            }
        };
    });

    /**
     * @module  ui相关模块
     * @Extends Object
     * @class  TC.ui
     * @deprecated   前端ui的相关操作集合
     * @return {[Object]}
     */
    _TC.module('tc.ui', function(win, doc, t) {

        /**
         * @method   TC.ui.invertSelect
         * @param  {Dom节点} element    父级节点
         * @deprecated   反选一定范围内的所有的复选框
         */
        this.invertSelect = function(element) {
            if (element && (typeof element == "object")) {
                var eles = element.getElementsByTagName("input");
                var len = eles.length;
                for (var i = 0; i < len; i++) {
                    var obj = eles[i];
                    (!obj.type == "checkbox") || (obj.checked = (!obj.checked));
                }
            }
        };
        /**
         * @method   TC.ui.allSelect
         * @param  {Dom节点} element    父级节点
         * @param {Dom节点} clickInput   执行选中动作的节点
         * @deprecated   全选一定范围内的所有的复选框
         */
        this.allSelect = function(element, clickInput) {
            if (element && (typeof element == "object") && clickInput && (typeof clickInput == "object")) {
                var eles = element.getElementsByTagName("input");
                clickInput.onclick = function() {
                    var len = eles.length;
                    for (var i = 0; i < len; i++) {
                        var obj = eles[i];
                        (!obj.type == "checkbox") || (obj.checked = this.checked);
                    }
                };

            }
        };
        /**
         * @method   TC.ui.disable
         * @param  {Dom节点} button    被禁用的按钮
         * @param {number} second   禁用的时间
         * @deprecated   禁用按钮一段时间
         */
        this.disable = function(button, second) {
            if (button && (typeof button == "object") && !isNaN(second)) {
                button.disabled = true;
                var tim = setInterval(function() {
                    button.disabled = false;
                    window.clearInterval(tim);
                }, second * 1000);
            }
        };



        /**
     * @method   TC.ui.drag
     * @param  {Object} config    配置对象
     {
        left : 拖动对象左边的元素 jquery对象,
        control : 拖动元素  jquery元素,
        right : 拖动对象右边的元素 jquery对象,
    };
     * @deprecated   元素拖动  依赖jquery
     */
        this.drag = function(config) {
            var offsetX = 0;
            var isDrag = false;
            var MAX_LEFT_WIDTH = 340;
            var MIN_LEFT_WIDTH = 160;
            var INIT_LEFT = 240;
            var currentLeft = MIN_LEFT_WIDTH;
            var leftWidth = MIN_LEFT_WIDTH;
            if (config) {
                if (config.INIT_LEFT && (config.INIT_LEFT != '')) {
                    INIT_LEFT = config.INIT_LEFT;
                }
                if (config.MAX_LEFT_WIDTH && (config.MAX_LEFT_WIDTH != '')) {
                    MAX_LEFT_WIDTH = config.MAX_LEFT_WIDTH;
                }
                if (config.MIN_LEFT_WIDTH && (config.MIN_LEFT_WIDTH != '')) {
                    MIN_LEFT_WIDTH = config.MIN_LEFT_WIDTH;
                }
            } else {
                return false;
            }
            config.left.css("width", INIT_LEFT + "px");
            config.control.css("left", INIT_LEFT + 10 + "px");
            config.right.css("left", INIT_LEFT + 21 + "px");
            config.control.mousedown(function(evt) {
                var evt = window.event ? window.event : evt;
                if ((evt.which && (evt.which == 1)) || (evt.button && (evt.button == 1))) {
                    isDrag = true;
                    offsetX = evt.clientX;
                    zjhDrag(evt);
                }
                TC.util.stopEvent(evt);
            });
            $(document).mousemove(

                function(evt) {
                    if (isDrag) {
                        var evt = window.event ? window.event : evt;
                        if (evt.clientX > MAX_LEFT_WIDTH) {
                            config.control.css("left", MAX_LEFT_WIDTH + 10 + 'px');
                            config.left.css("width", MAX_LEFT_WIDTH + 'px');
                            config.right.css("left", MAX_LEFT_WIDTH + 21 + "px");
                        } else if (evt.clientX < MIN_LEFT_WIDTH) {
                            config.control.css("left", MIN_LEFT_WIDTH + 10 + 'px');
                            config.left.css("width", MIN_LEFT_WIDTH + 'px');
                            config.right.css("left", MIN_LEFT_WIDTH + 21 + "px");
                        } else {
                            config.control.css("left", evt.clientX - offsetX + currentLeft + 'px');
                            config.left.css("width", evt.clientX - offsetX + leftWidth + 'px');
                            config.right.css("left", evt.clientX - offsetX + currentLeft + 10 + 'px');
                        }
                        TC.util.stopEvent(evt);
                    };
                });
            $(document).mouseup(function(evt) {
                isDrag = false;
                var evt = window.event ? window.event : evt;
                zjhDrag(evt);
                TC.util.stopEvent(evt);
            });

            function zjhDrag(evt) {
                if (evt.clientX > MAX_LEFT_WIDTH) {
                    currentLeft = MAX_LEFT_WIDTH + 10;
                    leftWidth = MAX_LEFT_WIDTH;
                } else if (evt.clientX < MIN_LEFT_WIDTH) {
                    currentLeft = MIN_LEFT_WIDTH + 10;
                    leftWidth = MIN_LEFT_WIDTH;
                } else {
                    currentLeft = parseInt(config.control.css("left"));
                    leftWidth = parseInt(config.left.css("width"));
                }
            }
        };


        /**
         * @method   TC.ui.openTab
         * @param {String} url  tab的链接
         * @param {String} title  tab的显示名称
         * @deprecated   添加页签  依赖jquery
         */
        this.openTab = function(url, title) {
            TC.ui.TCtab.addTab("", title, url, null, null);
        };
        /**
         * @method TC.ui.relocateResource
         * @param  {Object} resObj 配置对象
        {
            url ：资源编码
        }
         * @deprecated 资源刷新
         */
        this.relocateResource = function(resObj) {
          var selected = TC.ui.TCtab.container.selected;
          if(resObj){
            var url = resObj.url;
            var params = resObj.param;
           // TC.ui.TCtab.addTab("", "", url, null, null);
            TC.ui.TCtab.addTab("", "", url, null , null, null, params);
          }
          if(selected != "1"){
            TC.ui.TCtab.removeTab(selected);
          }
        };
        /**
         * @method TC.ui.refResource
         * @param  {Object} resObj 配置对象
        {
            code ：资源编码
        }
         * @deprecated 资源刷新
         */
        this.refResource = function(resObj, flag, refCur) {
          if(resObj){
            var selected = TC.ui.TCtab.container.selected;
            refCur = typeof(refCur) == "undefined" ? true : refCur;
              $(resObj).each(function(index, elem){
                var code = elem.code.split("?");
                  var elements = [];
                  if(elem.id != undefined){
                    elements = TC.ui.TCtab.container.find("iframe[id='mainFrame_"+elem.id+"']");
                  }
                  if(elements.length < 1){
                    elements = TC.ui.TCtab.container.find("iframe[reload^='"+code[0]+"']");
                  }

                  elements.each(function() {
                    if($(this).attr("id").indexOf(selected) != -1){
                      if(refCur){
                        var tempUrl = $(this).attr("src");
                        var orisrc = $(this).attr("orisrc");
                        if(typeof(orisrc) != "undefined"){
                          tempUrl = orisrc;
                        }else{
                          $(this).attr("orisrc", $(this).attr("src"));
                        }
                        if(typeof(resObj.params) != "undefined"){
                          tempUrl += "&" + resObj.params;
                        }

                        //当要刷新的目标url不同时以新url刷新iframe
                        if(resObj.diUrl && resObj.diUrl != tempUrl){
                          tempUrl = resObj.diUrl;
                          $(this).attr("orisrc",resObj.diUrl);
                        }

                        $(this).attr("src", tempUrl);
                      }
                    }else if(!flag){
                      $(this).attr("needReload", true);
                    }
                    });
              });
          } else{
            TC.ui.TCtab.container.find("iframe").each(function() {
                $(this).attr("src", $(this).attr("src"));
                });
          }
        };
        /**
         * @method   TC.ui.openResource
         * @param  {Object} resObj 配置对象
        {
            type ：资源类型 在数据缓存内
            param：参数对象
            resId：资源id
        }
         * @deprecated   资源查看
         */
        this.openResource = function(resObj) {
          var url = resObj.url;
          var resId = resObj.id;
          var label = resObj.label ? resObj.label : "";
          var params = resObj.params;
          // 消息弹出提醒打开或社区时获取链接
          if(resObj.from && (resObj.from == "msg" || resObj.from == "com")){
                var type = resObj.type;
                if (typeof(type) != "number") {
                    type = parseInt(type);
                }
                var UrlParameter = [];
                if (resObj && resObj.params) {
                    for (var item in resObj.params) {
                        if (Object.prototype.toString.call(params[item]) === "[object String]") {
                            UrlParameter.push(item.toString() + '=' + params[item]);
                        }
                    }
                }
                resId = resObj.id || resObj.resId;
                var url = "";
                if(UrlParameter.length != 0){
                  params = UrlParameter.join("&");
                }
          }
          TC.ui.TCtab.addTab(resId, label, url, "curSelect", null, null, params);
        };
        /**
         * @method    TC.ui.createResource
         * @param  {number} resType 资源类型
         * @param  {Object} param   参数对象
         * @return {[type]}         [description]
         * @deprecated  资源新建
         */
        this.createResource = function(resType, param) {
            var title = "";
            var url = "";
            var UrlParameter = [];
            if (param) {
                for (var item in param) {
                    if (Object.prototype.toString.call(param[item]) === "[object String]") {
                        UrlParameter.push(item.toString() + '=' + param[item]);
                    }

                }
            }
            switch (resType) {
                case 10010001:
                    url = "tc/task/?m=new";
                    break;
                case 10030001:
                    //url = "col.addColIndex.do";
                    break;
            }
            // url += '?' + UrlParameter.join("&");
            TC.ui.TCtab.addTab("", title, url, "curSelect", null, null, UrlParameter.join("&"));
        };
        /**
         * @method 更换系统皮肤
         * @param  {[type]} skinName 皮肤名称
         * @return {[type]}          [description]
         */
        this.skin = function(skinName) {
            var skinAndText = {};
            skinAndText["tec"] = "#888888";
            skinAndText["gov"] = "#FFFFFF";
            skinAndText["eco"] = "#336699";
            skinAndText["cul"] = "#000000";
            skinAndText["cloud"] = "#FFFFFF";
            skinAndText["sport"] = "#000000";
            skinAndText["afternoon"] = "#000000";
            skinAndText["city"] = "#FFFFFF";
            if (skinName && Object.prototype.toString.call(skinName) === "[object String]") {
                var doc = _TC.topDoc;
                $("#ToolBar", doc).css("background", "url(" + TC.config.baseUrl + "/tc_ttp/style/" + skinName + "/images/topBg.png) top left repeat-x");
                $("#main_left", doc).css("background", "url(" + TC.config.baseUrl + "/tc_ttp/style/" + skinName + "/images/leftBg.png) top right ");
                $("#main_left", doc).css("background-position", "0 -67px");
                $("#top_Text", doc).css("color", skinAndText[skinName]);
            }
        };

    });



    _TC.module('tc.ui.TCtab', function(win, doc, t) {
        if (win != _TC.topWin &&  _TC.topWin.TC) {
            _TC.module("tc.ui.TCtab", _TC.topWin.TC.ui.TCtab);
            return false;
        }

        this.container;
        this.counter = 1;
        this.action;

        /**
         * @method   TC.ui.TCtab.addTab
         * @param {String} tabId  tab标示符
         * @param {String} label  tab的显示名称
         * @param {String} url    tab的请求路径
         * @param {number} index  执行当前方法后需要打开的tab
         * @param {boolean} reload  打开当前tab是否刷新 参数  true为要刷新false为不刷新
         * @param {String} from  动作来源
         * @deprecated   添加页签  依赖jquery
         */
        this.addTab = function(tabId, label, url, index, reload, from, params) {
            if(this.counter > this.allowMaxTabCount){
        	top.$.dialog.alert("您打开的窗口超过最大限制，请先关闭一些窗口<br>");
        	return ;
           }
          // 判断url
          if(!url){
            throw new Error("url can not null!");
            return;
          }
          var tempUrl = url;
          if(params){
            var linkchar = tempUrl.indexOf("?") == -1 ? "?":"&";
            if(Object.prototype.toString.call(params) == "[object String]"){
              tempUrl += (linkchar + params);
            } else if (typeof params == "object") {
              tempUrl += (linkchar + decodeURIComponent($.param(params, false)));
            }
          }
          // 用于标识页签
          var code = url.split("?")[0].replace(new RegExp("\\/", "g"), "_");
          reload = code;
          // yangc 取消ID判断,id直接与url一起判定
          // if (tabId === null || (tabId == "")) {
          if (true) {
            tabId = url.replace(new RegExp("\\.", "g"), "_")
            .replace(new RegExp("\\?", "g"), "_")
            .replace(new RegExp("\\=", "g"), "_")
            .replace(new RegExp("\\/", "g"), "_")
            .replace(new RegExp("\\&", "g"), "_")
            .replace(new RegExp("\\@", "g"), "_");
          }
          var defaultLabel = label;
          // var isNull = label == "";
          var isNull = true;
          if(isNull){
            label = "新标签页";
          } else{
            label=label.replace("<","&lt;").replace(">","&gt;");// 将标题文字中的"<"与">"替换
          }
            var newTabId = tabId;
            if (newTabId === null || (newTabId == "")) {
                newTabId = "new-tab-" + this.counter;
            } else {
                if ($("#" + newTabId).length > 0) {
                  var flag = false;
                  var param = {code:url.replace(new RegExp("\\/", "g"), "_"),"params":params};
                  param.id = newTabId;
                  if(from && (from == "menu" || from == "msg")){
                    flag = true;
                  }
                  this.container.tabs("select", newTabId);
                  param.diUrl = tempUrl;//设置本次要刷新的目的url
                  TC.ui.refResource(param, flag);
                  return;
                }
            }
            var selected = this.container.tabs('option', 'selected');
            var newTab = [];
            newTab.push('<div id="' + newTabId + '" style="position:absolute;top:28px; z-index:0;bottom:0;left:0;right:0; margin:0; padding:0;border-left:none;border-right:1px solid #b5b5b5;border-top:1px solid #b5b5b5;border-bottom:1px solid #b5b5b5; background:#fff">');
            newTab.push('<div id="loading_' + newTabId + '" class="loadingDiv">');
            newTab.push('<img src="/assets/images/loading.gif" style=" position:absolute;left:50%;top:50%">');
            newTab.push('</div>');
            newTab.push('<iframe id="mainFrame_' + newTabId + '" code="' + code + '" reload="' + reload + '" name="reload" src="" style="width:100%;" frameborder="0"  scrolling="yes" marginheight="0"></iframe>');
            newTab.push("</div>");
            this.container.append(newTab.join(""));
            var tabWidth = TC.ui.TCtab.resetWidth(1);
            if (index == 'curSelect') {
                this.container.tabs("add", "#" + newTabId, label, selected + 1, tabWidth);
                this.container.tabs("select", selected + 1);
            } else {
                this.container.tabs("add", "#" + newTabId, label, undefined, tabWidth);
                this.container.tabs("select", this.counter);
            }
            this.container.find('#mainFrame_' + newTabId).css("visibility", "hidden");
            this.container.find('#loading_' + newTabId).css('display', 'block');
            // 加载
            this.container.find('#mainFrame_' + newTabId).attr('src', tempUrl).css("height","100%");
            var currentTab = this.container.find("a[href='#" + newTabId + "'] span");
            currentTab.attr("defaultLabel",defaultLabel);
            var _this = this;
            this.container.find('#mainFrame_' + newTabId).load(function() { //加载等待..
                $(this).prev().css('display', 'none');
                $(this).css("visibility", "visible");
                var title = $(this).contents().find("title").html();
                var titleAll = title.replace(new RegExp("&lt;", "g"), "<").replace(new RegExp("&gt;", "g"), ">");
                var defaultLabel = currentTab.attr("defaultLabel");
                // if(label == "新标签页"){
                if(!title || $.trim(title).length <= 0){
                  title = defaultLabel;
                }
                var showTitle = title;
                var valueSize = textSize("12px", showTitle);
                while (currentTab.parent().length != 0 && valueSize.width > currentTab.parent().outerWidth() - 22) {
                showTitle = showTitle.substring(0, showTitle.length - 1);
                  valueSize = textSize("12px", showTitle);
                }
                if (showTitle != title) {
                  title = showTitle + "...";
                }
                currentTab.parent().parent().attr("title", titleAll.replace(/<br \/>/g,"").replace(/[\r\n]/g, ""));
                if(title.indexOf("<") != -1 || title.indexOf("<") != -1){
                  title = title.htmlEncode();
                }
                if(_this.container.find("a[href='#" + newTabId + "'] span").length < 1){
                  //新增页签时前一个页签中的span会被组件去掉
                  currentTab = _this.container.find("a[href='#" + newTabId + "']");
                }
                currentTab.html(title);
            });
            this.counter++;
            this.container.find("#tabLabel").find("li:not(:first-child)").smartMenu(this.action, {
              name: "tabMenu"
            });
        };
        this.resetWidth = function(add) { //add=1增加时，add=0减少时
            var tabNum = this.container.find("ul").find("li").length;
            if (tabNum < 5) {
                tabNum = 5;
            } else {
                if (add == 1) {
                    tabNum = tabNum + 1;
                }
            }
            var tabWidth = parseInt((this.container.parent().outerWidth() - 90) / tabNum) - 48; //调整240可以改变预留右侧的宽度
            this.container.find("ul").find("li").each(function() {
                $(this).find("a").css("width", tabWidth);
                var tempValue = $(this).attr("title"); //完整标题
                if(tempValue){
                  tempValue=tempValue.replace("&lt;","<").replace("&gt;",">");//将title中的"&lt;"与"&gt;"替换
                }
                var valueSize = textSize("12px", $(this).find("a").text()); //当前显示标题
                while ($(this).find("a").length != 0 && typeof(tempValue) != "undefined" && valueSize.width > $(this).find("a").outerWidth() - 22) {
                    tempValue = tempValue.substring(0, tempValue.length - 1);
                    valueSize = textSize("12px", tempValue);
                }
                var valueSize = textSize("12px", tempValue); //当前显示标题
                while ($(this).find("a").length != 0 && typeof(tempValue) != "undefined" && valueSize.width > $(this).find("a").outerWidth() - 22) {
                    tempValue = tempValue.substring(0, tempValue.length - 1);
                    valueSize = textSize("12px", tempValue);
                }
                if (tempValue != $(this).attr("title")) {
                    tempValue = tempValue + "...";
                }
                if(tempValue != "新标签页"){
                  $(this).find("a").text(tempValue);
                }
            });
            return tabWidth;
        };
        this.removeTab = function(index) {
            this.container.tabs("remove", index);
            TC.ui.TCtab.resetWidth(0);
//            TC.ui.TCtab.rePosAddButton(0);
            this.counter--;
        };
        this.initTab = function(config) {
            var container = config.tabDiv;
            var homePage = config.homePage;
            var tabMenu = config.tabMenu;
            /**
            var setMenu = config.setMenu;
            var spaceMenu = config.spaceMenu;
            var setSpace = config.setSpace;*/
            TC.ui.TCtab.container = container;
            TC.ui.TCtab.counter = 1;
            //设置允许打开窗口的最大个数量
            TC.ui.TCtab.allowMaxTabCount = 19;
            TC.ui.TCtab.action = [
                [{
                    text: "刷新页签",
                    func: function() {
                        var li = $(this);
                        var index = TC.ui.TCtab.container.find("li").index(li.get(0));
                        var ref = $(TC.ui.TCtab.container.find("iframe[name='reload']")[index]);
                        ref.attr("src", ref.attr("src"));
                    }
                },{
                    text: "关闭页签",
                    func: function() {
                        var li = $(this);
                        var index = TC.ui.TCtab.container.find("li").index(li.get(0));
                        TC.ui.TCtab.container.tabs("remove", index);
                        TC.ui.TCtab.resetWidth(0);
//                        TC.ui.TCtab.rePosAddButton(0);
                        TC.ui.TCtab.counter--;
                    }
                }, {
                    text: "关闭其他页签",
                    func: function() {
                        var curLi = $(this);
                        TC.ui.TCtab.container.find("li:not(:first-child)").each(function(e) {
                            if ($(this).get(0) != curLi.get(0)) {
                                var li = $(this);
                                var index = TC.ui.TCtab.container.find("li").index(li.get(0));
                                TC.ui.TCtab.container.tabs("remove", index);
                                TC.ui.TCtab.resetWidth(0);
//                                TC.ui.TCtab.rePosAddButton(0);
                                TC.ui.TCtab.counter--;
                            }
                        });
                    }
                }, {
                    text: "关闭全部页签",
                    func: function() {
                        TC.ui.TCtab.container.find("li:not(:first-child)").each(function(e) {
                            var li = $(this);
                            var index = TC.ui.TCtab.container.find("li").index(li.get(0));
                            TC.ui.TCtab.container.tabs("remove", index);
                            TC.ui.TCtab.resetWidth(0);
//                            TC.ui.TCtab.rePosAddButton(0);
                            TC.ui.TCtab.counter--;
                        });
                    }
                }, {
                    text: "关闭左侧页签",
                    func: function() {
                        var curLi = $(this);
                        TC.ui.TCtab.container.find("li:not(:first-child)").each(function(e) {
                            if ($(this).get(0) != curLi.get(0)) {
                                var li = $(this);
                                var index = TC.ui.TCtab.container.find("li").index(li.get(0));
                                TC.ui.TCtab.container.tabs("remove", index);
                                TC.ui.TCtab.resetWidth(0);
//                                TC.ui.TCtab.rePosAddButton(0);
                                TC.ui.TCtab.counter--;
                            } else {
                                return false;
                            }
                        });
                    }
                }, {
                    text: "关闭右侧页签",
                    func: function() {
                        var curLi = $(this);
                        $(TC.ui.TCtab.container.find("li:not(:first-child)").toArray().reverse()).each(function(i) {
                            if ($(this).get(0) != curLi.get(0)) {
                                var li = $(this);
                                var index = TC.ui.TCtab.container.find("li").index(li.get(0));
                                TC.ui.TCtab.container.tabs("remove", index);
                                TC.ui.TCtab.resetWidth(0);
//                                TC.ui.TCtab.rePosAddButton(0);
                                TC.ui.TCtab.counter--;
                            } else {
                                return false;
                            }
                        });
                    }
                }]
            ];
            //---------------------------------构建页签区域
            if(typeof(homePage) != "undefined"){
              var tabUL = [];
              tabUL.push("<ul id=\"tabLabel\" style=\"position:relative;z-index:1; border:none; margin-left:-4px;\">");
              tabUL.push("<li><a id=\"indexText\" style=\"text-align:left;\" href=\"#tabs-1\">" + homePage.label + "</a>");
              tabUL.push("<div id=\"indexSet\" title=\"切换首页空间\">&nbsp;</div>");
              tabUL.push("</li></ul>");
              tabUL.push("<div id=\"tabs-1\" style=\"border-top:1px solid #b5b5b5;border-right:1px solid #b5b5b5;border-bottom:1px solid #b5b5b5;border-left:none;margin:0;padding:0; overflow:hidden; height:100%; background:#fff;\" >");
              tabUL.push("<div id=\"space1\" class=\"curSpace\" style=\"position:absolute;width:100%;top:30px;bottom:0;\">");
              tabUL.push("<iframe id=\"mainFrame\" name=\"reload\"  src=\"" + homePage.url + "\" style=\"height:100%; width:100%;\" frameborder=\"0\" scrolling=\"auto\" marginheight=\"0\"></iframe>");
              tabUL.push("</div></div>");
              container.html(tabUL.join(""));
            }
            if(tabMenu && (tabMenu.length > 0)){
//                var tabAddBtn = [];
//                tabAddBtn.push("<div id=\"addTabButton\" class=\"addTabButton\"  title=\"快速打开\" style=\"left: 232px;\"> </div>");
//                container.after(tabAddBtn.join(""));
//                bindEventForAddTabButton($("#addTabButton"));//"+"号按钮添加事件 函数在tc_suite/js/index.js中
            }
            //页签添加事件
            container.tabs({
                add: addEventHandler,
                ajaxOptions: {
                    async: false
                },
                select: function(event, ui) {
                  container.selected = $(ui.tab).attr("href").replace("#", "");
                  container.find($(ui.tab).attr("href")).find("iframe[needReload='true']").each(function() {
                    $(this).attr("src", $(this).attr("src"));
                    $(this).attr("needReload", false);
                  });
                },
            });
            var loadPags = [];
            function addEventHandler(event, ui) {
                var li = $(ui.tab).parent();
                $('<img style="padding-top:5px" title="关闭" src="assets/images/tab_close.png"/>') //关闭按钮
                .appendTo(li).hover(function() {
                    var img = $(this);
                    img.attr('src', 'assets/images/tab_close_on.png');
                }, function() {
                    var img = $(this);
                    img.attr('src', 'assets/images/tab_close.png');
                }).click(function() { //关闭按钮,关闭事件绑定
                    var li = $(ui.tab).parent();
                    var ultab = li.parent();
                    var content = ultab.next().next();
                    var iframe = content[0].childNodes[1];
                    if ('onExit' in iframe.contentWindow &&  typeof iframe.contentWindow.onExit === "function"){
                        iframe.contentWindow.onExit();
                    }
                    var index = container.find("li").index(li.get(0));
                    container.tabs("remove", index);
                    TC.ui.TCtab.resetWidth(0);
//                    TC.ui.TCtab.rePosAddButton(0);
                    TC.ui.TCtab.counter--;
                });
                $(ui.tab).dblclick(function() { //双击关闭事件绑定
                    var li = $(ui.tab).parent();
                    var index = container.find("li").index(li.get(0));
                    container.tabs("remove", index);
                    TC.ui.TCtab.resetWidth(0);
//                    TC.ui.TCtab.rePosAddButton(0);
                    TC.ui.TCtab.counter--;
                });
                $(li).find("img").load(function(){
//                  TC.ui.TCtab.rePosAddButton(1);
                });
            }
            TC.ui.TCtab.resetWidth(1);
//            TC.ui.TCtab.rePosAddButton();
            //container.find("#tabs-1").height($(window).height() - 93 - 20);
        };
    });


    /**
     * @module  工具方法
     * @Extends Object
     * @class  TC.util
     * @deprecated    前端扩展方法
     * @return {[Object]}
     */
    _TC.module('tc.util', function(win, doc, t) {

        /**
         * 表单元素验证  <input  id="" name="" rule=""/>
         * @param  {Object} formDomObject 待验证的Form对象
         * @param  {funtion} callback  验证通过的回调方法
         * @return {[type]}  返回true表示验证通过
         */
        this.validate = function(formDomObject, callback) {
            var result = {};
            var kvArray = {};
            var ruleArray = {};
            ruleArray['email'] = "";
            ruleArray['noNull'] = "";
            if (!formDomObject || formDomObject.length || formDomObject.length < 1) {
                return false;
            }
            if (formDomObject.is('form')) {
                formDomObject.find('input,textare').each(function(index, el) {
                    kvArray[$(el).attr('id')] = $(el).val();
                    if (ruleArray[$(el).attr('rule')]) {
                        result[$(el).attr('id')] = $(el).val().match(ruleArray[$(el).attr('rule')], "g");
                    } else {
                      if(undefined != TC.console){
                        TC.console.log($(el).attr('id') + "验证规则书写不正确！");
                      }
                    }

                });
            } else {
                kvArray[$(formDomObject).attr('id')] = $(formDomObject).val();
                if (ruleArray[$(formDomObject).attr('rule')]) {
                    result[$(formDomObject).attr('id')] = $(formDomObject).val().match(ruleArray[$(formDomObject).attr('rule')], "g");
                } else {
                  if(undefined != TC.console){
                    TC.console.log($(formDomObject).attr('id') + "验证规则书写不正确！");
                  }
                }
            }
            if (Object.prototype.toString.call(callback) == "[object  Funtion]") {
                callback.call(result, kvArray);
            } else {
                return result;
            }
        };

        /**
         * @method  TC.util.stopEvent
         * @param {Object} evt    事件
         * @example    TODO
         * @deprecated    阻止默认事件的执行
         */
        this.stopEvent = function(evt) {
            var event = window.event ? window.event : evt;
            if (event.preventDefault) {
                event.preventDefault();
                event.stopPropagation();
            } else {
                event.returnValue = false;
            }

        };
        /**
         * @method  TC.util.escapeStringToHTML
         * @param {String} str    待被编码的字符串
         * @example    TODO
         * @deprecated    去除html标签内容
         */

        this.escapeStringToHTML = function(str) {
            if (!str) {
                return "";
            }
            str = str.replace(/&/g, "&amp;");
            str = str.replace(/</g, "&lt;");
            str = str.replace(/>/g, "&gt;");
            str = str.replace(/\r/g, "<br>");
            str = str.replace(/\'/g, "&#039;");
            str = str.replace(/"/g, "&#034;");
            return str;
        };


        /**
         * @method  TC.util.enterEvent
         * @param {Object} htmlDomNode    待绑定的DoM节点
         * @param {Funtion} fn    回车事件的内容
         * @example    TODO
         * @deprecated    给html节点绑定回车事件
         */
        this.enterEvent = function(htmlDomNode, fn) {
            if (!htmlDomNode || (htmlDomNode.nodeType != 1)) {
                return false;
            }
            if (fn) {
                if (htmlDomNode.attachEvent) {
                    htmlDomNode.attachEvent('onkeydown', function(e) {

                        if (e.keyCode == 13) {
                            e.preventDefault();
                            fn.call(htmlDomNode);
                        }
                    });
                } else {
                    htmlDomNode.addEventListener("keydown", function(e) {

                        if (e.keyCode == 13) {
                            e.preventDefault();
                            fn.call(htmlDomNode);
                        }
                    }, false);
                    htmlDomNode.addEventListener("keypress", function(e) {

                        if (e.keyCode == 13) {
                            e.preventDefault();
                            fn.call(htmlDomNode);
                        }
                    }, false);


                }


            }
        };
        /**
         * @method  TC.util.getUrlParameter
         * @param {String} key     标示符
         * @example    TODO
         * @deprecated    获取url的参数内推
         */
        this.getUrlParameter = function(key) {
            var queryString = document.location.search;
            if (queryString) {
                queryString = queryString.substring(1);
                var params = queryString.split("&");
                for (var i = 0; i < params.length; i++) {
                    var items = params[i].split("=");
                    if (key == items[0]) {
                        return items[1];
                    }
                }

            }
        };

        /**
         * @method  TC.util.encodeURIat
         * @param {String} inputStr     待编码的字符串
         * @example    TODO
         * @deprecated    对字符串进行编码
         */
        this.encodeURIat = function(inputStr) {
            if ((typeof inputStr) !== "string") {
                return "";
            }
            inputStr = encodeURI(inputStr);
            var reg = /&|\/|\+|\?|\s|%|#|=/g;
            if (reg.test(inputStr)) {
                // inputStr = inputStr.replace( /(%)/g, "%25");
                inputStr = inputStr.replace(/(\/)/g, "%2F");
                inputStr = inputStr.replace(/(&)/g, "%26");
                inputStr = inputStr.replace(/(\+)/g, "%2B");
                inputStr = inputStr.replace(/(\?)/g, "%3F");
                inputStr = inputStr.replace(/(#)/g, "%23");
                // inputStr = inputStr.replace( /(\s)/g, "%20");
                inputStr = inputStr.replace(/(=)/g, "%3D");
            }
            return inputStr;
        };
        /**
         * @method  TC.util.parseDate
         * @param {String} dateStr     待转换的字符串
         * @example    TODO
         * @deprecated    将字符串转换为时间对象  格式只支持yyyy-mm-dd
         */
        this.parseDate = function(dateStr) {
            if (dateStr && (dateStr.constructor == Object)) {
                dateStr = dateStr.toString()
            }
            var ds = String.prototype.toString.split.call(dateStr, "-");
            var y = parseInt(ds[0], 10);
            var m = parseInt(ds[1], 10) - 1;
            var d = parseInt(ds[2], 10);

            return new Date(y, m, d);
        };
        /**
         * @method  TC.util.formatDate
         * @param {Date} dateStr     待格式化的时间对象
         * @example    TODO
         * @deprecated    格式化时间对象  格式只支持yyyy-mm-dd
         */
        this.formatDate = function(dateStr) {
            if (dateStr && (dateStr.constructor == Object)) {
                dateStr = dateStr.toString()
            }
            var d = String.prototype.split.call(dateStr, "-");
            var month = parseInt(d[1], 10);
            var date = parseInt(d[2], 10);

            return d[0] + "-" + (month < 10 ? "0" + month : month) + "-" + (date < 10 ? "0" + date : date);
        };
        /**
         * @method  TC.util.compareDate
         * @param {String} dateStr1    时间字符串1
         * @param {String} dateStr2    时间字符串2
         * @example    TODO
         * @deprecated    比较时间大小   前者比后者大返回值大于0相反则小于0
         */
        this.compareDate = function(dateStr1, dateStr2) {
            return Date.parse(dateStr1.replace(/\-/g, '/')) - Date.parse(dateStr2.replace(/\-/g, '/'));
        };
        /**
         * @method  TC.util.postFormData
         * @param {String} dotype    提交类型  ajax或者form
         * @param {Jquery Object} form    待提交的form表单对象
         * @param {Function} callback     提交成功的的回调方法
         * @example    TODO
         * @deprecated    数据提交
         */
        this.postFormData = function(dotype, form, callback,repeatSubmit) {
            var url = form.attr("action");
            var type = form.attr("method");
            if ((dotype != null) && (dotype == "ajax")) {
              var options = {
                        type: type,
                        url: url,
                        data: form.serialize(),
                        dataType: "JSON",
                        success: callback,
                        error: function() {
                            $.dialog.alert("提交失败");
                        }
              };
                if(repeatSubmit){
                  options.repeatSubmit=repeatSubmit;
                }
               return $.ajax(options);
            } else {
               return form.submit();
            }
        };
        /**
         * @method  TC.util.vilValueIsExist
         * @param {String} key    待验证的字段
         * @param {String} value    待验证字段的目前的值
         * @param {String} url      请求的url
         * @param {Function} fun     验证后的方法
         * @example    TODO
         * @deprecated    字段非空验证
         */
        this.vilValueIsExist = function(key, value, url, fun) {
            if (key && value && url) {
                $.ajax({
                    type: "post",
                    url: url,
                    data: "fielName=" + key + "&fielValue=" + value,
                    dataType: "JSON",
                    success: function(data) {
                        fun(data);
                    },
                    error: function() {
                        $.dialog.alert("程序异常，请联系系统管理员！");
                    }
                });
            }
        };
        /**
         * @method  TC.util.cutstr
         * @param {String} str    待截取的字符串
         * @param {number} len    截取的长度
         * @example    TODO
         * @deprecated    截取字符串
         */
        this.cutstr = function(str, len) {
            var str_length = 0;
            var str_len = 0;
            var str_cut = new String();
            str_len = str.length;
            for (var i = 0; i < str_len; i++) {
                var a = str.charAt(i);
                str_length++;
                if (escape(a).length > 4) {
                    //中文字符的长度经编码之后大于4
                    str_length++;
                }
                str_cut = str_cut.concat(a);
                if (str_length >= len) {
                    str_cut = str_cut.concat("...");
                    return str_cut;
                }
            }
            //如果给定字符串小于指定长度，则返回源字符串；
            if (str_length < len) {
                return str;
            }
        };


        /**
         * @method  TC.util.postAjaxData
         * @param {String} url    提交的url
         * @param {Object} json    待提交的form表单对象
         * @param {Function} callback     提交成功的的回调方法
         * @param {Boolean} async     是否同步
         * @param {String} method     提交方式
         * @example    TODO
         * @deprecated    数据提交   依赖jquery
         */
        this.postAjaxData = function(url, json, callback, async, method) {
            var data;
            var isAsync = true;
            if (typeof json == "string") {
                data = json;
            } else if (typeof json == "object") {
                data = decodeURIComponent($.param(json, false));
            } else {
                data = "";
            }
            if (typeof(async) != "undefined") {
                isAsync = async;
            }
            var commitType = "post";
            if (typeof(method) != "undefined") {
              commitType = method;
            }
            $.ajax({
                type: commitType,
                url: url,
                data: data,
                async: isAsync,
                dataType: "json",
                success: callback,
                error: function() {
                	$("#loading").hide();
                    $.dialog.alert("提交失败");
                }
            });
        }; /** ************************************************************************ */
        /**
         * @method  TC.util.removeHTMLTag
         * @param {String} str    待编码的字符串
         * @example    TODO
         * @deprecated    编码带有html标签内容的字符串
         */
        this.removeHTMLTag = function(str) {
            str = str.replace(/<\/?[^>]*>/g, ''); //去除HTML tag
            str = str.replace(/[ | ]*\n/g, '\n'); //去除行尾空白
            //str = str.replace(/\n[\s| | ]*\r/g,'\n'); //去除多余空行
            str = str.replace(/&nbsp;/ig, ''); //去掉&nbsp;
            return str;
        };
        /**
         * @method  TC.util.random
         * @param {number} min    范围的最小值
         * @param {number} max    范围的最大值
         * @example    TODO
         * @deprecated    获取随机数
         */
        this.random = function(min, max) {
            return Math.floor(Math.random() * (max - min + 1) + min);
        };
        /**
         * @method  TC.util.clone
         * @param {Object} o    待被克隆的对象
         * @example    TODO
         * @deprecated    克隆的对象
         */
        this.clone = function(o) {
            /**
             * @ignore
             */
            var tempClass = function() {};
            tempClass.prototype = o;

            // 返回新克隆的对象
            return (new tempClass());
        };


    });
    /**
     * @module  cookie扩展模块
     * @Extends Object
     * @class  TC.cookie
     * @deprecated   cookie的相关扩展
     * @return {[Object]}
     */
    _TC.module('tc.cookie', function(win, doc, t) {
        if (win != _TC.topWin &&  _TC.topWin.TC) {
            _TC.module("tc.cookie", _TC.topWin.TC.cookie);
            return false;
        }
        /**
         * @method  TC.cookie.select
         * @param  {String} name    cookie标示
         * @deprecated    查询cookie   键必须是字符串类型
         * @example    TC.data.select("id");
         * @return {Object}       需要的值
         */
        this.select = function(name) {
            var cookieValue = null;
            if (_TC.topWin.document.cookie && (_TC.topWin.document.cookie != '')) {
                var cookies = document.cookie.split(';');
                for (var i = 0; i < cookies.length; i++) {
                    var cookie = $.trim(cookies[i]);
                    if (cookie.substring(0, name.length + 1) == (name + '=')) {
                        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                        break;
                    } else {
                        //
                    }
                }
            } else {
                //
            }
            return cookieValue;
        };
        /**
         * @method  TC.cookie.add
         * @param {String} name   cookie名称
         * @param {Object} value   cookie值
         * @param {Object} options 参数
         * @example    TODO
         * @deprecated    添加cookie
         */
        this.add = function(name, value, options) {
            if (typeof value != 'undefined') {
                options = options || {};
                if (value === null) {
                    value = '';
                    options.expires = -1;
                }
                var expires = '';
                if (options.expires && ((typeof options.expires == 'number') || options.expires.toUTCString)) {
                    var date;
                    if (typeof options.expires == 'number') {
                        date = new Date();
                        date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
                    } else {
                        date = options.expires;
                    }
                    expires = '; expires=' + date.toUTCString();
                }
                var path = options.path ? '; path=' + options.path : '';
                var domain = options.domain ? '; domain=' + options.domain : '';
                var secure = options.secure ? '; secure' : '';
                _TC.topWin.document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
            }

        };
        /**
         * @method  TC.cookie.del
         * @param {String} key   cookie名称
         * @example    TODO
         * @deprecated    删除cookie
         */
        this.del = function(key) {
            if (!key || (key == '')) {
                return;
            }
            var _coo = this.select(key);
            if (!_coo || (_coo == '')) {
                return;
            }
            var exp = new Date();
            exp.setTime(exp.getTime() - 1);
            _TC.topWin.document.cookie = key + " = " + _coo + ";expires = " + exp.toGMTString();

        };
        /**
         * @method  TC.cookie.update
         * @param {String} name   cookie名称
         * @param {Object} value   cookie值
         * @param {Object} options 参数
         * @example    TODO
         * @deprecated    更新cookie
         */
        this.update = function(name, value, options) {
            TC.cookie.add(name, value, options);
        };

    });
    /**
     * @module  正文相关
     * @Extends Object
     * @class  TC.editor
     * @deprecated   editor的相关扩展
     * @return {[Object]}
     */
    _TC.module('tc.editor', function(win) {
        if (win != _TC.topWin &&  _TC.topWin.TC) {
            _TC.module("tc.editor", _TC.topWin.TC.editor);
            return false;
        }
        /**
         * @method    TC.editor.editTxt
         * @deprecated  编辑正文
         * @param {Object} contentId 正文ID
         * @param {Object} rType 资源类型
         * @param {Object} rId 资源ID
         * @param {Funtion} callback 发送后的回调方法
         * @param {Object} openType edit-编辑正文，print-打印正文
         * @return
         */
       /* this.editTxt = function(contentId, rType, rId, callback, openType) {
          var url = TC.config.baseUrl + "tc/content/?m=dialog&contentId="+contentId+"&rType="+rType+"&rId="+rId+"&openType="+openType;

          if(typeof(contentId) == "undefined" || contentId == "undefined" || contentId == ""){
            url = TC.config.baseUrl + "tc/content/?m=dialog&contentModule=2&rType=" + rType + "&rId=" + rId;

          }
          var option = {
           id: "editTxt",
           title: "修改正文",
           max: true,
           min: false,
           xButton: false,
           width: "800px",
           height: "500px",
           content: "url:" + url + "&contentModule=1",
           lock: true,
           parent: this,
           cancel: true
          };
          if(openType == "print"){
            option = $.extend(option, {title: "打印正文"});
          } else{
            option = $.extend(option, {ok: function() {
              var funcTemp = this.content.contentFrame.commitContent;
              if(typeof(funcTemp) == "undefined"){
                funcTemp = this.content.contentFrame.contentWindow.commitContent;
              }
              funcTemp(function(result) {
                if (typeof(callback) == "function") {
                    callback(result);
                }
                editDialog.close();
              });
              return false;
            },});
          }
          var editDialog = $.dialog(option);
        };*/
    });

    /**
     * @module  原型扩展
     * @Extends Date
     * @deprecated   Date相关的扩展  支持年月日时分秒
     * @method    格式化时间对象
     * @param {String} format 格式
     * @example
     * @return {[Object]}
     */
    Date.prototype.format = function(format) {
        var o = {
            "M+": this.getMonth() + 1,
            //month
            "d+": this.getDate(),
            //day
            "h+": this.getHours(),
            //hour
            "m+": this.getMinutes(),
            //minute
            "s+": this.getSeconds(),
            //second
            "q+": Math.floor((this.getMonth() + 3) / 3),
            //quarter
            "S": this.getMilliseconds() //millisecond
        }
        if (/(y+)/.test(format)) {
            format = format.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        }
        for (var k in o)
            if (new RegExp("(" + k + ")").test(format)) {
                format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
            }
        return format;
    }
    Array.prototype.isContain = function(key) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] == key) {
                return true;
            }
        };
    };

    w.TC = _TC;
})(window, document);