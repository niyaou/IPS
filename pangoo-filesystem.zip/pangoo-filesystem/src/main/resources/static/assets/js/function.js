// JavaScript Document
String.prototype.trim = function() {
	// return this.replace(/(^\s+)|(\s+$)/g, "");
	return this.replace(/^(&nbsp;|[\s　])+|(&nbsp;|[\s　])+$/g, "");
};
String.prototype.suolve = function(length) {
	var sub_length = length ? length : 20;
	// 精髓
	var temp1 = this.replace(/[^\x00-\xff]/g, "**");
	var temp2 = temp1.substring(0, sub_length);
	// 找出有多少个*
	var x_length = temp2.split("\*").length - 1;
	var hanzi_num = x_length / 2;
	// 实际需要sub的长度是总长度-汉字长度
	sub_length = sub_length - hanzi_num;
	var res = this.substring(0, sub_length);
	var end = "";
	if (sub_length < this.length) {
		end = res + "……";
	} else {
		end = res;
	}
	return end;
};
String.prototype.htmlEncode = function() {
	var s = "";
	if (this.length == 0)
		return "";
	s = this.replace(/&/g, "&gt;");
	s = s.replace(/</g, "&lt;");
	s = s.replace(/>/g, "&gt;");
	s = s.replace(/ /g, "&nbsp;");
	s = s.replace(/\'/g, "&#39;");
	s = s.replace(/\"/g, "&quot;");
	s = s.replace(/\n/g, "<br>");
	return s;
};
String.prototype.replaceAll = function(reallyDo, replaceWith, ignoreCase) {  
  if (!RegExp.prototype.isPrototypeOf(reallyDo)) {  
      return this.replace(new RegExp(reallyDo, (ignoreCase ? "gi": "g")), replaceWith);  
  } else {  
      return this.replace(reallyDo, replaceWith);  
  }  
}
String.prototype.urlEncode = function() {
	var s = "";
	if (this.length == 0)
		return "";
	for(var i=0; i<this.length; i++){
	  var subs = this.substring(i, i+1);
	  if(subs == "%"){
	    s += "%25";
	  }else if(subs == "&"){
	    s += "%26";
	  }else if(subs == "\?"){
      s += "%3F";
    }else{
      s += subs;
    }
	}
	// s = this.replace(/&/g, "%26");
	// s = s.replace(/\?/g, "%3F");
	return s;
}
var Sys = {};
var ua = navigator.userAgent.toLowerCase();
var s;
(s = ua.match(/msie ([\d.]+)/)) ? Sys.ie = s[1] : (s = ua.match(/firefox\/([\d.]+)/)) ? Sys.firefox = s[1] : (s = ua.match(/chrome\/([\d.]+)/)) ? Sys.chrome = s[1]
		: (s = ua.match(/opera.([\d.]+)/)) ? Sys.opera = s[1] : (s = ua.match(/version\/([\d.]+).*safari/)) ? Sys.safari = s[1] : 0;
// 以下进行测试
/*
 * if (Sys.ie) alert('IE: ' + Sys.ie); if (Sys.firefox) alert('Firefox: ' +
 * Sys.firefox); if (Sys.chrome) alert('Chrome: ' + Sys.chrome); if (Sys.opera)
 * alert('Opera: ' + Sys.opera); if (Sys.safari) alert('Safari: ' + Sys.safari);
 */
// IE下支持indexOf
if (!Array.indexOf) {
	Array.prototype.indexOf = function(obj) {
		for ( var i = 0; i < this.length; i++) {
			if (this[i] == obj) {
				return i;
			}
		}
		return -1;
	}
}
// 判断数组中是否有某值
function IsInArray(arr, val) {
	var testStr = ',' + arr.join(",") + ",";
	return testStr.indexOf("," + val + ",") != -1;
}
// 从数组中删除一个元素
function removeFromArray(arr, i) {
	return arr.slice(0, i - 1).concat(arr.slice(i));
}
// 根据classname获得元素集
function getElementsByClassName(n) {
	var classElements = [], allElements = document.getElementsByTagName('*');
	for ( var i = 0; i < allElements.length; i++) {
		if (allElements[i].className == n) {
			classElements[classElements.length] = allElements[i];
		}
	}
	return classElements;
}
// 获得obj的坐标
function getXY(obj) {
	var x = 0, y = 0;
	if (obj.getBoundingClientRect) {
		var box = obj.getBoundingClientRect();
		var D = document.documentElement;
		x = box.left + Math.max(D.scrollLeft, document.body.scrollLeft) - D.clientLeft;
		y = box.top + Math.max(D.scrollTop, document.body.scrollTop) - D.clientTop;
	} else {
		for (; obj != document.body; x += obj.offsetLeft, y += obj.offsetTop, obj = obj.offsetParent) {
		}
	}
	return {
		x : x,
		y : y
	}
}
// ----------同getXY函数----------------------
function getPos(obj) {
	return {
		top : document.documentElement.scrollTop + obj.getBoundingClientRect().top,
		left : document.documentElement.scrollLeft + obj.getBoundingClientRect().left
	};
}
// -----------兼容safari浏览器的写法，效率低些------------
/*
 * function getPos(obj){ var pos = {"top":0, "left":0}; if (obj.offsetParent){
 * while (obj.offsetParent){ pos.top += obj.offsetTop; pos.left +=
 * obj.offsetLeft; obj = obj.offsetParent; } }else if(obj.x){ pos.left += obj.x;
 * }else if(obj.x){ pos.top += obj.y; } return pos; }
 */
// ------------------获得元素位置，比较准--------------
function getPoint(source) {
	var pt = {
		x : 0,
		y : 0
	};
	do {
		pt.x += source.offsetLeft;
		pt.y += source.offsetTop;
		source = source.offsetParent;
	} while (source);
	return pt;
}
// -------------获得页面scroll位置-----------------------------
function getScrollXY() {
	var x, y;
	if (document.body.scrollTop) {
		x = document.body.scrollLeft;
		y = document.body.scrollTop;
	} else {
		x = document.documentElement.scrollLeft;
		y = document.documentElement.scrollTop;
	}
	return {
		x : x,
		y : y
	};
}
// 获得鼠标绝对位置
function mouseCoords(ev) {
	evev = ev || window.event;
	if (ev.pageX || ev.pageY) {
		return {
			x : ev.pageX,
			y : ev.pageY
		};
	}
	return {
		x : ev.clientX + document.body.scrollLeft - document.body.clientLeft,
		y : ev.clientY + document.body.scrollTop - document.body.clientTop
	};
}
// 获得鼠标相对位置
function getMousePosition(event, o) {
	var mousePosition = {
		x : 0,
		y : 0
	};
	var top, left, obj;
	obj = o;
	var ParentObj = obj;
	left = obj.offsetLeft;
	while (ParentObj = ParentObj.offsetParent) {
		left += ParentObj.offsetLeft;
	}
	mousePosition.x = event.clientX - left + document.body.scrollLeft;
	ParentObj = obj;
	top = obj.offsetTop;
	while (ParentObj = ParentObj.offsetParent) {
		top += ParentObj.offsetTop;
	}
	mousePosition.y = event.clientY - top + document.body.scrollTop;
	return mousePosition;
}
function mousePos(e) {
	var x, y;
	var e = e || window.event;
	return {
		x : e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft,
		y : e.clientY + document.body.scrollTop + document.documentElement.scrollTop
	};
}
// ----------------------------遮罩层相关代码---------------------------------------------------------------------
function createElement(type) {
	return document.createElement(type);
}
function hideSelects(zIndexNow) {
	if (navigator.appVersion.indexOf("MSIE 6.0") != -1) {
		var selects = document.getElementsByTagName("select");
		var length = selects.length;
		for ( var i = 0; i < length; i++) {
			if (selects[i].zIndexNow != zIndexNow && selects[i].style.visibility != "hidden") {
				selects[i].style.visibility = "hidden";
				selects[i].zIndexNow = zIndexNow;
			}
		}
	}
}
function showSelects(zIndexNow) {
	if (navigator.appVersion.indexOf("MSIE 6.0") != -1) {
		var selects = document.getElementsByTagName("select");
		var length = selects.length;
		for ( var i = 0; i < length; i++) {
			if (selects[i].zIndexNow == zIndexNow) {
				selects[i].style.visibility = "";
				selects[i].zIndexNow = -1;
			}
		}
	}
}
function getWindowSize() {
	var myWidth = 0, myHeight = 0;
	if (typeof (window.innerWidth) == 'number') {
		// Non-IE
		myWidth = window.innerWidth;
		myHeight = window.innerHeight;
	} else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
		// IE 6+ in 'standards compliant mode'
		myWidth = document.documentElement.clientWidth;
		myHeight = document.documentElement.clientHeight;
	} else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {
		// IE 4 compatible
		myWidth = document.body.clientWidth;
		myHeight = document.body.clientHeight;
	}
	return ([ myWidth, myHeight ]);
}
var Mask = function() {
	this.zIndexNow = 100;
	this.maskDiv = null;
	this.indexArr = [];
	this.show = function() {
		this.zIndexNow += 10;
		if (this.indexArr.length == 0) {
			var maskHeight = document.documentElement.scrollHeight > getWindowSize()[1] ? document.documentElement.scrollHeight : getWindowSize()[1];
			this.maskDiv = createElement("div");
			this.maskDiv.onclick = function() {
				var event = arguments[0] || window.event;
				event.cancelBubble = true;
			};
			this.maskDiv.className = "mask";
			this.maskDiv.style.width = "100%";
			this.maskDiv.style.height = maskHeight + "px";
			document.body.appendChild(this.maskDiv);
		}
		this.maskDiv.style.zIndex = this.zIndexNow - 1;
		this.indexArr.push(this.zIndexNow - 1);
		hideSelects(this.zIndexNow);
	};
	this.clean = function() {
		showSelects(this.zIndexNow);
		this.indexArr.pop();
		if (this.indexArr.length > 0) {
			this.maskDiv.style.zIndex = this.indexArr[this.indexArr.length - 1];
			this.zIndexNow = this.indexArr[this.indexArr.length - 1] + 1;
		} else {
			document.body.removeChild(this.maskDiv);
			this.zIndexNow = 100;
		}
	};
};
// ----------------------遮罩层相关代码结束--------------------------------------------------------------------------
// --------获得时间类函数---------------------------------------------------------
function getCurYear(len) {
	var myDate = new Date();
	if (len == 2) {
		return myDate.getYear(); // 获取当前年份(2位)
	}
	if (len = 4) {
		return myDate.getFullYear(); // 获取完整的年份(4位,1970-????)
	}
}
function getCurMonth() {
	var myDate = new Date();
	return myDate.getMonth() + 1;
}
// ------------------------------------------------------------------
var Utils = {
	/**
	 * 数字转中文
	 * 
	 * @number {Integer} 形如123的数字
	 * @return {String} 返回转换成的形如 一百二十三 的字符串
	 */
	numberToChinese : function(number) {
		/*
		 * 单位
		 */
		var units = '个十百千万@#%亿^&~';
		/*
		 * 字符
		 */
		var chars = '零一二三四五六七八九';
		var a = (number + '').split(''), s = [];
		if (a.length > 12) {
			throw new Error('too big');
		} else {
			for ( var i = 0, j = a.length - 1; i <= j; i++) {
				if (j == 1 || j == 5 || j == 9) {// 两位数 处理特殊的 1*
					if (i == 0) {
						if (a[i] != '1')
							s.push(chars.charAt(a[i]));
					} else {
						s.push(chars.charAt(a[i]));
					}
				} else {
					s.push(chars.charAt(a[i]));
				}
				if (i != j) {
					s.push(units.charAt(j - i));
				}
			}
		}
		// return s;
		return s.join('').replace(/零([十百千万亿@#%^&~])/g, function(m, d, b) {// 优先处理
			// 零百
			// 零千 等
			b = units.indexOf(d);
			if (b != -1) {
				if (d == '亿')
					return d;
				if (d == '万')
					return d;
				if (a[j - b] == '0')
					return '零'
			}
			return '';
		}).replace(/零+/g, '零').replace(/零([万亿])/g, function(m, b) {// 零百 零千处理后
			// 可能出现
			// 零零相连的
			// 再处理结尾为零的
			return b;
		}).replace(/亿[万千百]/g, '亿').replace(/[零]$/, '').replace(/[@#%^&~]/g, function(m) {
			return {
				'@' : '十',
				'#' : '百',
				'%' : '千',
				'^' : '十',
				'&' : '百',
				'~' : '千'
			}[m];
		}).replace(/([亿万])([一-九])/g, function(m, d, b, c) {
			c = units.indexOf(d);
			if (c != -1) {
				if (a[j - c] == '0')
					return d + '零' + b
			}
			return m;
		});
	}
};
var now = new Date(); // 当前日期
var nowDayOfWeek = now.getDay(); // 今天本周的第几天
var nowDay = now.getDate(); // 当前日
var nowMonth = now.getMonth(); // 当前月
var nowYear = now.getYear(); // 当前年
nowYear += (nowYear < 2000) ? 1900 : 0; //      
// 格式化日期：yyyy-MM-dd
function formatDate(date) {
	var myyear = date.getFullYear();
	var mymonth = date.getMonth() + 1;
	var myweekday = date.getDate();
	if (mymonth < 10) {
		mymonth = "0" + mymonth;
	}
	if (myweekday < 10) {
		myweekday = "0" + myweekday;
	}
	return (myyear + "-" + mymonth + "-" + myweekday);
}

//格式化日期：yyyy-MM-dd HH:mm:ss
function formatDate2(date) {
	var myyear = date.getFullYear();
	var mymonth = date.getMonth() + 1;
	var myweekday = date.getDate();
	var myhour = date.getHours();
	var myminutes = date.getMinutes();
	var mysec = date.getSeconds()
	if (mymonth < 10) {
		mymonth = "0" + mymonth;
	}
	if (myweekday < 10) {
		myweekday = "0" + myweekday;
	}
	if (myhour < 10) {
		myhour = "0" + myhour;
	}
	if (myminutes < 10) {
		myminutes = "0" + myminutes;
	}
	if (mysec < 10) {
		mysec = "0" + mysec;
	}
	return (myyear + "-" + mymonth + "-" + myweekday + " " + myhour + ":" + myminutes + ":" + mysec);
}

// 格式化yyyy-MM-dd为xxxx年xx月xx日格式,默认要加上年份
function formatDateShow(dateShow, removeYear) {
	var year = dateShow.substr(0, 4);
	var month = parseInt(dateShow.substr(5, 2), 10);
	var day = parseInt(dateShow.substr(8, 2), 10);
	if (typeof (removeYear) == 'undefined') {
		return (year + "年" + month + "月" + day + "日");
	} else {
		return (month + "月" + day + "日");
	}
}
// ----------1-7转化为星期一，星期二。。。星期天
function getWeekShow(num) {
	var r = "";
	switch (num) {
	case "1":
		r = "星期一";
		break;
	case "2":
		r = "星期二";
		break;
	case "3":
		r = "星期三";
		break;
	case "4":
		r = "星期四";
		break;
	case "5":
		r = "星期五";
		break;
	case "6":
		r = "星期六";
		break;
	case "7":
		r = "星期天";
		break;
	}
	return r;
}
// 时间段格显示式化如果在同一年，后一个不显示年份
function betweenShow(beginDate, endDate) {
	var beginYear = beginDate.substr(0, 4);
	var endYear = endDate.substr(0, 4);
	if (beginYear == endYear) {
		return (formatDateShow(beginDate) + " - " + formatDateShow(endDate, "removeYear"));
	} else {
		return (formatDateShow(beginDate) + " - " + formatDateShow(endDate));
	}
}
// 获得月/日格式日期
function formatDateMD(date) {
	var mymonth = date.getMonth() + 1;
	var myweekday = date.getDate();
	return (mymonth + "/" + myweekday);
}
// 获得月/日格式日期
function formatDateStrMD(dateStr) {
	var month = parseInt(dateStr.substr(5, 2), 10);
	var day = parseInt(dateStr.substr(8, 2), 10);
	return (month + "/" + day);
}
// 获得某月的天数 有问题，不要用!!
/*
 * function getMonthDays(myMonth){ var monthStartDate = new Date(nowYear,
 * myMonth, 1); var monthEndDate = new Date(nowYear, myMonth + 1, 1); var days =
 * (monthEndDate - monthStartDate)/(1000 * 60 * 60 * 24); return days; }
 */
// 改进获得某月天数，参数为yyyy-MM-dd
function getMonthDays(date) {
	var year = date.substr(0, 4);
	var month = parseInt(date.substr(5, 2), 10);
	return new Date(year, month, 0).getDate();
	/*
	 * var monthStartDate = new Date(year, month, 1); var monthEndDate = new
	 * Date(year, month + 1, 1); var days = (monthEndDate -
	 * monthStartDate)/(1000 * 60 * 60 * 24); return days;
	 */
}
// 获得本季度的开始月份
function getQuarterStartMonth() {
	var quarterStartMonth = 0;
	if (nowMonth < 3) {
		quarterStartMonth = 0;
	}
	if (2 < nowMonth && nowMonth < 6) {
		quarterStartMonth = 3;
	}
	if (5 < nowMonth && nowMonth < 9) {
		quarterStartMonth = 6;
	}
	if (nowMonth > 8) {
		quarterStartMonth = 9;
	}
	return quarterStartMonth;
}
// 未指定参数，获得本周的开始日期；指定参数，获得参数日期所在周的开始日期
function getWeekStartDate(date) {
	// var weekStartDate = new Date(nowYear, nowMonth, nowDay - nowDayOfWeek);
	// //yl20120531修改，符合国人习惯每周从周一开始
	if (typeof (date) == 'undefined') {
		var weekStartDate = new Date(nowYear, nowMonth, nowDay - nowDayOfWeek + 1);
		return formatDate(weekStartDate);
	} else {
		var year = date.substr(0, 4);
		var month = parseInt(date.substr(5, 2), 10);
		var day = parseInt(date.substr(8, 2), 10);
		var dayDate = new Date(year, month - 1, day);
		var dayOfWeek = dayDate.getDay();
		if (dayOfWeek == 0)
			dayOfWeek = 7;
		var weekStartDate = new Date(year, month - 1, day - dayOfWeek + 1);
		return formatDate(weekStartDate);
	}
}
// 未指定参数，获得本周的结束日期；指定参数，获得参数日期所在周的结束日期
function getWeekEndDate(date) {
	// var weekEndDate = new Date(nowYear, nowMonth, nowDay + (6 -
	// nowDayOfWeek)); //yl20120531修改，符合国人习惯每周最后一天为周日
	if (typeof (date) == 'undefined') {
		var weekEndDate = new Date(nowYear, nowMonth, nowDay + (7 - nowDayOfWeek));
		return formatDate(weekEndDate);
	} else {
		var year = date.substr(0, 4);
		var month = parseInt(date.substr(5, 2), 10);
		var day = parseInt(date.substr(8, 2), 10);
		var dayDate = new Date(year, month - 1, day);
		var dayOfWeek = dayDate.getDay();
		if (dayOfWeek == 0)
			dayOfWeek = 7;
		var weekEndDate = new Date(year, month - 1, day + (7 - dayOfWeek));
		return formatDate(weekEndDate);
	}
}
// 取得本周每天日期 格式月/日
function getWeekDay(beginDate, weekNum) {
	// var weekDate = new Date(nowYear, nowMonth, nowDay -
	// nowDayOfWeek+weekNum);
	var year = beginDate.substr(0, 4);
	var month = parseInt(beginDate.substr(5, 2), 10);
	var day = parseInt(beginDate.substr(8, 2), 10);
	var weekDate = new Date(year, month - 1, day + weekNum - 1);
	return formatDate(weekDate);
}
// //未指定参数，获得本月的开始日期；指定参数，获得参数日期所在月的开始日期
function getMonthStartDate(date) {
	if (typeof (date) == 'undefined') {
		var monthStartDate = new Date(nowYear, nowMonth, 1);
		return formatDate(monthStartDate);
	} else {
		var year = date.substr(0, 4);
		var month = parseInt(date.substr(5, 2), 10);
		var day = parseInt(date.substr(8, 2), 10);
		var monthStartDate = new Date(year, month - 1, 1);
		return formatDate(monthStartDate);
	}
}
// ////未指定参数，获得本月的结束日期；指定参数，获得参数日期所在月的结束日期
function getMonthEndDate(date) {
	if (typeof (date) == 'undefined') {
		var monthEndDate = new Date(nowYear, nowMonth, 0);
		return formatDate(monthEndDate);
	} else {
		var year = date.substr(0, 4);
		var month = parseInt(date.substr(5, 2), 10);
		var monthEndDate = new Date(year, month, 0);
		return formatDate(monthEndDate);
	}
}
// 获得本季度的开始日期
function getQuarterStartDate() {
	var quarterStartDate = new Date(nowYear, getQuarterStartMonth(), 1);
	return formatDate(quarterStartDate);
}
// 或的本季度的结束日期
function getQuarterEndDate() {
	var quarterEndMonth = getQuarterStartMonth() + 2;
	var quarterStartDate = new Date(nowYear, quarterEndMonth, 0).getDate();
	return formatDate(quarterStartDate);
}
// 获得date前后n天的日期,date 为 yyyy-MM-dd格式字符串
function getIntervalDate(date, n) {
	var dayDate = getDateType(date);
	dayDate.setDate(dayDate.getDate() + n);
	return formatDate(dayDate);
}
// //获得date前后n月同一天日期,为 yyyy-MM-dd格式字符串
function getIntervalMonthDate(date, n) {
	var year = date.substr(0, 4);
	var month = parseInt(date.substr(5, 2), 10);
	var day = parseInt(date.substr(8, 2), 10);
	var MonthDate = new Date(year, month + n - 1, day);
	return formatDate(MonthDate);
}
// 将yyyy-MM-dd格式字符串转换成日期类型
function getDateType(date) {
	var year = date.substr(0, 4);
	var month = parseInt(date.substr(5, 2), 10);
	var day = parseInt(date.substr(8, 2), 10);
	var dayDate = new Date(year, month - 1, day);
	return dayDate;
}
// 判断日期在本月第几周
function getMonthWeek(date) {
	var year = date.substr(0, 4);
	var month = parseInt(date.substr(5, 2), 10);
	var day = parseInt(date.substr(8, 2), 10);
	var newDate = new Date(year, parseInt(month) - 1, day);
	var w = newDate.getDay();
	var d = newDate.getDate();
	return Math.ceil((d + 6 - w) / 7);
}
// 判断日期在本年第几周
function getYearWeek(date) {
	var year = date.substr(0, 4);
	var month = parseInt(date.substr(5, 2), 10);
	var day = parseInt(date.substr(8, 2), 10);
	var date1 = new Date(year, parseInt(month) - 1, day);
	var date2 = new Date(year, 0, 1);
	var d = Math.round((date1.valueOf() - date2.valueOf()) / 86400000);
	return Math.ceil((d + ((date2.getDay() + 1) - 1)) / 7);
}
// alert(getQuarterEndDate());
// --------------------获得font-size的字符串文字尺寸----------------------------
function textSize(fontSize, text) {
	var span = document.createElement("span");
	var result = {};
	result.width = span.offsetWidth;
	result.height = span.offsetWidth;
	span.style.visibility = "hidden";
	document.body.appendChild(span);
	if (typeof span.textContent != "undefined")
		span.textContent = text;
	else
		span.innerText = text;
	result.width = span.offsetWidth - result.width;
	result.height = span.offsetHeight - result.height;
	span.parentNode.removeChild(span);
	return result;
}
// 对象的字符串表示,例:检测parent.topObject.top.initData则执行checkObjctExist("parent.topObject.top.initData");
function checkObjctExist(stringOfObject) {
	try {
		var tmpObject = eval(stringOfObject);
		if (tmpObject == undefined || tmpObject == null) {
			return false;
		}
	} catch (e) {
		return false;
	}
	return true;
}
/**
 * @param para
 * @param resetFlag
 *            重置参数(true表示按照para完全重置,false代表在现在基础上做替换)
 * @param w
 */
function reloadWindow(para, resetFlag, w) {
	w = w ? w : window;
	var url = w.location.href;
	if (para) {
		var oldPara = {};
		var urls = url.split("?");
		if (urls.length > 1) {
			var params = urls[1].split("&");
			for ( var i = 0; i < params.length; i++) {
				if (params[i].indexOf("=")) {
					var kvs = params[i].split("=");
					oldPara[kvs[0]] = kvs[1];
				}
			}
		}
		if (resetFlag) {
			oldPara = para;
		} else {
			for ( var k in para) {
				oldPara[k] = para[k];
			}
		}
		url = urls[0] + "?" + $.param(oldPara, false);
	}
	w.location.href = url;
}
function getIcon(type, title) {
	if (type == "col") {
		return "<img src='tc_ttp/style/default/images/jointIco.png' style='margin-top:-3px;' align='absmiddle' title='协同'>";
	} else if (type == "task") {
		return "<img src='"+TC.config.baseUrl+"tc_ttp/style/default/images/task.png' align='absmiddle' style='margin-top:-3px; title='事项'>";
	} else {
		return "<img src='tc_ttp/style/default/images/icon/" + type + "16x16.png' align='absmiddle' style='margin-top:-3px; title='" + title + "'>";
	}
}
/**
 * 构造关联信息回显时候的html元素
 * @param file 必须的file对象
 * @param addFileDiv 添加到那个元素之内
 */
function addFileHtml(file,addFileDiv,callBack) {
	if (file.resouceType == 10020001) {//rel.getIcon.do
		TC.util.postAjaxData(TC.config.baseUrl + "/tc/rel/?m=icon", {"fileType":file.fileType}, function(result) {
			var attObj = "<div name=\"fileDiv\" style=\"float:left;margin:0;margin-top:2px;white-space:nowrap; \" id="+file.id+"><input type=\"hidden\" resouceType="+file.resouceType+" fileSize="+file.fileSize+" id=att"+file.id+" name=\"attachment\" value="+file.id + "*" + file.fileName+">"
			+"<img src='"+TC.config.baseUrl+"/tc_ttp/style/default/images/icon/"+result.icon+"16x16.png' style=\"margin-top:-4px\" align=\"absmiddle\" />"
			+"<a href=\"javascript:void()\" onclick=\"task.common.downloadAtt('"+file.id+"')\">" + file.fileName + "</a>"
			+"<img src='"+TC.config.baseUrl+"/tc_ttp/style/default/images/del_min.png' align='absmiddle' style='cursor:pointer;margin-right:5px;'"
			+" title='取消关联' onclick='delAtt5upload(this , "+callBack+")'>&nbsp;&nbsp;</div>";
			if (addFileDiv) {
				addFileDiv.append(attObj);
			} else {
				$("#addFiles").append(attObj);
			}
			if ($(window.parent.document) && $(window.parent.document).find("#processFrame").length > 0 && addFileDiv) {
				$(window.parent.document).find("#processFrame").height($(window).height() + addFileDiv.height());
			}
		},false,"get");
	} else {
		var img = "";
		if(file.fileType){
//			img = getIcon(file.fileType.split("_")[0], file.fileType.split("_")[1]);
			img = "<img src='"+TC.config.baseUrl+"tc_ttp/style/default/images/task.png' align='absmiddle' style='margin-top:-3px; title='事项'>";
		}
		var fileName = (file.fileName).htmlEncode();
		var params = "{id:'"+file.id+"',url:'tc/task/"+file.id+"/',type:"+file.resouceType+"}";

		//var params = "{id:'"+file.id+"',url:'tc/task/"+file.id+"/',type:"+file.resouceType+"/',outtype:1111"}";

		var attObj = "<div id="+file.id+" name=\"relDiv\" style=\"float:left;margin:0;margin-top:2px;white-space:nowrap;\"><input type=\"hidden\" fileName="+fileName+" resouceType="+file.resouceType+" id="+file.id+" name=\"relResource\" value=" + file.id + "*" + file.resouceType+">"
		+ img
		+"<a href=\"javascript:void()\" onclick=\"TC.ui.openResource(" + params + ")\">" + fileName + "</a>"
		+"<img src='"+TC.config.baseUrl+"/tc_ttp/style/default/images/del_min.png' align='absmiddle' style='cursor:pointer;margin-top:-4px;'"
		+" title='取消关联' onclick='delAtt5upload(this)'>&nbsp;&nbsp;</div>";
		if (addFileDiv) {
			addFileDiv.append(attObj);
		} else {
			$("#addFiles").append(attObj);
		}
		if ($(window.parent.document) && $(window.parent.document).find("#processFrame").length > 0) {
			$(window.parent.document).find("#processFrame").height($(window).height() + addFileDiv.height());
		}
	}
}

function ztreeNodeDefaultState(zTreeObj) {
	if (zTreeObj.getNodes().length > 0) {
		var id = zTreeObj.getNodes()[0].id;
		zTreeObj.selectNode(zTreeObj.getNodesByParam("id", id)[0]);
	}
}
function checkDate(startDate , endDate , callBack) {
	if (startDate && endDate) {
		if(startDate.val()>endDate.val()){
			$.dialog.alert("开始时间不能大于结束时间");
		} else if (endDate.val()<startDate.val()) {
			$.dialog.alert("结束时间不能小于结束时间");
		}else{
			callBack(true);
		}
	}
}
function getCanlendar() {
	var d = new Date();
	return d.toLocaleString().replace("日","").replace(/[年月]/g,"-").substring(10);
}

Date.prototype.format = function(format) {
	    /*
		 * 
		 * eg:format="YYYY-MM-dd hh:mm:ss";
		 * 
		 */
	    var o = {
	        "M+" :this.getMonth() + 1, // month
	        "d+" :this.getDate(), // day
	        "h+" :this.getHours(), // hour
	        "m+" :this.getMinutes(), // minute
	        "s+" :this.getSeconds(), // second
	        "q+" :Math.floor((this.getMonth() + 3) / 3), // quarter
	        "S" :this.getMilliseconds()
	    // millisecond
	    }
	    if (/(y+)/.test(format)) {
	        format = format.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
	    }
	    for ( var k in o) {
	        if (new RegExp("(" + k + ")").test(format)) {
	            format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
	        }
	    }
	    return format;
}
Date.prototype.getCalendarMonthData = function() {
	var locale = this.toLocaleString();
	return locale.substring(10 , locale.length - 3);
}

/**
 * 设置title换行
 * @param obj	要换行的jquery对象
 * @param colnum	多少字符换行
 */
function changeTitleStyle(obj,colnum){
	$(obj).each(function(){
		var title = $(this).attr("title");
		if(title != undefined && title.length > 0){
			var array = [];
			title = $.trim(title);
			var count = 0;
			for(var i=0;i<title.length;i++){
				var _str = title[i];
				count += /[\u4e00-\u9fa5]/.test(_str)?2:1;
				array.push(title[i]);
				if(count >= colnum*2){
					array.push("\n");
					count = 0;
				}
				/*
				if(i > 0 && i % colnum == 0){
					array.push("\n");
				}*/
			}
			$(this).attr("title",array.join(""));	
		}
	});
}


/**
 * 根据iframeId获取iframe的documnet
 * FF与IE获取iframe的doucment有差异
 */
function getDocumentByIframeId(iframeId){
	return document.getElementById(iframeId).contentDocument || document.frames[iframeId].document;
}

/**
 * 
 */
function getFrameWindow(frame){
  if(isWindow(frame)){
    return frame;
  }
	if(frame && typeof(frame)=='object' && /iframe/i.test(frame.tagName)){
		return frame.contentWindow || frame.window;
	}
	return null;
}

function isWindow(obj){
	/*
	var result = obj.window;
	if (result) {
		return obj.window === obj.window.window;
	}
  return true;
  */
  return /Window|global/.test({}.toString.call(obj))||obj==obj.document&&obj.document!=obj; 
}

function getChoosePersonConfig() {
	var config = {
			title : "选择人员",
			chooseModule : "ChooseInAll",
			orgOrgUnitRange : [ "OrgDepartment", "OrgTeam", "OrgPost", "OrgLevel", "OrgRole", "RelationPerson" ],
			orgChooseDataType : [ "10000003" ]
			//orgInitChooseDatas : initData,
			//orgChooseCount : 1
		};
	return config;
}
function delAtt5upload(obj,callBack){
	//$(obj).parent().empty();
	//$(obj).prev().prev().prev().remove();
	//$(obj).prev().prev().remove();
	//$(obj).prev().remove();
	//$(obj).remove();
	
	if (callBack && jQuery.isFunction(callBack)) {
		callBack($(obj).parent().attr("id"));
	}
	$(obj).parent().remove();
}
function getFilTypeNotImageType() {
	return ["*.txt" , "*.doc" , "*.pdf" , "*.docx" , "*.xlsx" , "*.rar" , "*.wps" , "*.zip" , "*.CHM","*.chm" , "*.mmap" , "*.xml" , "*.ppt" , "*.pptx" , "*.mp3" , "*.wma" , "*.mp4"];
}
//时间间隔判断
function getDays(strDateStart, strDateEnd) {
	var strSeparator = "-"; //日期分隔符
	var oDate1;
	var oDate2;
	var iDays;
	oDate1 = strDateStart.split(strSeparator);
	oDate2 = strDateEnd.split(strSeparator);
	var strDateS = new Date(oDate1[0], oDate1[1] - 1, oDate1[2]);
	var strDateE = new Date(oDate2[0], oDate2[1] - 1, oDate2[2]);
	iDays = parseInt(Math.abs(strDateS - strDateE) / 1000 / 60 / 60 / 24)//把相差的毫秒数转换为天数
	return iDays;
}
//时间间隔判断
function checkDays(strDateStart, strDateEnd){
	var days = getDays(strDateStart, strDateEnd);
	if(days > 31){
		return true;
	}
	return false;
}
//时间间隔判断
function checkDaysInterval(strDateStart, strDateEnd, maxDateInterval){
	var days = getDays(strDateStart, strDateEnd);
	if(days > maxDateInterval){
		return true;
	}
	return false;
}
//新开窗口
function newWin(url,id) {
    var a = top.document.createElement('a');
    a.setAttribute('href', url);
    a.setAttribute('target', '_blank');
    a.setAttribute('id', id);
    // 防止反复添加
    if(!top.document.getElementById(id)) {                     
    	top.document.body.appendChild(a);
    }
    a.click();
    top.document.getElementById(id).remove();
}

function IsPC() {
    var userAgentInfo = navigator.userAgent;
    var Agents = ["Android", "iPhone",
                "SymbianOS", "Windows Phone",
                "iPad", "iPod"];
    var flag = true;
    for (var v = 0; v < Agents.length; v++) {
        if (userAgentInfo.indexOf(Agents[v]) > 0) {
            flag = false;
            break;
        }
    }
    return flag;
}

function goBack() {
	window.history.go(-1);
}

function appClient(){
    Android.appClient()
}

/**
 * checkbox获取选择的id
 */
function getSelectItemIds(){
	var ids = [];
	$("input[data-item-id]:checked").each(function(){
		 ids.push($(this).attr("data-item-id"));
	})
	return ids;
}

/**
 * 退出
 */
function exit(){
	top.TC.ui.relocateResource();
}

/**
 * 努力加载中
 */
function loading(){
	if($("#loading").length == 0){
		$("body").append('<div class="loading" id="loading"><div><a><i></i></a></div></div>');
	}
	$("#loading").show();
}


//下载文件
function downloadFile(url){
	var iframe = document.createElement("iframe");
	iframe.setAttribute("style", "display: none;");
	document.body.appendChild(iframe);  
	iframe.src = url;
}