(function($, TC) {
  var _args, _path = (function(script, i, me) {
      var l = script.length;

      for (; i < l; i++) {
        me = !!document.querySelector ?
          script[i].src : script[i].getAttribute('src', 4);

        if (me.substr(me.lastIndexOf('/')).indexOf('lang') !== -1)
          break;
      }

      me = me.split('?');
      _args = me[1];

      return me[0].substr(0, me[0].lastIndexOf('/') + 1);
    })(document.getElementsByTagName('script'), 0),

    /*!
     * 获取url参数值函数
     * @param  {String}
     * @return {String||null}
     */
    _getArgs = function(name) {
      if (_args) {
        var p = _args.split('&'),
          i = 0,
          l = p.length,
          a;
        for (; i < l; i++) {
          a = p[i].split('=');
          if (name === a[0]) return a[1];
        }
      }
      return null;
    },

    /*! 获取语言,默认为en_US */
    local = '' + _getArgs('local') || 'en_US';

  var langPackageUrl = TC.config.baseUrl + "html/assets/i18n/"+local+".js";
  
	/**
	 * 格式化
	 * templateString:格式化模板
	 * args:格式化所需参数
	 */
	function format(templateString,args){
		if(!templateString){
			return "";
		}
		if(!args){
			return templateString;
		}
		return templateString.replace(/\{(\d+)\}/g,function(matchs,index){
			return args[index];
		});
	}
  
	 jQuery.ajax({
			type: "GET",
			url: langPackageUrl,
			async: false,
			dataType: "script",
			success: function(data){
				  var Lang = {
							$langList:[{name:"en_US",charset:"UTF-8"},{name:"zh_CN",charset:"UTF-8"}],
							getLabel:function(){
								var labelName = arguments[0];
								var params = [];
								for(var i=1; i<arguments.length; i++){
									params.push(arguments[i]);
								}
								return format($lang.label[labelName], params);
							},
							getMenu:function(){
								var menuName = arguments[0];
								var params = [];
								for(var i=1; i<arguments.length; i++){
									params.push(arguments[i]);
								}
								return format($lang.menu[menuName], params);
							},
							getMessage:function(){
								var messageName = arguments[0];
								var params = [];
								for(var i=1; i<arguments.length; i++){
									params.push(arguments[i]);
								}
								var value = format($lang.message[messageName], params);
								if (value == "") {
									return messageName;
								} else {
									return value;
								}
							}
					};	
				  window.Lang = Lang;
			}
		});

})($, TC);
