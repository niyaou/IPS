//同一个页面有两个分页的情况使用

//分页一页数量
function pageNumClick(obj){
	var recordTotal = $("#datalist1 tbody").find("tr").length;
	var pageSize = parseInt($(obj)[0].value);
	var currentPage = parseInt($("#kkpager").children(".curr").text());
	var totalPage = recordTotal / pageSize;
	if(recordTotal % pageSize > 0){
		totalPage+=1;
	}
	var obj = {currentPage:1, totalPage:totalPage, totalCount:recordTotal, pageSize:pageSize};
	showPage(obj);
	page(obj);
}

//页码设置
function page(obj){
	$("#kkpager").empty();
	kkpager.generPageHtml({
        pno : obj['currentPage'],
        mode : 'click', //设置为click模式
        //总页码  
        total : obj['totalPage'],  
        //总数据条数  
        totalRecords : obj['totalCount'],
        //点击页码、页码输入框跳转、以及首页、下一页等按钮都会调用click
        //适用于不刷新页面，比如ajax
        click : function(n){
        	obj["currentPage"] = n;
        	showPage(obj);
    		page(obj);
        }
    },true);
	var checklist = document.getElementsByName("ischeck"); 
	var flg=false;
		for(var i=0; i<checklist.length; i++){ 
			if("none"!=$(checklist[i]).parents("tr").css("display")){
				if($(checklist[i]).is(':checked')){
					flg=true;
				}else{
					flg=false;
					break;
				}
			}
		}  
		if(flg){
			$("#allcheck").prop("checked",true);
		}else{
			$("#allcheck").removeAttr("checked");
		}
}

//页面显示
function showPage(obj){
	var pageSize = obj['pageSize'];
	var n = obj['currentPage'];
	$("#datalist1 table tbody tr").hide();
	$("#datalist1 table tbody tr").each(function(index){
		if(n * pageSize > index && (n-1) * pageSize <= index){
			$(this).show();
		}
	});
//	$(".pagesize").show();
}

//分页初期化
function fenyeInit(){
	var recordTotal = $("#datalist1 tbody").find("tr").length;
	var pageSize = $("#pagesizeIpt").val();
	var totalPage = recordTotal / pageSize;
	if(recordTotal % pageSize > 0){
		totalPage+=1;
	}
	var obj = {currentPage:1, totalPage:totalPage, totalCount:recordTotal, pageSize:pageSize};
	showPage(obj);
	page(obj);
}

//初期化每次都是最后页
function fenyeInitlastPage(){
	var recordTotal = $("#datalist1 tbody").find("tr").length;
	var pageSize = $("#pagesizeIpt").val();
	var totalPage = recordTotal / pageSize;
	if(recordTotal % pageSize > 0){
		totalPage+=1;
	}
	var currentPage=1;
	currentPage=Math.ceil(recordTotal / pageSize);
	var obj = {currentPage:currentPage, totalPage:totalPage, totalCount:recordTotal, pageSize:pageSize};
	showPage(obj);
	page(obj);
}

// 第二个分页
// 分页一页数量
function pageNumClick2(obj){
	var recordTotal = $("#datalist2 tbody").find("tr").length;
	var pageSize = parseInt($(obj)[0].value);
	var currentPage = parseInt($("#kkpager2").children(".curr").text());
	var totalPage = recordTotal / pageSize;
	if(recordTotal % pageSize > 0){
		totalPage+=1;
	}
	var obj = {currentPage:1, totalPage:totalPage, totalCount:recordTotal, pageSize:pageSize};
	showPage2(obj);
	page2(obj);
}

//页码构成
function page2(obj){
	$("#kkpager2").empty();
	kkpager2.generPageHtml({
      pno : obj['currentPage'],
      mode : 'click', //设置为click模式
      //总页码  
      total : obj['totalPage'],  
      //总数据条数  
      totalRecords : obj['totalCount'],
      //点击页码、页码输入框跳转、以及首页、下一页等按钮都会调用click
      //适用于不刷新页面，比如ajax
      click : function(n){
      	obj["currentPage"] = n;
      	showPage2(obj);
  		page2(obj);
      }
  },true);
}

//计算显示结果
function showPage2(obj){
	var pageSize = obj['pageSize'];
	var n = obj['currentPage'];
	$("#datalist2 table tbody tr").hide();
	$("#datalist2 table tbody tr").each(function(index){
		if(n * pageSize > index && (n-1) * pageSize <= index){
			$(this).show();
		}
	});
//	$(".pagesize2").show();
}

//分页初期化
function fenyeInit2(){
	var recordTotal = $("#datalist2 tbody").find("tr").length;
	var pageSize = $("#pagesizeIpt2").val();
	var totalPage = recordTotal / pageSize;
	if(recordTotal % pageSize > 0){
		totalPage+=1;
	}
	var obj = {currentPage:1, totalPage:totalPage, totalCount:recordTotal, pageSize:pageSize};
	showPage2(obj);
	page2(obj);
}