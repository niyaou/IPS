//1，about require js config//配置信息
;
require.config({
    //define all js file path base on this base path
    //actually this can setting same to data-main attribute in script tag
    //定义所有JS文件的基本路径,实际这可跟script标签的data-main有相同的根路径
    baseUrl: "./"

    //define each js frame path, not need to add .js suffix name
    //定义各个JS框架路径名,不用加后缀 .js
    , paths: {
        "jqueryCookie": ["/js/jquery.cookie"]
        , "websocket": ["/js/mywebsocket"]
    }

    //include NOT AMD specification js frame code
    //包含其它非AMD规范的JS框架
    , shim: {
        "underscore": {
            "exports": "_"
        }
    }

});

//2，about load each js code basing on different dependency
//按不同先后的依赖关系加载各个JS文件
require(["websocket"], function (ws) {
    var socket = ws.createConnect(location.host, '/uploadFileSocket');
    window.onExit = function () {
        socket.close();
    };
    var cancel = window.$('#cancelSelect')[0];
    cancel.onclick = function (ev) {
        if (window.selectedTr == null) {
            alert("请先选中进度行");
            return;
        }
        window.cancelSelect();
    };
});
