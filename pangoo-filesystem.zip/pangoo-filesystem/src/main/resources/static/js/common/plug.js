$(function() {
	$.extend($.fn, {
		open : function() {
			$(this).dialog('open');
		},
		close : function() {
			$(this).dialog('close');
		},

		// 万能查询
		allsearch : function(grid, url) {
			grid.cleargrid();
			var str = getSearchDivData($(this));
			var s = url.indexOf("?");
			if (s != -1) {
				str = ReplaceAll(str, "?", "&");
			}
			str = url + str;
			encodeURI(str)
			// 将变量赋值给全局变量方便清空时使用
			GridRedirect(grid, str);
			$(this).dialog('close');
		},
		// 清空grid
		cleargrid : function() {
			$(this).jqGrid("clearGridData");
		},
		regrid : function() {
			$(this).jqGrid("clearGridData");
			$(this).jqGrid("setGridParam", {
						search : true
					}).trigger("reloadGrid", [{
								page : 1
							}]);
		},
		gridpost:function(url,param,callback){
		  $(this).setgrid(url);
		  $(this).changepost(param,callback);
		},
		getrowvalue : function(id) {
			return $(this).jqGrid("getRowData", id);
		},
		setauto : function(url) {
			$(this)
					// don't navigate away from the field on tab when selecting
					// an item
					.bind("keydown", function(event) {
						if (event.keyCode === $.ui.keyCode.TAB
								&& $(this).data("autocomplete").menu.active) {
							event.preventDefault();
						}
					}).autocomplete({
								source : function(request, response) {
									$.getJSON(url, {
												autoValue : request.term
											}, response);
								},
								search : function() {
									// custom minLength
									var term = extractLast(this.value);
									if (term.length < 1) {
										return false;
									}
								},
								focus : function() {
									// prevent value inserted on focus
									return false;
								},
								select : function(event, ui) {
									this.value = ui.item.value;
									return false;
								}
							});
		},
		// 自动获得下拉框 自动callback需要
		setnewauto : function(url, callback) {
			$(this)
					// don't navigate away from the field on tab when selecting
					// an item
					.bind("keydown", function(event) {
						if (event.keyCode === $.ui.keyCode.TAB
								&& $(this).data("autocomplete").menu.active) {
							event.preventDefault();
						}
					}).autocomplete({
								source : function(request, response) {
									if (isnull(callback)) {
										$.getJSON(url, {
													autoValue : request.term
												}, response);
									} else {
										$.getJSON(url, {
													autoValue : request.term
												}, callback);
									}

								},
								search : function() {
									// custom minLength
									var term = extractLast(this.value);
									if (term.length < 2) {
										return false;
									}
								},
								focus : function() {
									// prevent value inserted on focus
									return false;
								},
								select : function(event, ui) {
									this.value = ui.item.value;
									return false;
								}
							});
		},
		changepost : function(param, callback) {
			$(this).jqGrid("clearGridData");
			if (callback != null && callback != undefined && callback != "") {
				var postData = $(this).jqGrid("getGridParam", "postData");
				// 新POstdata
				$.extend(postData, param);
				$(this).jqGrid("setGridParam", {
							loadComplete : callback
						});
			} else {
				var postData = $(this).jqGrid("getGridParam", "postData");
				// 新POstdata
				$.extend(postData, param);
			}
			$(this).regrid();
		},
		Lazyload : function(url, callback) {
			if (!isnull($(this).attr('tag'))) {
				if (!isnull(callback)) {

					callback();
				}
			} else {
				$(this).load(url, {}, function() {
							$(this).attr('tag', "12");
							if (!isnull(callback)) {
								setTimeout(function() {
											callback(); // 加载页面运行查询列表
										}, 300);

							}
						});
			}
		},
		redgrid : function(url, callback) {
			if (url != "") {
				if (isnull(callback)) {
					url = encodeURI(url);
					$(this).jqGrid("setGridParam", {
								url : url
							});
				} else {
					url = encodeURI(url);

					$(this).jqGrid("setGridParam", {
								url : url,
								loadComplete : callback
							});
				}
			}

			$(this).regrid();
		},
		setgrid : function(url) {
			if (url != "") {
				url = encodeURI(url);
				$(this).jqGrid("setGridParam", {
							url : url
						});
			}
		},
		delgrid : function(url, callback) {
			var $currgrid = $(this); // lizeyuan_20120117_刷新失效——$(this)在ajax中丢失
			var selectedId = $currgrid.jqGrid("getGridParam", "selarrrow");
			if (selectedId == undefined || selectedId == "") {
				showMessage("请选择选项，进行删除！");
				return;
			}
			if (confirm("是否确定删除该记录，一旦删除将无法恢复！请谨慎处理！")) {
				var data = {
					ids : selectedId
				};
				mask();
				$.ajax({
							type : 'POST',
							url : url,
							data : data,
							success : function(data) {
								$currgrid.jqGrid("setGridParam", {
											search : true
										}).trigger("reloadGrid", [{
													page : 1
												}]);
								showMessage(data.message);
								if (callback != null && callback != undefined) {
									callback();
								}
								unmask();
							}
						});
			}
		},
		createtree : function(parentId, parentName, getUrl, dropdownMenuback) {
			var selectTree;
			alert(parentName.attr('id'));
			$("body").bind("mousedown", function(event) {
				if (!(event.target.id == parentName.attr('id') || event.target.id == dropdownMenuback
						.attr('id'))) {
					hideMenu(dropdownMenuback);
				}
			});
			selectTree = $(this).zTree({
						async : true,
						asyncUrl : getUrl,
						callback : {
							// 發送成功
							asyncSuccess : function(event, treeId, treeNode,
									msg) {
								if (treeNode) {
									selectTree.updateNode(treeNode);
									selectTree.selectNode(treeNode.nodes[0]);
								} else {
									showMenu(parentName, dropdownMenuback);
								}
							},
							click : function(event, treeId, treeNode) {
								parentName.val(treeNode.name);
								parentId.val(treeNode.id);
								hideMenu(dropdownMenuback);
							}
						}
					}, []);

		},
		delgridself : function(url, loginOrgid, callback) {// 过滤组织不符合条件的选项
			var $currgrid = $(this); // lizeyuan_20120207_删除本组织
			var selectedIds = $currgrid.jqGrid("getGridParam", "selarrrow");
			if (selectedIds == undefined || selectedIds == "") {
				showMessage("请选择选项，进行删除！");
				return;
			}
			if (loginOrgid == undefined || loginOrgid == "") {
				showMessage("登录数据缺失，请刷新页面再试一次！");
				return;
			}

			var result = []; // 删除列表(传入后台)
			var createOtherOrg = false;
			for (var i = 0; i < selectedIds.length; i++) {
				var rowData = $currgrid.jqGrid("getRowData", selectedIds[i]);
				var rowOrgid = $.trim(rowData.user_org_id); // 创建人组织id
				if(isnull(rowOrgid)){
					rowOrgid=rowData.orgId;
				}
				if (loginOrgid != rowOrgid) {
					createOtherOrg = true;
					continue;
				}
				result.push(selectedIds[i]);
			}
			if (createOtherOrg) {
				alert("不能删除其它组织创建标准！");
			}
			if (result.length <= 0) {
				showMessage("请重新选择选项，再进行删除！");
				return;
			}
			if (confirm("是否确定删除记录，一旦删除将无法恢复！请谨慎处理！")) {
				var data = {
					ids : result
				};
				mask();
				$.ajax({
							type : 'POST',
							url : url,
							data : data,
							success : function(data) {
								$currgrid.jqGrid("setGridParam", {
											search : true
										}).trigger("reloadGrid", [{
													page : 1
												}]);
								showMessage(data.message);
								if (callback != null && callback != undefined) {
									callback();
								}
								unmask();
							}
						});
			}
		},
		delgridrank : function(url, loginOrgid, loginOrgrank, callback) {// (保留)过滤组织不符合条件的选项
			var $currgrid = $(this); // lizeyuan_20120207_
			var selectedIds = $currgrid.jqGrid("getGridParam", "selarrrow");
			if (selectedIds == undefined || selectedIds == "") {
				showMessage("请选择选项，进行删除！");
				return;
			}
			if (loginOrgid == undefined || loginOrgid == "") {
				showMessage("数据缺失，请刷新页面！");
				return;
			}
			if (loginOrgrank == undefined || loginOrgrank == "") {
				showMessage("数据缺失，请刷新页面！");
				return;
			}
			var result = []; // 删除列表(传入后台)
			var createParentOrg = false;
			for (var i = 0; i < selectedIds.length; i++) {
				var rowData = $currgrid.jqGrid("getRowData", selectedIds[i]);
				var rowOrgrank = $.trim(rowData.user_org_rank); // 创建人组织级别rank
				var rowOrgid = $.trim(rowData.user_org_id); // 创建人组织id
				if (loginOrgrank > rowOrgrank) { // 当前用户级别在创建级别下的
					createParentOrg = true;
				}
				if (loginOrgrank <= rowOrgrank) { // 添加符合条件级别
					result.push(selectedIds[i]);
				}
				// if(loginOrgrank==rowOrgrank){//级别相同
				// if(loginOrgid!=rowOrgid){//组织不同过滤
				// selectedIds.remove(selectedIds[i]);
				// }
				// }

			}
			if (createParentOrg) {
				alert("当前选中上级部门创建标准不会删除！");
			}
			if (result.length <= 0) {
				showMessage("请重新选择选项，再进行删除！");
				return;
			}
			if (confirm("是否确定删除该记录，一旦删除将无法恢复！请谨慎处理！")) {
				var data = {
					ids : result
				};
				mask();
				$.ajax({
							type : 'POST',
							url : url,
							data : data,
							success : function(data) {
								$currgrid.jqGrid("setGridParam", {
											search : true
										}).trigger("reloadGrid", [{
													page : 1
												}]);
								showMessage(data.message);
								if (callback != null && callback != undefined) {
									callback();
								}
								unmask();
							}
						});
			}
		}

	});
});
