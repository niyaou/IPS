(function (window) {
    var getMySocket = function ($) {
        return {
            createConnect: function (host, path, onError, onOpen, onMessage, onClose, onBeforeUnload) {
                var webSocket = null;
                var trimPath = path.replace(/^\/*/g,"");
                var socketUrl = "ws://" + host + "/" + trimPath + "?login=" + $.cookie('login');
                //判断当前浏览器是否支持WebSocket
                if ('WebSocket' in window) {
                    webSocket = new WebSocket(socketUrl);
                } else {
                    alert('Not support websocket')
                }
                //连接发生错误的回调方法
                webSocket.onerror = onError || function (ev) {
                    console.log("连接发生错误"+ev.data);
                };
                //连接成功建立的回调方法
                webSocket.onopen = onOpen || function (event) {
                    console.log("连接建立成功");
                };
                //接收到消息的回调方法
                webSocket.onmessage = onMessage || function (ev) {
                    console.log("收到消息:" + ev.data);
                };
                //连接关闭的回调方法
                webSocket.onclose = onClose || function (ev) {
                    console.log("连接关闭"+ev.data);
                };
                //监听窗口关闭事件，当窗口关闭时，主动去关闭websocket连接，防止连接还没断开就关闭窗口，server端会抛异常。
                window.onbeforeunload = function (window, ev) {
                    webSocket.close();
                    if (onBeforeUnload) {
                        onBeforeUnload(window, ev);
                    }
                };
                return webSocket;
            }
        };
    }
    window.MyWebSocket = getMySocket($);
    if (typeof define === "function" && define.amd && define.amd.jQuery) {
        define([], function () {
            return getMySocket(window.$);
        });
    }
})(window);