/**
*获取当前日期
*/
function getCurrentDay(){
	var date=new Date() ;
	var year = date.getFullYear();
	var month = date.getMonth()+1;
	var day = date.getDate();
	if (month < 10) {
		month = "0" + month;
	}
	if (day < 10) {
		day = "0" + day;
	}
	var m = year+"-"+month+"-"+day;
	return m;
}

/**
*获取当前月的第一天
*/
function getCurrentMonthFirst(){
	var date=new Date() ;
	date.setDate(1);
	var year = date.getFullYear();
	var month = date.getMonth()+1;
	var day = date.getDate();
	if (month < 10) {
		month = "0" + month;
	}
	if (day < 10) {
		day = "0" + day;
	}
	var m = year+"-"+month+"-"+day;
	return m;
}

/**
*获取项目路径
*/
function getRootPath_web() {
    var curWwwPath = window.document.location.href;
    var pathName = window.document.location.pathname;
    var pos = curWwwPath.indexOf(pathName);
    var localhostPaht = curWwwPath.substring(0, pos);
    var projectName = pathName.substring(0, pathName.substr(1).indexOf('/') + 1);
    return (localhostPaht + projectName);
}




function xySearch(str){
	switch(str){
		case "param_open":
			$("#param_open").hide();
			$("#param_close").show();
			$("#param_close").parent().parent().next().show();
			break;
		default:
			$("#param_close").hide();
			$("#param_open").show();
			$("#param_open").parent().parent().next().hide();
	}
}


function loading(){
	if($("#loading").length == 0){
		$("body").append('<div class="loading" id="loading"><div><a><i>loading...</i></a></div></div>');
	}
	$("#loading").show();
}

function dealNumber(num,size) {
	var temp = parseFloat(num).toFixed(size);
	var result = parseFloat(temp);
	if (result==0) {
		return "";
	}
	return result;
//	return num;
}

function dealNumber1(num,size) {
	var temp = parseFloat(num).toFixed(size);
	var result = parseFloat(temp);
	if (result==0) {
		return "";
	}
	return result;
}

function dealNumber2(num,size) {
	var temp = parseFloat(num).toFixed(size);
	var result = parseFloat(temp);
	if (result==0) {
		return "";
	}
	if (result > 0 ) {
		return result;
	} else if (result < 0) {
		return result;
	}
}





















