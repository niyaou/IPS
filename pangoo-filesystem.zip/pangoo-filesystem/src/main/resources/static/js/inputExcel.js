$(function(){
    closeBg();
})
//显示灰色的遮罩层
function showBg(){
	var bh = $(window).height();
	var bw = $(window).width();
	var layerW = $(".layer").width();
	var layerH = $(".layer").height();
	var Top = (bh-layerH)/2;
	var left = (bw-layerW)/2;
	/*$(".layer").css({
		top:Top
	});*/
	$("#fullbg").css({
		height:bh,
		width:bw,
		//overflow:"scroll",
		display:"block"
	})
	$(".layer").show();
}
//关闭灰色 jQuery 遮罩 
function closeBg(){
	$("#fullbg,.layer").hide();
}

function importData(){
	loading();
	$("#importFile").submit();
	$("#loading").hide();
}