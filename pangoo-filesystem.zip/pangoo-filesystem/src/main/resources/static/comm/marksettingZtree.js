KCGL = {
	choose:function(callback){
		$.dialog({
			title : "上级标签选择",
			max : false,
			min : false,
			width : '400px',
			height : '380px',
			content : 'url:' + top.TC.config.host + "marksetting/wzflGroup",
			lock : true,
			parent : this,
			button : [ {
				name : "确定",
				callback : function() {
					var api = this;
					var group = this.content.getSelectGroup();
					var jsonLength = 0;
					var jsonstr="";
					if(group != null){
						jsonLength++;
						jsonstr += "{\"id\":"+"\""+group.id+"\",\"igrpName\":"+"\""+group.name+"\"}";
					}
					
					var strarr = "["+jsonstr+"]";
	   				strarr = strarr.replace(",]","]");
					if($.isFunction(callback) && jsonLength > 0){
						callback(strarr);
					}else{
						jsonstr += "{\"id\":"+"\""+""+"\",\"igrpName\":"+"\""+""+"\"},";
						var strarr = "["+jsonstr+"]";
		   				strarr = strarr.replace(",]","]");
						callback(strarr);
					}
					api.close();
					return false;
				},
				focus : true
			}, {
				name : "取消"
			}]
		});	
	}
};






















