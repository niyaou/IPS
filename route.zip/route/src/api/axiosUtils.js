/* eslint-disable no-template-curly-in-string */
import api from './index'
import { axios } from '@/utils/request'
import { JSEncrypt } from 'jsencrypt'
import { dateTime } from '@/utils/util'
/**
 * 获取公钥
 */
export function getPublicKey() {
  return axios({
    url: api.Publickey,
    method: 'get'
  })
}

/**
 * 登录密码加密
 * @param {} psw
 * @param {*} callback
 */
export function encryptPsw (psw, callback) {
  let encryptStr = ''
  axios({
    url: api.Publickey,
    method: 'get'
  }).then(res => {
    const jSEncrypt = new JSEncrypt()
    jSEncrypt.setPublicKey(res.data)
    encryptStr = jSEncrypt.encrypt(dateTime() + psw)
    callback(encryptStr)
  })
}

/**
 * 登录
 * @param {*} parameter
 */
export function login (parameter) {
  return axios({
    url: api.Login,
    method: 'post',
    data: parameter
  })
}

/**
 * 使用ldap系统账号登录
 * @param {*} params
 */
export function loginByLadp (params) {
  return axios({
    url: api.LadpLogin,
    method: 'post',
    params: params
  })
}

export function getSmsCaptcha (parameter) {
  return axios({
    url: api.SendSms,
    method: 'post',
    data: parameter
  })
}

/**
 * 获取用户信息
 * get方法用于获取
 * @param {} username
 */
export function getUserInfo (username) {
  return axios({
    url: api.UserInfo + '?username=' + username,
    method: 'get'
  })
}

/**
 * 获取用户权限列表
 */
export function tokenPerssion (token) {
  return axios({
    url: api.TokenPerssion + '?token=' + token,
    method: 'get'
  })
}

/**
 * 登出
 */
export function logout () {
  return axios({
    url: api.Logout,
    method: 'post',
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

/**
 * 注册用户
 * @param {*} parameter
 * @param {*} callback
 */
export function regiterUser (parameter, callback) {
  axios({
    url: api.Registration,
    method: 'post',
    data: parameter
  }).then(response => {
    const result = response
    callback(result)
  })
}

/**
 * 注册企业用户
 * @param {*} parameter
 * @param {*} callback
 */
export function regiterEnterpriseUser (parameter, callback) {
  axios({
    url: api.RegiterEnterpriseUser,
    method: 'post',
    data: parameter
  }).then(response => {
    const result = response
    callback(result)
  })
}

/**
 * get user 2step code open?
 * @param parameter {*}
 */
export function get2step (parameter) {
  return axios({
    url: api.twoStepCode,
    method: 'post',
    data: parameter
  })
}

/**
 * 更新用户基本信息
 * post方法用于更新
 * @param {*} parameter
 */
export function updateUserInfo (parameter) {
  return axios({
    url: api.UserInfo,
    method: 'post',
    data: parameter
  })
}

/**
 * 修改密码，加密之后传输
 * @param {*} oldPsw
 * @param {*} newPsw
 * @param {*} callback
 */
export function encryptPassword (oldPsw, newPsw, callback) {
  axios({
    url: api.Publickey,
    method: 'get'
  }).then(res => {
    const jSEncrypt = new JSEncrypt()
    jSEncrypt.setPublicKey(res.data)
    const result = { encryptStrOld: jSEncrypt.encrypt(dateTime() + oldPsw), encryptStrNew: jSEncrypt.encrypt(dateTime() + newPsw) }
    callback(result)
  })
}

/**
 * 修改密码
 * @param {*} oldPsw
 * @param {*} newPsw
 * @param {*} callback
 */
export function encryptPasswordUpdate(oldPsw, newPsw, callback) {
  return axios({
    url: api.UpdatePassword,
    method: 'post',
    data: { oldPassword: oldPsw, newPassword: newPsw }
  }).then(encrypt => {
    callback(encrypt, encrypt.code === 200)
  }).catch(error => {
    callback(error, false)
  })
}

/**
 * 添加企业域
 * @param {*} entity
 */
export function createEnterprise(entity) {
  return axios({
    url: api.CreateEnterprise,
    method: 'post',
    data: entity
  })
}

/**
 * 分页浏览企业
 * @param {*} pageNo
 * @param {*} pageSize
 */
export function exploreEnterprise (pageNo, pageSize) {
  return axios({
    url: `${api.ExploreEnterprise}?pageNo=${pageNo}&pageSize=${pageSize}`,
    method: 'get'
  })
}

/**
 * 分页浏览企业成员
 * @param {*} orgId
 * @param {*} isManager
 * @param {*} pageNo
 * @param {*} pageSize
 */
export function exploreEnterpriseUser (orgId, isManager = '', pageNo = '', pageSize = '') {
  return axios({
    url: `${api.ExploreEnterpriseUser}?orgId=${orgId}&isManager=${isManager}&pageNo=${pageNo}&pageSize=${pageSize}`,
    method: 'get'
  })
}

/**
 * 分页浏览企业管理员
 * @param {*} orgId
 * @param {*} isManager
 * @param {*} pageNo
 * @param {*} pageSize
 */
export function exploreEnterpriseManager (pageNo = '', pageSize = '') {
  return axios({
    url: `${api.ExploreEnterpriseManager}?pageNo=${pageNo}&pageSize=${pageSize}`,
    method: 'get'
  })
}

/**
 * 添加企业管理员
 * @param {*} userName
 * @param {*} orgId
 */
export function createEnterpriseManager(userName, orgId) {
  return axios({
    url: api.CreateEnterpriseManager,
    method: 'post',
    params: { userName: userName, orgId: orgId }
  })
}

/**
 * 添加企业成员，用于自主鉴权企业
 * @param {*} userName
 * @param {*} orgId
 */
export function createEnterpriseUser(userName, orgId) {
  return axios({
    url: api.CreateEnterpriseUser,
    method: 'post',
    params: { userName: userName, orgId: orgId }
  })
}

/**
 * 获取当前用户可分配角色列表
 * @param {*} pageNo
 * @param {*} pageSize
 */
export function getUserRoles (pageNo = '1', pageSize = '50') {
  return axios({
    url: `${api.getRoleList}?pageNo=${pageNo}&pageSize=${pageSize}`,
    method: 'get'
  })
}

/**
 * 设置用户角色
 * @param {*} cid
 * @param {*} roles
 */
export function dispatchUserRoles(cid, roles) {
  return axios({
    url: api.SetUserRole,
    method: 'post',
    data: { roleIds: roles, userCid: cid }
  })
}

/**
 * 查询指定用户的角色信息
 * @param {*} cid
 */
export function getUserDispatchedRoles (cid) {
  return axios({
    url: `${api.getDispatchedRoles}?cid=${cid}`,
    method: 'get'
  })
}

/**
 * 获取系统权限列表
 * @param {*} pageNo
 * @param {*} pageSize
 */
export function getTotalPermission (pageNo, pageSize) {
  return axios({
    url: `${api.getTotalPermission}?pageNo=${pageNo}&pageSize=${pageSize}`,
    method: 'get'
  })
}

/**
 * 添加系统权限
 * @param {*} descs
 * @param {*} method
 * @param {*} name
 * @param {*} type
 */
export function addPermission(descs, method, name, type) {
  return axios({
    url: api.AddPermission,
    method: 'post',
    data: { descs: descs, method: method, name: name, type }
  })
}

/**
 * 冻结用户
 * @param {*} cid
 * @param {*} flag true :冻结   false:解冻
 */
export function userFrozen(cid, flag) {
  return axios({
    url: flag ? api.UserFrozen(cid) : api.UserRelease(cid),
    method: 'put'
  })
}

/**
 * 激活用户
 * @param {*} cid
 */
export function userVerified(cid) {
  return axios({
    url: api.UserAuthorized(cid),
    method: 'put'
  })
}


/**
 * 获取三方key列表
 */
export function getKeyList() {
  return axios({
    url: api.getKeyList,
    method: 'get'
  })
}


/**
 * 创建三方key
 * @param {*} item 
 */
export function createKeyCode(item) {
  return axios({
    url: api.createKeyCode,
    method: 'post',
    data:item
  })
}

