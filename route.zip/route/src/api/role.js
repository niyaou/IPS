import api from './index'
import { axios } from '@/utils/request'

export function actionToObject(json) {
  try {
    return JSON.parse(json)
  } catch (e) {
    console.log('err', e.message)
  }
  return []
}

export function addRole(parameter) {
  return axios({
    url: api.AddRole,
    method: 'post',
    data: parameter
  })
}

export function updateRole(parameter) {
  return axios({
    url: api.UpdateRole,
    method: 'post',
    data: parameter
  })
}

export function getRoleList(parameter) {
  return axios({
    url: api.GetRoleList,
    method: 'get',
    params: parameter
  })
}

export function getPermissionList(parameter) {
  return axios({
    url: api.GetPermissionList,
    method: 'get',
    params: parameter
  })
}

export function getRolePermission(parameter) {
  return axios({
    url: api.GetRolePermission,
    method: 'get',
    params: {
      roleId: parameter
    }
  })
}

export function getRolePermissionTree(parameter) {
  return axios({
    url: api.GetRolePermissionTree,
    method: 'get',
    params: {
      roleId: parameter
    }
  })
}

export function deleteRole(parameter) {
  return axios({
    url: api.DeleteRole,
    method: 'delete',
    params: {
      roleId: parameter
    }
  })
}

export function getOrgTree(parameter) {
  return axios({
    url: api.orgTree,
    method: 'get',
    params: parameter
  })
}
