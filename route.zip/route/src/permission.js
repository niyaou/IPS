import router from './router'
import store from './store'

import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style
import notification from 'ant-design-vue/es/notification'
import { setDocumentTitle, domTitle } from '@/utils/domUtil'

import { tokenPerssion } from '@/api/axiosUtils'

NProgress.configure({ showSpinner: false }) // NProgress Configuration

const whiteList = ['login', 'register', 'registerResult'] // no redirect whitelist

router.beforeEach((to, from, next) => {
  console.info(` route from ${from.path} to ${to.path}`)
  NProgress.start() // start progress bar
  to.meta && (typeof to.meta.title !== 'undefined' && setDocumentTitle(`${to.meta.title} - ${domTitle}`))
  // console.info('router.beforeEach-----')
  console.info(store.getters.token)
  if (store.getters.token) {
    // console.info('Vue.ls.get(ACCESS_TOKEN)-----')
    /* has token */
    if (to.path === '/user/login') {
      console.info('dashboard/workplace')
      next({ path: '/dashboard/workplace' })
      NProgress.done()
      // console.info('to.path user/login-----')
    } else {
      console.info(store.getters.roles.length)
      if (store.getters.roles.length === 0) {
        // --------------------
        // 获取用户信息
        const token = store.getters.token
        console.info(store.getters.addRouters)
        tokenPerssion(token).then(res => {

          if (res.code === 200) {
            const permissionList = res.data.permissionList.filter(item => item.type === '2')
            store.commit('SET_ROLES', permissionList)

            const { roles } = store.state.user.roles
            console.info(store.getters.addRouters)
            store.dispatch('GenerateRoutes', { roles }).then(() => {

              // 根据roles权限生成可访问的路由表
              // 动态添加可访问路由表
              router.addRoutes(store.getters.addRouters)
              console.info(store.getters.addRouters)
              console.info(router)
              const redirect = decodeURIComponent(from.query.redirect || to.query)
              if (to.path === redirect) {
                // console.info('(to.path === redirect-----')
                // hack方法 确保addRoutes已完成 ,set the replace: true so the navigation will not leave a history record
                console.info(store.getters.addRouters)
                console.info(to.path)
                next({ ...to, replace: true })
                
               
              } else {
                // 跳转到目的路由
                // console.info(`(to.path === ${redirect}-----`)
                console.info(redirect)
                next({ path: redirect })
               
              }
            })
          }
        }).catch((error) => {
          console.info(error)
          notification.error({
            message: '错误',
            description: '请求用户权限信息失败，请重试'
          })
        })
      } else {
        console.info(store.getters.addRouters)
        router.addRoutes(store.getters.addRouters)
        console.info(route.next)
        next()
        // store.dispatch('GenerateRoutes', { roles }).then(() => {
        //   next()
        // }).catch((error) => {
        //   console.info(error)
        //   notification.error({
        //     message: '错误',
        //     description: '请求用户权限信息失败，请重试'
        //   })
        // })
      }
    }
  } else {
    if (whiteList.includes(to.name)) {
      // 在免登录白名单，直接进入
      console.info(store.getters.addRouters)
      next()
    } else {
      console.info(store.getters.addRouters)
      next({ path: '/user/login', query: { redirect: to.fullPath } })
      NProgress.done() // if current page is login will not trigger afterEach hook, so manually handle it
    }
  }
})

router.afterEach(() => {
  NProgress.done() // finish progress bar
})
