<template>
  <a-card>
    <div class="operate">
      <a-button type="dashed" style="width: 100%" icon="plus" @click="$refs.permissionForm.add()">添加</a-button>
    </div>
    <a-table
      :columns="columns"
      :rowKey="record => record.permissionId"
      :dataSource="data"
      :pagination="pagination"
      :loading="loading"
      @change="handleTableChange"
    >
    <!-- <template slot="name" slot-scope="name">
      {{name.first}} {{name.last}}
    </template> -->
    </a-table>
    <permission-form ref="permissionForm" :initialCounter="pageChaged" />
  </a-card>
</template>

<script>
import permissionForm from '@/views/list/modules/PermissionForm'
import { getTotalPermission } from '@/api/axiosUtils'

const columns = [{
  title: '权限id',
  dataIndex: 'permissionId'
},
{
  title: '权限名称',
  dataIndex: 'name'
},
{
  title: '机构id',
  dataIndex: 'orgId'
},
{
  title: '方法名',
  dataIndex: 'method'
},
{
  title: '描述',
  dataIndex: 'descs'
},
{
  title: '类型',
  dataIndex: 'type'
}]

export default {
  components: {
    permissionForm
  },
  mounted() {
    this.fetch(this.pagination.current, this.pagination.pageSize)
  },
  data() {
    return {
      data: [],
      pagination: { pageSize: 10, total: 1, current: 1 },
      loading: false,
      columns
    }
  },
  methods: {
    pageChaged(index) {
      console.info(index)
    },
    handleTableChange(pagination, filters, sorter) {
      console.info(pagination)
      this.fetch(pagination.current, pagination.pageSize)
    },
    fetch (index, size) {
      this.loading = true
      console.info('fetch')
      getTotalPermission(index, size).then((data) => {
        this.loading = false
        this.data = data.data.content
        this.pagination = { pageSize: size, total: data.data.totalElements }
      })
    }
  }
}
</script>
