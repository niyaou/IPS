<template>
  <div>
    <a-card :bordered="false">
      <a-row>
        <a-col :sm="8" :xs="24" :offset="8">
          <head-info title="企业管理员" :content="totalNum" :bordered="false"/>
        </a-col>

      </a-row>
    </a-card>

    <a-card
      style="margin-top: 24px"
      :bordered="false" >
      <a-row style="margin-bottom:1rem">
        <p>企业管理员 </p>
        <a-tag color="#87d068"> 已分配角色</a-tag>
        <a-tag color="darkgrey">未分配角色</a-tag>
      </a-row>
     

      <a-list
        size="large"
        :grid="{ gutter: 8, column: 8 }"
        :pagination="{ onChange:pageChaged, showQuickJumper: true, pageSize: pageSize, total: parseInt(totalNum)}">
        <a-list-item :key="index" v-for="(item, index) in data">
          <a-popover
            trigger="click"
            v-model="item.visible" >
            <template slot="content">
              <p> <a @click="dispatchRole(item)" v-show="item.userStatus" slot="content">设置角色</a> </p>
            </template>
            <a-tag :color="item.color"> {{ item.loginName }}</a-tag>
          </a-popover>
        </a-list-item>
      </a-list>

      <task-form ref="taskForm" />
    </a-card>
    <a-modal
      :title="title"
      :visible="visible"
      :maskClosable="false"
      @ok="handleOk"
      :confirmLoading="confirmLoading"
      @cancel="handleCancel"
    >
      <a-form layout="vertical" ref="formRegister" :form="form" id="formRegister">

        <a-form-item >
          <a-checkbox-group
            :value="mdl"
            :options="permissions"
            @change="onChange"
          >
            <a-row slot="label" slot-scope="{label}" >{{ label }}
              <!-- <a-col :span="8" v-for="(permission, index) in permissions" :key="index">
                <a-checkbox :value="permission.id">{{ permission.roleName }}</a-checkbox></a-col> -->
            </a-row>
          </a-checkbox-group>
        </a-form-item>
      </a-form>
    </a-modal>



  </div>
</template>

<script>
import HeadInfo from '@/components/tools/HeadInfo'
import TaskForm from '@/views/list/modules/TaskForm'
import { exploreEnterpriseManager, getUserRoles, dispatchUserRoles, getUserDispatchedRoles } from '@/api/axiosUtils'
import store from '@/store'


export default {
  name: 'StandardList',
  components: {
    HeadInfo,
    TaskForm
  },
  data () {
    return {
      permissions: [],
      form: this.$form.createForm(this),
      visible: false,
      memberVisible: false,
      mdl: [],
      confirmLoading: false,
      title: '',
      readyToSubmit: false,
      userName: '',
      orgId: '',
      currentCid: '',
      pageSize: 50,
      totalNum: 1,
      data: []
    }
  },
  methods: {
    addManager() {
      this.title = `添加企业成员`
      this.memberVisible = true
    },
    pageChaged(current) {
      this.refreshEnterprise(current)
    },
    onChange (checkedValues) {
      console.log('checked = ', checkedValues)
      this.mdl = checkedValues
    },
    hide(item) {
      item.visible = false
    },
    refreshEnterprise(index) {
      while (this.data.length > 0) {
        this.data.pop()
      }

      // exploreEnterpriseUser(Vue.ls.get(ORGID), '', index, this.pageSize).then(res => {
      exploreEnterpriseManager(store.getters.orgId, '', index, this.pageSize).then(res => {
        console.info(res)
        this.totalNum = res.data.totalElements.toString()
        for (const one of res.data.content) {
          const enterprise = {}
          enterprise['loginName'] = one.loginName
          enterprise['isManager'] = one.isManager === '1'
          enterprise['cid'] = one.cid
          enterprise['visible'] = false
          enterprise['status'] = one.status === '1' // 冻结状态
          enterprise['userStatus'] = one.userStatus === '1' // 审核状态
          enterprise['roleList'] = one.roleList  // 角色列表

          enterprise['color'] =one.roleList.length>0?'#87d068':'darkgrey' 
          this.data.push(enterprise)
        }
      })
    },
    dispatchRole(item) {
      this.title = `设置${item.loginName}的角色`
      this.visible = true
      this.currentCid = item.cid
      this.hide(item)
    },
    getRoleList() {
      while (this.permissions.length > 0) {
        this.permissions.pop()
      }
      getUserRoles().then(res => {
        console.info(res)
        for (const one of res.data.content) {
          const enterprise = {}
          enterprise['id'] = one.id
          enterprise['roleName'] = one.roleName
          Object.assign(enterprise, { value: one.id, label: one.roleName })
          this.permissions.push(enterprise)
        }
        this.handlerDispatchedRoles(this.currentCid)
      })
    },
    handlerDispatchedRoles(cid) {
      getUserDispatchedRoles(cid).then(res => {
        if(res.code === 200) {
            console.info(res)
            this.mdl = res.data.length === 0 ? [] : res.data.map(role => {
           console.info(role)
          return role.id
        })
        }else{
          this.visible = false
 
          this.$notification['error']({
            message: '获取管理员角色失败',
            description: `失败原因: ${res.msg}`,
            duration: 8
          })
        }
      })
    },
        handleOk(e) {
      this.confirmLoading = true
      e.preventDefault()
      dispatchUserRoles(this.currentCid, this.mdl).then(res => {
        console.info(res)
        this.confirmLoading = false
        this.visible = false
        if (res.code === 200) {
          this.refreshEnterprise(1)
          this.$notification['success']({
            message: '成员角色设置成功',
            description: res.msg,
            duration: 8
          })
        } else {
          this.$notification['error']({
            message: '成员角色设置失败',
            description: `失败原因： ${res.msg}`,
            duration: 8
          })
        }
      })
    },
    handleCancel(e) {
      this.visible = false
      this.memberVisible = false
    },

    handlePasswordCheck (rule, value, callback) {
      if (value === undefined || value === '') {
        callback(new Error('不能为空'))
        this.readyToSubmit = false
      } else {
        this.userName = value
        this.readyToSubmit = true
        callback()
      }
    }
  },
  watch: {
    visible: {
      handler(newp, oldp) {
        this.readyToSubmit = false
        this.userName = ''
        this.orgId = ''
        this.form.resetFields()
        console.info(newp)
        if (newp) {
          this.getRoleList()
        }
      }
    }
  },
  mounted() {
    this.refreshEnterprise(1)
  }
}
</script>

<style lang="less" scoped>
    .ant-avatar-lg {
        width: 48px;
        height: 48px;
        line-height: 48px;
    }

    .list-content-item {
        color: rgba(0, 0, 0, .45);
        display: inline-block;
        vertical-align: middle;
        font-size: 14px;
        margin-left: 40px;
        span {
            float:right;
            line-height: 20px;
        }
        p {
            text-align: center;
            margin-top: 4px;
            margin-bottom: 0;
            line-height: 22px;
        }
    }
</style>
