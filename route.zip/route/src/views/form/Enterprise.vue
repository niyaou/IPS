<template>
  <a-card :body-style="{padding: '24px 32px'}" :bordered="false">
    <a-form @submit="handleSubmit" :form="form">
      <a-form-item
        label="企业名称"
        :labelCol="{lg: {span: 7}, sm: {span: 7}}"
        :wrapperCol="{lg: {span: 10}, sm: {span: 17} }">
        <a-input
          v-decorator="[
            'name',
            {rules: [{ required: true, message: '企业名称' }]}
          ]"
          name="name"
          placeholder="给目标起个名字" />
      </a-form-item>
      <a-form-item
        label="鉴权模式"
        :labelCol="{lg: {span: 7}, sm: {span: 7}}"
        :wrapperCol="{lg: {span: 10}, sm: {span: 17} }"
        :required="true">
        <a-select
          defaultValue="false"
          v-decorator="[
            'authType', ]">
          <a-select-option value="true">企业自主鉴权</a-select-option>
          <a-select-option value="false">平台鉴权</a-select-option>
        </a-select>
      </a-form-item>
      <a-form-item
        label="企业鉴权地址"
        :labelCol="{lg: {span: 7}, sm: {span: 7}}"
        :wrapperCol="{lg: {span: 10}, sm: {span: 17} }">
        <a-input
          placeholder="请输入企业鉴权地址"
          v-decorator="[
            'url',
            {rules: [{ required: true, message: '请输入企业鉴权地址' }]}
          ]" />
      </a-form-item>
      <a-form-item
        label="接口访问方式"
        :labelCol="{lg: {span: 7}, sm: {span: 7}}"
        :wrapperCol="{lg: {span: 10}, sm: {span: 17} }"
        :required="true">
        <a-select
          defaultValue="post"
          v-decorator="[
            'type', ]" >
          <a-select-option value="post">POST</a-select-option>
          <a-select-option value="get">GET</a-select-option>
        </a-select>
      </a-form-item>
      <a-form-item
        label="企业鉴权授权码"
        :labelCol="{lg: {span: 7}, sm: {span: 7}}"
        :wrapperCol="{lg: {span: 10}, sm: {span: 17} }">
        <a-input

          placeholder="请输入企业鉴权授权码"
          v-decorator="[
            'keyCode',
            {rules: [{ required: true, message: '请输入企业鉴权授权码' }]}
          ]" />
      </a-form-item>

      <a-form-item
        label="企业ID"
        :labelCol="{lg: {span: 7}, sm: {span: 7}}"
        :wrapperCol="{lg: {span: 10}, sm: {span: 17} }">
        <a-input
          placeholder="请为你的企业分配ID"
          v-decorator="[ 'id',
                         {rules: [{ required: true, message: '请为你的企业分配ID' }]}
          ]" />
      </a-form-item>

      <a-form-item
        :labelCol="{lg: {span: 7}, sm: {span: 7}}"
        :wrapperCol="{lg: {span: 10}, sm: {span: 17} }"
        label="添加鉴权参数">

        <a-input-search placeholder="请在此添加鉴权参数" @search="addParams" v-model="temParams" size="large">
          <!-- <a-button  type="primary"  icon="plus">添加</a-button> -->
          <a-button slot="enterButton" type="primary" @click="addParams" icon="plus" v-if="temParams">Params</a-button>
        </a-input-search>
      </a-form-item>

      <a-form-item
        :labelCol="{lg: {span: 7}, sm: {span: 7}}"
        :wrapperCol="{lg: {span: 10}, sm: {span: 17} }"
        label="选择鉴权参数">
        <a-select
          mode="multiple"
          label="企业ID"
          defaultValue=""
          v-decorator="[
            'params',
            {rules: [{ required: true, message: '请为你的企业分配ID' }]}
          ]">
          <a-select-option v-for="(item ,index ) in params" :key="index" :value="item">{{ item }}</a-select-option>
        </a-select>
      </a-form-item>

      <a-form-item
        :wrapperCol="{ span: 24 }"
        style="text-align: center"
      >
        <a-button htmlType="submit" type="primary" @click.stop.prevent="handleSubmit" >提交</a-button>
        <a-button style="margin-left: 8px">保存</a-button>
      </a-form-item>
    </a-form>
  </a-card>
</template>

<script>
import { createEnterprise } from '@/api/axiosUtils'
export default {
  name: 'BaseForm',
  data () {
    return {
      description: '用于向平台添加企业域，最终生成该企业域ID,域内员工使用该ID参与企业管理运营。',
      value: 1,
      temParams: '',
      params: [''],
      // form
      form: this.$form.createForm(this)

    }
  },
  methods: {
    addParams() {
      console.info(this.params)
      this.params.push(this.temParams)
      this.temParams = ''
      console.info(this.params)
    },
    // handler
    handleSubmit (e) {
      e.preventDefault()
      this.form.validateFields((err, values) => {
        if (!err) {
          console.log('Received values of form: ', values)
          const entity = {
            'auth': values.authType,
            'authParams': {
              'sercet_key': values.keyCode
            },
            'authType': values.type,
            'authUrl': values.url,
            'name': values.name,
            'orgId': values.id,
            'remark': 'values'
          }
          createEnterprise(entity).then(res => {
            if (res.code === 200) {
              this.$notification.success({
                message: '创建成功',
                description: `创建企业域成功，企业域ID：${values.id}！`
              })
            } else {
              this.$notification.error({
                message: '创建失败',
                description: res.msg
              })
            }
            console.info(res)
          })
        }
      })
    }
  }
}
</script>
