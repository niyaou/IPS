<template>
  <div>
    <a-card :bordered="false">
      <a-row>
        <a-col :sm="8" :xs="24" :offset="8">
          <head-info title="企业数" :content="totalNum" :bordered="false"/>
        </a-col>

      </a-row>
    </a-card>

    <a-card
      style="margin-top: 24px"
      :bordered="false"
      title="企业列表">

      <div class="operate">
        <a-button type="dashed" style="width: 100%" icon="plus" @click="newMember" :disabled="newKey.disabled">添加</a-button>
      </div>

      <a-list size="large" :pagination="{ onChange:pageChaged, showQuickJumper: true, pageSize: pageSize, total: parseInt(totalNum)}">
        <a-list-item :key="index" v-for="(item, index) in data">

          <template v-if="item.editable">

            <a-row style="width:100%" :gutter="32" type="flex" justify="space-between" align="middle" >

              <a-col :span="3"> <a-input
                @change=" e => handleChange(e.target.value,'name')"
                placeholder="请填写KEY名称"
              /></a-col>
              <a-col :span="2">
                <a-input-number
                  :min="0"
                  placeholder="授权总次数"
                  @change=" e => handleChange(e,'accessCount')"
                /></a-col>

              <a-col :span="3"> <a-input-number
                :min="0"
                placeholder="每日授权次数"
                @change=" e => handleChange(e,'accessCountDay')"
              /></a-col>
              <a-col :span="4">
                <a-date-picker
                  @change="onDataChange"
                />
              </a-col>
              <a-col :span="6">
                <a-tree-select
                  style="width:100%"
                  :treeData="treeData"
                  :value="checkValue"
                  @change="onChange"
                  treeCheckable
                  :showCheckedStrategy="SHOW_PARENT"
                  placeholder="请选择权限"
                />
              </a-col>
              <a-col :span="2">
                <a @click="addNew">添加</a>
                <a-divider type="vertical" />
                <a @click="removeNew">删除</a>
              </a-col>
            </a-row></template>

          <template v-else>
            <a-list-item-meta :description="item.key" >
              <a-avatar slot="avatar" size="large" shape="square" :src="item.avatar"/>
              <a slot="title" >{{ item.title }}</a>
            </a-list-item-meta>
            <a-list-item>
              <a-list
                size="large"
                :grid="{ gutter: 8, column: 2 }">
                <a-list-item :key="indexs" v-for="(permission, indexs) in item.permissionlist">
                  <a-tag color="blue"> {{ permission.name }}</a-tag>
                </a-list-item>
              </a-list>
            </a-list-item>
          </template>
        </a-list-item>

      </a-list>

    </a-card>

  </div>
</template>

<script>
import HeadInfo from '@/components/tools/HeadInfo'
import { getRolePermissionTree } from '@/api/role'
import { getKeyList, createKeyCode } from '@/api/axiosUtils'
import { TreeSelect } from 'ant-design-vue'
const SHOW_PARENT = TreeSelect.SHOW_PARENT

const colors = [ '/companyrego.png', '/companyregp.png', '/companyregg.png', '/companyreg.png' ]

export default {
  name: 'StandardList',
  components: {
    HeadInfo
  },
  data () {
    return {
      form: this.$form.createForm(this),
      visible: false,
      confirmLoading: false,
      title: '',
      readyToSubmit: false,
      userName: '',
      orgId: '',
      pageSize: 5,
      totalNum: 1,
      treeData: [],
      data: [],
      permissions: [],
      checkValue: [],
      newKey: {
        name: '',
        accessCount: 0,
        accessCountDay: 0,
        expireTime: '',
        permissionList: '',
        disabled: false
      },
      SHOW_PARENT
    }
  },
  methods: {
    removeNew() {
      this.data.shift()
      while (this.checkValue.length > 0) {
        this.checkValue.pop()
      }
      this.newKey['disabled'] = false
    },
    addNew() {
      const newKey = (({ name, accessCount, accessCountDay, expireTime, permissionList }) => ({ name, accessCount, accessCountDay, expireTime, permissionList }))(this.newKey)
      createKeyCode(newKey).then(res => {
        console.info(res)
        this.removeNew()
        if (res.code === 200) {
          this.refreshEnterprise(1)
          this.$notification['success']({
            message: '添加三方KEY成功',
            description: res.msg,
            duration: 8
          })
        } else {
          this.$notification['error']({
            message: '添加三方KEY失败',
            description: `失败原因： ${res.msg}`,
            duration: 8
          })
        }
      }).catch(err => {
        console.info(err)
        this.removeNew()
        this.$notification['error']({
          message: '添加三方KEY失败',
          description: `失败原因： ${err}`,
          duration: 8
        })
      })
    },
    handleChange(value, target) {
      this.newKey[target] = value
    },
    onDataChange(date, dateString) {
      this.handleChange(dateString, 'expireTime')
    },
    onChange (checkedValues) {
      this.checkValue = checkedValues
      this.handleChange(checkedValues, 'permissionList')
    },
    getRoleList() {
      while (this.permissions.length > 0) {
        this.permissions.pop()
      }
      getRolePermissionTree().then(res => {
        this.treeData = res.data
      })
    },
    pageChaged(current) {
      this.refreshEnterprise(current)
    },
    refreshEnterprise(index) {
      while (this.data.length > 0) {
        this.data.pop()
      }
      getKeyList(index, this.pageSize).then(res => {
        this.totalNum = res.data.totalElements.toString()
        for (const one of res.data.content) {
          const index = Math.floor(colors.length * Math.random())
          const color = colors[index]
          const enterprise = {}
          enterprise['permissionlist'] = one.permissionlist
          enterprise['title'] = one.name
          enterprise['key'] = one.key
          enterprise['avatar'] = color
          enterprise['editable'] = false
          this.data.push(enterprise)
        }
      })
    },
    newMember () {
      const length = this.data.length
      this.data.push({
        key: length === 0 ? '1' : (parseInt(this.data[length - 1].key) + 1).toString(),
        title: '',
        permissionlist: '',
        avatar: colors[0],
        editable: true,
        isNew: true
      })
      this.newKey['disabled'] = true
      this.data.reverse()
    }
  },
  watch: {
    visible: {
      handler(oldp, newp) {
        this.readyToSubmit = false
        this.userName = ''
        this.orgId = ''
        this.form.resetFields()
      }
    }
  },
  mounted() {
    this.refreshEnterprise(1)
    this.getRoleList()
  }
}
</script>

<style lang="less" scoped>
    .ant-avatar-lg {
        width: 48px;
        height: 48px;
        line-height: 48px;
    }

    .list-content-item {
        color: rgba(0, 0, 0, .45);
        display: inline-block;
        vertical-align: middle;
        font-size: 14px;
        margin-left: 40px;
        span {
            float:right;
            line-height: 20px;
        }
        p {
            text-align: center;
            margin-top: 4px;
            margin-bottom: 0;
            line-height: 22px;
        }
    }
</style>
