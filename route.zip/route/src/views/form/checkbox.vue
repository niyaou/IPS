<template>
 
  <div class="main">
      <a-form layout="vertical" ref="formRegister" :form="form"  id="formRegister">

        <a-form-item >
          <a-checkbox-group  :value="mdl" :options="permissions" @change="onChange">
             <!-- <span style="color: red" slot="label" slot-scope="{label}">{{label}}</span> -->
             <a-row slot="label" slot-scope="{label}" >{{label}} 
               <!-- <a-col :span="8" v-for="(permission, index) in permissions" :key="index">
                <a-checkbox :value="permission.id" slot="roleName" slot-scope="{roleName}"  >{{ roleName }}</a-checkbox></a-col>  -->
             </a-row>  
          </a-checkbox-group>
        </a-form-item>
      </a-form>
 <div>
        <a-checkbox-group :options="optionsWithDisabled"  :value="mdl"  @change="onChange">
      <span style="color: red" slot="label" slot-scope="{label}">{{label}}</span>
    </a-checkbox-group>
 </div>
  </div>
</template>

<script>
import Vue from 'vue'
import store from '@/store'
import pick from 'lodash.pick'
const optionsWithDisabled = [
  {  label: 'Apple',value: 1 },
  { label: 'Pear', value: 2 },
  { label: 'Orange', value: 3, disabled: false },
]

const permissions= [{id:1,roleName:'1x'},{id:2,roleName:'2x'},{id:3,roleName:'3x'},{id:4,roleName:'4x'}]

export default {
  name: 'StandardList',
  components: {
  },
  data () {
    return {
      optionsWithDisabled,
      permissions: [],
      form: this.$form.createForm(this),
      visible: false,
      mdl:[],
      confirmLoading: false,
      title: '',
      readyToSubmit: false,
      userName: '',
      orgId: '',
      currentCid: '',
      data: []
    }
  },
  methods: {
     onChange (checkedValues) {
      console.log('checked = ', checkedValues)
      this.mdl=checkedValues
    },
    hide(item) {
      item.visible = false
    },
    refreshEnterprise(index) {
 
    },
    dispatchRole(item) {
      this.title = `设置${item.loginName}的角色`
      this.visible = true
      this.currentCid = item.cid
      this.hide(item)
    },
    getRoleList() {
      // while (this.permissions.length > 0) {
      //   this.permissions.pop()
      // }
      // getUserRoles().then(res => {
      //   console.info(res)
      //   for (const one of res.data.content) {
      //     const enterprise = {}
      //     enterprise['id'] = one.id
      //     enterprise['roleName'] = one.roleName
      //     this.permissions.push(enterprise)
      //   }
      // })
    },
    handlerDispatchedRoles(){
      //       this.mdl = Object.assign({}, record)
      // // 有权限表，处理勾选
      // if (this.mdl.permissions && this.permissions) {
      //   // 先处理要勾选的权限结构
      //   const permissionsAction = {}
      //   this.mdl.permissions.forEach(permission => {
      //     permissionsAction[permission.permissionId] = permission.actionEntitySet.map(entity => entity.action)
      //   })

      //   console.log('permissionsAction', permissionsAction)
      //   // 把权限表遍历一遍，设定要勾选的权限 action
      //   this.permissions.forEach(permission => {
      //     const selected = permissionsAction[permission.id]
      //     permission.selected = selected || []
      //     this.onChangeCheck(permission)
      //   })


    
      
    


        
          this.permissions = permissions.map(entity =>{
              let option={}
              console.info(entity)
               Object.assign(entity,{
                 value:entity.id,
                  label:entity.roleName
               })
              return entity
          } )
          this.mdl=[1,2,3]
        
       






     
    },
    handleOk(e) {
    },
    handleCancel(e) {
      this.visible = false
    },
  },
  watch: {
    visible: {
      handler(newp, oldp) {
      }
    }
  },
  mounted() {
   this.handlerDispatchedRoles()
  }
}
</script>

<style lang="less" scoped>
    .ant-avatar-lg {
        width: 48px;
        height: 48px;
        line-height: 48px;
    }

    .list-content-item {
        color: rgba(0, 0, 0, .45);
        display: inline-block;
        vertical-align: middle;
        font-size: 14px;
        margin-left: 40px;
        span {
            float:right;
            line-height: 20px;
        }
        p {
            text-align: center;
            margin-top: 4px;
            margin-bottom: 0;
            line-height: 22px;
        }
    }
</style>
