<template>
  <div>
    <a-card :bordered="false">
      <a-row>
        <a-col :sm="8" :xs="24" :offset="8">
          <head-info title="企业数" :content="totalNum" :bordered="false"/>
        </a-col>

      </a-row>
    </a-card>

    <a-card
      style="margin-top: 24px"
      :bordered="false"
      title="企业列表">

      <div class="operate">
        <a-button type="dashed" style="width: 100%" icon="plus" @click="$refs.taskForm.add()">添加</a-button>
      </div>

      <a-list size="large" :pagination="{ onChange:pageChaged, showQuickJumper: true, pageSize: pageSize, total: totalNum}">
        <a-list-item :key="index" v-for="(item, index) in data">
          <a-list-item-meta :description="item.orgId">
            <a-avatar slot="avatar" size="large" shape="square" :src="item.avatar"/>
            <a slot="title">{{ item.title }}</a>
          </a-list-item-meta>
          <div slot="actions">
            <a @click="addManager(item)">添加管理员</a>
          </div>
          <!-- <div slot="actions">
            <a-dropdown>
              <a-menu slot="overlay">
                <a-menu-item><a>编辑</a></a-menu-item>
                <a-menu-item><a>删除</a></a-menu-item>
              </a-menu>
              <a>更多<a-icon type="down"/></a>
            </a-dropdown>
          </div> -->
          <div class="list-content">
            <div class="list-content-item">
              <span>Owner</span>
              <p>{{ item.owner }}</p>
            </div>
            <div class="list-content-item">
              <span>更新时间</span>
              <p>{{ item.startAt }}</p>
            </div>
            <div class="list-content-item">
              {{ item.progress.value }} &nbsp;成员
            </div>

          </div>
        </a-list-item>
      </a-list>

      <task-form ref="taskForm" />
    </a-card>
    <a-modal
      :title="title"
      :visible="visible"
      :maskClosable="false"
      @ok="handleOk"
      :confirmLoading="confirmLoading"
      @cancel="handleCancel"
      :okButtonProps="{ props: { disabled: !readyToSubmit} }"
    >
      <a-form layout="vertical" ref="formRegister" :form="form" id="formRegister">

        <a-form-item>

          <a-input
            size="large"
            type="text"
            autocomplete="false"
            placeholder="请输入管理员账号"
            v-decorator="['userName', {rules: [{ required: true, message: '请输入管理员账号'}, { validator: this.handlePasswordCheck } ], validateTrigger: ['change', 'blur'] }]"
          >
          </a-input>
        </a-form-item>

        <a-form-item>
          <a-input
            size="large"
            type="text"
            autocomplete="false"
            placeholder="请输入管理员所属企业ID"
            v-decorator="['orgId', {rules: [{ required: true, message: '请输入管理员所属企业ID'}, { validator: this.handlePasswordCheck } ], validateTrigger: ['change', 'blur']}]"

          ></a-input>
        </a-form-item>
        <a-form-item>

        </a-form-item>
      </a-form>
    </a-modal>
  </div>
</template>

<script>
import HeadInfo from '@/components/tools/HeadInfo'
import TaskForm from '@/views/list/modules/TaskForm'
import { exploreEnterprise, exploreEnterpriseUser, createEnterpriseManager } from '@/api/axiosUtils'

const colors = [ '/companyrego.png', '/companyregp.png', '/companyregg.png', '/companyreg.png' ]

export default {
  name: 'StandardList',
  components: {
    HeadInfo,
    TaskForm
  },
  data () {
    return {
      form: this.$form.createForm(this),
      visible: false,
      confirmLoading: false,
      title: '',
      readyToSubmit: false,
      userName: '',
      orgId: '',
      pageSize: 5,
      totalNum: 1,
      data: []
    }
  },
  methods: {
    pageChaged(current) {
      this.refreshEnterprise(current)
    },
    refreshEnterprise(index) {
      while (this.data.length > 0) {
        this.data.pop()
      }
      exploreEnterprise(index, this.pageSize).then(res => {
        console.info(res)
        this.totalNum = res.data.totalElements
        for (const one of res.data.content) {
          const index = Math.floor(colors.length * Math.random())
          const color = colors[index]
          const enterprise = {}
          enterprise['orgId'] = one.orgId
          enterprise['title'] = one.name
          enterprise['owner'] = '-'
          enterprise['description'] = one.remark
          enterprise['startAt'] = one.createTime === null ? null : one.createTime.substr(0, 10)
          enterprise['progress'] = {
            value: 0
          }
          enterprise['avatar'] = color

          this.data.push(enterprise)
          exploreEnterpriseUser(one.orgId).then(res => {
            enterprise['progress']['value'] = res.data.totalElements
          })
          exploreEnterpriseUser(one.orgId, 1).then(res => {
            if (res.data.totalElements > 0) {
              for (const org of this.data) {
                if (org['orgId'] === one.orgId) {
                  org['owner'] = res.data.content[0]['loginName']
                }
              }
            }
          })
        }
      })
    },
    addManager(item) {
      this.title = `为${item.title}添加管理员`
      this.visible = true
    },
    handleOk(e) {
      this.confirmLoading = true
      createEnterpriseManager(this.userName, this.orgId).then(res => {
        console.info(res)
        this.confirmLoading = false
        this.visible = false
        if (res.code === 200) {
          this.refreshEnterprise(1)
          this.$notification['success']({
            message: '添加管理员成功',
            description: res.msg,
            duration: 8
          })
        } else {
          this.$notification['error']({
            message: '添加管理员失败',
            description: `失败原因： ${res.msg}`,
            duration: 8
          })
        }
      })
    },
    handleCancel(e) {
      this.visible = false
    },

    handlePasswordCheck (rule, value, callback) {
      if (rule['field'] === 'userName') {
        this.userName = value
      } else if (rule['field'] === 'orgId') {
        this.orgId = value
      }

      if (value === undefined || value === '') {
        callback(new Error('不能为空'))
        this.readyToSubmit = false
      } else {
        this.readyToSubmit = (this.userName !== '' && this.orgId !== '')
        callback()
      }
    }
  },
  watch: {
    visible: {
      handler(oldp, newp) {
        this.readyToSubmit = false
        this.userName = ''
        this.orgId = ''
        this.form.resetFields()
      }
    }
  },
  mounted() {
    this.refreshEnterprise(1)
  }
}
</script>

<style lang="less" scoped>
    .ant-avatar-lg {
        width: 48px;
        height: 48px;
        line-height: 48px;
    }

    .list-content-item {
        color: rgba(0, 0, 0, .45);
        display: inline-block;
        vertical-align: middle;
        font-size: 14px;
        margin-left: 40px;
        span {
            float:right;
            line-height: 20px;
        }
        p {
            text-align: center;
            margin-top: 4px;
            margin-bottom: 0;
            line-height: 22px;
        }
    }
</style>
