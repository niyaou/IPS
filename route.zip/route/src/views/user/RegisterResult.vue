<template>
  <result :isSuccess="result.isSuccess" :title="result.title" :description="result.description">
    <template slot="action">
      <a-button size="large" type="primary" @click="goRegisterHandle" v-if="!result.isSuccess">修改信息</a-button>
      <a-button size="large" style="margin-left: 8px" @click="goHomeHandle">返回首页</a-button>
    </template>
  </result>
</template>

<script>
import { Result } from '@/components'

export default {
  name: 'RegisterResult',
  components: {
    Result
  },
  data() {
    return {
      description: '',
      result: {
        isSuccess: Boolean,
        title: String,
        description: String
      },
      form: {}
    }
  },
  computed: {
    email() {
      const v = (this.form && this.form.email) || 'xxx'
      const title = [`你的账户：${v} 注册成功`, '账户注册失败']
      return this.result.isSuccess ? title[0] : title[1]
    }
  },
  beforeCreate() {
    console.info('beforeCreate')
  },
  created() {
    console.info('created')
  },
  beforeMount() {
    console.info('beforeMount')
  },
  beforeUpdate() {
    console.info('beforeUpdate')
  },
  updated() {
    console.info('updated')
  },
  activated() {
    console.info('activated')
    this.form = this.$route.params
    const successed = this.form.code === 200
    const msg = this.form.msg
    const v = (this.form && this.form.email) || 'niyaou@xxx.com'
    const title = [`你的账户：${v} 注册成功`, '账户注册失败']
    const comments = [
      '激活邮件已发送到你的邮箱中，邮件有效期为24小时。请及时登录邮箱，点击邮件中的链接激活帐户。',
      `账号注册失败，${msg},请根据提示修改注册信息重试`
    ]
    this.result = {
      isSuccess: successed,
      title: successed ? title[0] : title[1],
      description: successed ? comments[0] : comments[1]
    }
  },
  methods: {
    goHomeHandle() {
      this.$router.push({ name: 'login' })
    },
    goRegisterHandle() {
      this.$router.push({ name: 'register' })
    }
  }
}
</script>

<style scoped>
</style>
