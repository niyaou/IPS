<template>
  <a-card :bordered="false" :style="{ height: '100%' }">
    <a-row :gutter="24">
      <!-- <a-col :md="4">
        <a-list itemLayout="vertical" :dataSource="roles">
          <a-list-item slot="renderItem" slot-scope="item, index" :key="index">
            <a-list-item-meta :style="{ marginBottom: '0' }">
              <span slot="description" style="text-align: center; display: block">{{ item.describe }}</span>
              <a slot="title" style="text-align: center; display: block" @click="edit(item)">{{ item.name }}</a>
            </a-list-item-meta>
          </a-list-item>
        </a-list>
      </a-col>-->
      <a-col :md="4"></a-col>
      <a-col :md="20">
        <div style="max-width: 800px">
          <a-divider v-if="isMobile()" />
          <div v-if="mdl.id">
            <h3>角色：{{ mdl.name }}</h3>
          </div>
          <a-form
            :form="form"
            @submit="handleSubmit"
            :layout="isMobile() ? 'vertical' : 'horizontal'"
          >
            <a-form-item label="角色id" hidden>
              <a-input
                type="hidden"
                read-only="read-only"
                v-decorator="[ 'roleId', {rules: [{ required: true, message: '请填写角色id!' }]} ]"
                placeholder="请填写角色id"
              />
            </a-form-item>
            <a-form-item label="角色名称">
              <a-input
                read-only="read-only"
                v-decorator="[ 'roleName', {rules: [{ required: true, message: '请填写角色名称!' }]} ]"
                placeholder="请填写角色名称"
              />
            </a-form-item>
            <a-form-item label="备注说明">
              <a-textarea
                :row="3"
                v-decorator="[ 'remark', {rules: [{ required: true, message: '请填写备注说明!' }]} ]"
                placeholder="请填写备注说明"
              />
            </a-form-item>
            <!-- <a-form-item label="选择权限">
              <a-checkbox-group @change="onChange" v-decorator="[ 'permissionList', {rules: []} ]">
                <a-row>
                  <a-col :span="8" v-for="(permission, index) in permissions" :key="index">
                    <a-checkbox
                      :value="permission.permissionId"
                      :defaultChecked="permission.checked"
                    >{{ permission.name }}</a-checkbox>
                  </a-col>
                </a-row>
              </a-checkbox-group>
            </a-form-item>-->
            <a-form-item label="选择权限">
              <!-- <a-checkbox-group @change="onChange" v-decorator="[ 'permissionList', {rules: []} ]"> -->
              <a-row>
                <a-col>
                  <a-tree-select
                    style="width: 600px"
                    :treeData="treeData"
                    :value="checkValue"
                    @change="onChange"
                    treeCheckable
                    :showCheckedStrategy="SHOW_PARENT"
                    searchPlaceholder="Please select"
                  />
                  <a-checkbox-group
                    :options="options"
                    :defaultValue="valuelist"
                    @change="onChange"
                    v-decorator="[ 'permissionList', {rules: []} ]"
                  />
                </a-col>
              </a-row>
              <!-- </a-checkbox-group> -->
            </a-form-item>
            <a-form-item>
              <a-button size="large" type="primary" htmlType="submit" class="addRole-button">确定</a-button>
            </a-form-item>
          </a-form>
        </div>
      </a-col>
    </a-row>
  </a-card>
</template>

<script>
import { updateRole, getRolePermissionTree, getRolePermission } from '@/api/role'
import { mixinDevice } from '@/utils/mixin'
import { TreeSelect } from 'ant-design-vue'
import pick from 'lodash.pick'

const SHOW_PARENT = TreeSelect.SHOW_PARENT

export default {
  name: 'RoleAdd',
  mixins: [mixinDevice],
  components: {},
  data() {
    return {
      checkValue: [],
      treeData: [],
      SHOW_PARENT,
      roleId: this.$route.query.id,
      roleName: this.$route.query.roleName,
      remark: this.$route.query.remark,
      form: this.$form.createForm(this),
      mdl: {},
      roles: [],
      options: [],
      values: [],
      permissions: [],
      allPermissions: [],
      rolePermissions: [],
      lists: [
        '注册接口',
        'token认证接口',
        '用户基础信息接口',
        '用户角色管理',
        '管理企业用户',
        '企业管理',
        '企业用户注册入口',
        '新迭代接口',
        'PANGOO一期功能'
      ],
      valuelist: []
    }
  },
  created: function() {
    this.loadPermissions()
    this.loadRolePermission(this.roleId)
    this.initData()
  },

  methods: {
    handleSubmit(e) {
      e.preventDefault()
      const {
        form: { validateFields }
      } = this
      validateFields({ force: true }, (err, values) => {
        if (!err) {
          Object.assign(values, { permissionList: this.checkValue })
          console.log(values)
          updateRole(values)
            .then(res => this.updateSuccess(res))
            .catch(err => this.requestFailed(err))
            .finally(() => {})
        }
      })
    },
    updateSuccess(res) {
      if (res.code === 200) {
        this.$router.push({ name: 'RoleList' })
        setTimeout(() => {
          this.$notification.success({
            message: '提示',
            description: `修改成功！`
          })
        }, 1000)
      } else {
        this.$notification.error({
          message: '提示',
          description: res.msg
        })
      }
    },
    requestFailed(err) {
      this.$notification['error']({
        message: '错误',
        description: ((err.response || {}).data || {}).message || '请求出现错误，请稍后再试',
        duration: 4
      })
    },
    callback(val) {
      console.log(val)
    },

    add() {
      this.edit({ id: 0 })
    },

    edit(record) {
      this.mdl = Object.assign({}, record)
      // 有权限表，处理勾选
      if (this.mdl.permissions && this.permissions) {
        // 先处理要勾选的权限结构
        const permissionsAction = {}
        this.mdl.permissions.forEach(permission => {
          permissionsAction[permission.permissionId] = permission.actionEntitySet.map(entity => entity.action)
        })

        console.log('permissionsAction', permissionsAction)
        // 把权限表遍历一遍，设定要勾选的权限 action
        this.permissions.forEach(permission => {
          const selected = permissionsAction[permission.id]
          permission.selected = selected || []
          this.onChangeCheck(permission)
        })

        console.log('this.permissions', this.permissions)
      }

      this.$nextTick(() => {
        this.form.setFieldsValue(pick(this.mdl, 'id', 'name', 'status', 'describe'))
      })
      console.log('this.mdl', this.mdl)
    },
    onChange (value) {
      console.log('onChange ', value)
      this.checkValue = value
    },
    onChangeCheck(permission) {
      permission.indeterminate =
        !!permission.selected.length && permission.selected.length < permission.actionsOptions.length
      permission.checkedAll = permission.selected.length === permission.actionsOptions.length
    },
    onChangeCheckAll(e, permission) {
      console.log('permission:', permission)
      Object.assign(permission, {
        selected: e.target.checked ? permission.actionsOptions.map(obj => obj.value) : [],
        indeterminate: false,
        checkedAll: e.target.checked
      })
    },
    loadPermissions() {
      getRolePermissionTree().then(res => {
        console.info(res)
        this.treeData = res.data
        // result.forEach(function(v) {
        //   var perobj = {
        //     label: v.name,
        //     value: v.permissionId
        //   }
        //   myoption.push(perobj)
        // })
        // this.options = myoption

        // this.permissions = result.map(permission => {
        //   const options = actionToObject(permission)
        //   permission.checkedAll = false
        //   permission.selected = []
        //   permission.indeterminate = false
        //   permission.actionsOptions = options.map(option => {
        //     return {
        //       label: option.name,
        //       value: option.permissionId
        //     }
        //   })
        //   return permission
        // })
      })
    },
    loadRolePermission(roleId) {
      getRolePermission(roleId).then(res => {
        console.info(res)
        const roleResult = res.data
        let myvalues = []
        // this.rolePermissions = roleResult
        // roleResult.forEach(function(t) {
        //   myvalues.push(t.permissionId)
        // })
        myvalues = roleResult.map(item => {
          return item.permissionId
        })
        console.info(myvalues)
        this.checkValue = myvalues
      })
    },
    initData() {
      this.$nextTick(() => {
        this.form.setFieldsValue({
          roleId: this.roleId,
          roleName: this.roleName,
          remark: this.remark
          // permissionList: this.permissions.checked
        })
      })
    }
  }
}
</script>

<style scoped>
</style>
