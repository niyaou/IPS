<template>
  <a-card :bordered="false">
    <div class="table-page-search-wrapper">
      <a-form layout="inline">
        <a-row :gutter="48" style="margin-left:20px;">
          <a-col :md="8" :sm="24">
            <a-form-item label="角色名称">
              <a-input v-model="queryParam.roleName" placeholder="请输入" />
            </a-form-item>
          </a-col>
          <a-col :md="8" :sm="24">
            <span class="table-page-search-submitButtons">
              <a-button type="primary" @click="$refs.table.refresh(true)">查询</a-button>
              <a-button style="margin-left: 8px" @click="() => queryParam = {}">重置</a-button>
            </span>
          </a-col>
        </a-row>
      </a-form>
    </div>

    <s-table
      ref="table"
      size="default"
      :columns="columns"
      :data="loadData"
      :rowKey="(record) => record.id"
    >
      <!-- <div slot="expandedRowRender" slot-scope="record" style="margin: 0">
        <a-row :gutter="24" :style="{ marginBottom: '12px' }">
          <a-col
            :span="12"
            v-for="(role, index) in record.permissions"
            :key="index"
            :style="{ marginBottom: '12px' }"
          >
            <a-col :span="4">
              <span>{{ role.permissionName }}：</span>
            </a-col>
            <a-col :span="20" v-if="role.actionEntitySet.length > 0">
              <a-tag
                color="cyan"
                v-for="(action, k) in role.actionEntitySet"
                :key="k"
              >{{ action.describe }}</a-tag>
            </a-col>
            <a-col :span="20" v-else>-</a-col>
          </a-col>
        </a-row>
      </div>-->
      <span slot="action" slot-scope="text, record">
        <router-link
          :to="{ name: 'editRole',query: {id: record.id, roleName: record.roleName, remark: record.remark} }"
        >编辑</router-link>
        <!-- <a @click="edit(record.id)">编辑</a> -->
        <a-divider type="vertical" />
        <a @click="deletes(record.id)">删除</a>
        <a-divider type="vertical" />
        <!-- <a-dropdown>
          <a class="ant-dropdown-link">
            更多 <a-icon type="down" />
          </a>
          <a-menu slot="overlay">
            <a-menu-item>
              <a href="javascript:;">详情</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;">禁用</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;">删除</a>
            </a-menu-item>
          </a-menu>
        </a-dropdown>-->
      </span>
    </s-table>

    <!-- <role-modal ref="modal" @ok="handleOk"></role-modal> -->
  </a-card>
</template>

<script>
import { STable } from '@/components'
import { deleteRole } from '@/api/role'
// import RoleModal from '../other/modules/RoleModal'

export default {
  name: 'TableList',
  components: {
    STable
    // RoleModal
  },
  data() {
    return {
      description: '',

      visible: false,

      form: null,
      mdl: {},

      // 高级搜索 展开/关闭
      advanced: false,
      // 查询参数
      queryParam: {},
      // 表头
      columns: [
        {
          title: '角色ID',
          dataIndex: 'id'
        },
        {
          title: '角色名称',
          dataIndex: 'roleName'
        },
        {
          title: '机构ID',
          dataIndex: 'orgId'
        },
        {
          title: '创建者',
          dataIndex: 'createId'
        },
        {
          title: '创建时间',
          dataIndex: 'createDate'
        },
        {
          title: '更新时间',
          dataIndex: 'updateDate'
          // sorter: true
        },
        {
          title: '角色描述',
          dataIndex: 'remark'
        },
        {
          title: '操作',
          width: '150px',
          dataIndex: 'action',
          scopedSlots: { customRender: 'action' }
        }
      ],
      // 加载数据方法 必须为 Promise 对象
      loadData: parameter => {
        return this.$http
          .get('/pangoo-usersystem/orgRole/getRoleList', {
            params: Object.assign(parameter, this.queryParam)
          })
          .then(res => {
            return res.data
          })
      },
      selectedRowKeys: [],
      selectedRows: []
    }
  },
  methods: {
    getData(parameter) {
      return this.$http
        .get('/pangoo-usersystem/orgRole/getRoleList', {
          params: Object.assign(parameter, this.queryParam)
        })
        .then(res => {
          return res.data
        })
    },
    handleEdit(record) {
      this.mdl = Object.assign({}, record)

      this.mdl.permissions.forEach(permission => {
        permission.actionsOptions = permission.actionEntitySet.map(action => {
          return { label: action.describe, value: action.action, defaultCheck: action.defaultCheck }
        })
      })

      console.log(this.mdl)
      this.visible = true
    },
    handleOk() {
      // 新增/修改 成功时，重载列表
      this.$refs.table.refresh()
    },
    onChange(selectedRowKeys, selectedRows) {
      this.selectedRowKeys = selectedRowKeys
      this.selectedRows = selectedRows
    },
    toggleAdvanced() {
      this.advanced = !this.advanced
    },
    edit(id) {
      this.$notification.success({
        message: '提示',
        description: `编辑成功！` + id
      })
    },
    deletes(id) {
      const that = this
      that.$confirm({
        title: '提示',
        content: '真的要删除该角色吗 ?',
        onOk() {
          return deleteRole(id)
            .then(res => that.deleteSuccess(res))
            .catch(err => that.requestFailed(err))
            .finally(() => {})
        },
        onCancel() {
          console.log('Cancel')
        }
      })

      // deleteRole(id)
      //   .then(res => this.deleteSuccess(res))
      //   .catch(err => this.requestFailed(err))
      //   .finally(() => {})
      // this.$notification.success({
      //   message: '提示',
      //   description: `删除成功！` + id
      // })
    },
    deleteSuccess(res) {
      if (res.code === 200) {
        console.log('kaishishancl ')
        this.$refs.table.refresh()
        // 延迟 1 秒显示提示信息
        setTimeout(() => {
          this.$notification.success({
            message: '提示',
            description: `删除成功！`
          })
        }, 1000)
        // this.$router.push({ name: 'RoleList' })
        // this.loadData()
      } else {
        this.$notification.success({
          message: '提示',
          description: res.msg
        })
      }
    },
    requestFailed(err) {
      this.$notification['error']({
        message: '错误',
        description: ((err.response || {}).data || {}).message || '请求出现错误，请稍后再试',
        duration: 4
      })
    }
  },
  watch: {
    /*
      'selectedRows': function (selectedRows) {
        this.needTotalList = this.needTotalList.map(item => {
          return {
            ...item,
            total: selectedRows.reduce( (sum, val) => {
              return sum + val[item.dataIndex]
            }, 0)
          }
        })
      }
      */
  }
}
</script>
