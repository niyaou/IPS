<template>
  <div >
    <a-list
      itemLayout="horizontal"
      :dataSource="data.options"
    >
      <a-list-item slot="renderItem" slot-scope="item, index" :key="index">
        <a-list-item-meta>
          <a slot="title">{{ item.title }}</a>
          <span slot="description">
            <span class="security-list-description">{{ item.description }}</span>
            <span v-if="item.value"> : </span>
            <span class="security-list-value">{{ item.value }}</span>
          </span>
        </a-list-item-meta>
        <template v-if="item.actions">
          <a slot="actions" @click="item.actions.callback">{{ item.actions.title }}</a>
        </template>

      </a-list-item>
    </a-list>
    <a-modal
      title="修改密码"
      :visible="password.visible"
      @ok="handleOk"
      :confirmLoading="password.confirmLoading"
      @cancel="handleCancel"
      :maskClosable="false"
      :okButtonProps="{ props: { disabled: ! password.readyToSubmit} }"
    >

      <a-form layout="vertical" ref="formRegister" :form="form" id="formRegister">

        <!-- <a-popover
        placement="rightTop"
        :trigger="['focus']"
        :getPopupContainer="(trigger) => trigger.parentElement"
        v-model="state.passwordLevelChecked"      > -->
        <!-- <template slot="content">
          <div :style="{ width: '240px' }">
            <div :class="['user-register', passwordLevelClass]">
              强度：
              <span>{{ passwordLevelName }}</span>
            </div>
            <a-progress
              :percent="state.percent"
              :showInfo="false"
              :strokeColor=" passwordLevelColor "
            />
            <div style="margin-top: 10px;">
              <span>请至少输入 6 个字符。请不要使用容易被猜到的密码。</span>
            </div>
          </div>
        </template> -->

        <a-form-item>
          <a-input
            size="large"
            type="password"
            @click="handlePasswordInputClick"
            autocomplete="false"
            v-model="password.oldPassword"
            placeholder="请输入原始密码"
            v-decorator="['origin', {rules: [{ required: true, message: '请输入原始密码'}, ]}]"
          ></a-input>
        </a-form-item>

        <a-form-item>
          <a-input
            size="large"
            type="password"
            autocomplete="false"
            v-model="password.newPassword"
            placeholder="请输入新密码，至少7位密码，区分大小写"
            v-decorator="['password', {rules: [{ required: true, message: '至少7位密码，区分大小写'}, { validator: this.handlePasswordLevel }], validateTrigger: ['change', 'blur']}]"

          ></a-input>
        </a-form-item>
        <!-- </a-popover> -->

        <a-form-item>
          <a-input
            size="large"
            type="password"
            autocomplete="false"
            v-model="password.repeatPassword"
            v-decorator="['password2', {rules: [{ required: true, message: '至少6位密码，区分大小写' }, { validator: this.handlePasswordCheck }], validateTrigger: ['change', 'blur']}]"
            placeholder="确认新密码"
          ></a-input>
        </a-form-item>
      </a-form>

    </a-modal>
  </div>
</template>

<script>

import { encryptPassword, encryptPasswordUpdate } from '@/api/axiosUtils'

export default {
  data () {
    return {
      form: this.$form.createForm(this),
      state: {
        time: 60,
        smsSendBtn: false,
        passwordLevel: 0,
        passwordLevelChecked: false,
        percent: 10,
        progressColor: '#FF0000',
        isCached: false
      },
      data: {
        options: [
          { title: '账户密码', description: '', value: '', actions: { title: '修改', callback: this.updatePassWord } },
          { title: '密保手机', description: '已绑定手机', value: '138****8293', actions: { title: '修改', callback: () => { this.$message.success('This is a message of success') } } },
          { title: '密保问题', description: '未设置密保问题，密保问题可有效保护账户安全', value: '', actions: { title: '设置', callback: () => { this.$message.error('This is a message of error') } } },
          { title: '备用邮箱', description: '已绑定邮箱', value: 'ant***sign.com', actions: { title: '修改', callback: () => { this.$message.warning('This is message of warning') } } },
          { title: 'MFA 设备', description: '未绑定 MFA 设备，绑定后，可以进行二次确认', value: '', actions: { title: '绑定', callback: () => { this.$message.info('This is a normal message') } } }
        ]
      },
      password: {
        ModalText: 'Content of the modal',
        visible: false,
        oldPassword: '',
        newPassword: '',
        repeatPassword: '',
        confirmLoading: false,
        readyToSubmit: false
      }
    }
  },
  watch: {
    'password.visible': {
      handler(oldp, newp) {
        this.form.resetFields()
      },
      deep: true,
      immediate: true
    }
  },
  methods: {
    handlePasswordInputClick () {
      this.state.passwordLevelChecked = false
    },
    handlePasswordLevel (rule, value, callback) {
      let level = 0

      // 判断这个字符串中有没有数字
      if (/[0-9]/.test(value)) {
        level++
      }
      // 判断字符串中有没有字母
      if (/[a-zA-Z]/.test(value)) {
        level++
      }
      // 判断字符串中有没有特殊符号
      if (/[^0-9a-zA-Z_]/.test(value)) {
        level++
      }
      this.state.passwordLevel = level
      this.state.percent = level * 30
      if (level >= 2) {
        if (level >= 3) {
          this.state.percent = 100
        }
        this.state.passwordLevelChecked = true
        callback()
      } else {
        if (level === 0) {
          this.state.percent = 10
        }
        this.state.passwordLevelChecked = false
        callback(new Error('密码强度不够'))
      }
    },

    handlePasswordCheck (rule, value, callback) {
      const password = this.form.getFieldValue('password')
      if (value === undefined) {
        callback(new Error('请输入密码'))
        this.password.readyToSubmit = false
        return
      }
      if (value && password && value.trim() !== password.trim()) {
        callback(new Error('两次密码不一致'))
        this.password.readyToSubmit = false
        return
      }
      this.password.readyToSubmit = true && this.state.passwordLevelChecked
      callback()
    },
    updatePassWord() {
      // this.$message.info('This is a normal message')
      this.password.visible = true
    },
    handleOk(e) {
      this.password.ModalText = 'The modal will be closed after two seconds'
      this.password.confirmLoading = true
      encryptPassword(this.password.oldPassword, this.password.newPassword, res => {
        encryptPasswordUpdate(res.encryptStrOld, res.encryptStrNew, (res, isSuccess) => {
          if (isSuccess) {
            this.$notification['success']({
              message: '密码更改成功',
              description: res.msg,
              duration: 8
            })
          } else {
            this.$notification['error']({
              message: '密码更改失败',
              description: `失败原因： ${res.msg}`,
              duration: 8
            })
          }
          this.password.visible = false
          this.password.confirmLoading = false
        })
      })
    },
    handleCancel(e) {
      this.password.visible = false
    }

  }
}
</script>

<style scoped>

</style>
