<template>
  <a-modal
    :width="640"
    :visible="visible"
    title="权限添加"
    @ok="handleSubmit"
    @cancel="visible = false"
    :maskClosable="false"
    :okButtonProps="{ props: { disabled: this.hasErrors(form.getFieldsError())} }"
  >
    <a-form @submit="handleSubmit" :form="form">
      <a-form-item label="权限名称" :labelCol="labelCol" :wrapperCol="wrapperCol">
        <a-input
          v-decorator="['name',{rules:[{required: true, message: '请添加权限名称'}], validateTrigger: ['change', 'blur']}]"
        ></a-input>
      </a-form-item>

      <a-form-item label="方法名" :labelCol="labelCol" :wrapperCol="wrapperCol">
        <a-input
          v-decorator="['method',{rules:[{required: true, message: '请添加方法名'}], validateTrigger: ['change', 'blur']}]"
        ></a-input>
      </a-form-item>

      <a-form-item label="描述" :labelCol="labelCol" :wrapperCol="wrapperCol">
        <a-input
          v-decorator="['descs',{rules:[{required: true, message: '请添加描述'}], validateTrigger: ['change', 'blur']}]"
        ></a-input>
      </a-form-item>

      <a-form-item label="类型" :labelCol="labelCol" :wrapperCol="wrapperCol">
        <a-select
          v-decorator="['type', {rules:[{required: true, message: '请选择类型'}], validateTrigger: ['change', 'blur']}]"
        >
          <a-select-option :value="1">接口权限</a-select-option>
          <a-select-option :value="2">页面权限</a-select-option>
        </a-select>
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script>
import { addPermission } from '@/api/axiosUtils'

function hasErrors(fieldsError) {
  return Object.keys(fieldsError).some(field => fieldsError[field])
}

export default {
  name: 'PermissionForm',

  props: { initialCounter: { type: Function, default: () => {} } },
  data () {
    return {
      successCall: this.initialCounter,
      hasErrors,
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 13 }
      },

      visible: false,
      form: this.$form.createForm(this)
    }
  },
  watch: {
    visible: {
      handler(oldp, newp) {
        this.form.resetFields()
      }
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.form.validateFields()
    })
  },
  methods: {
    formChange(e) {
      console.info(e)
    },
    add() {
      this.visible = true
    },
    edit(record) {
      const {
        form: { setFieldsValue }
      } = this
      this.visible = true
      this.$nextTick(() => {
        setFieldsValue({ taskName: 'test' })
      })
    },
    handleSubmit() {
      const {
        form: { validateFields }
      } = this
      this.visible = true
      validateFields((errors, values) => {
        if (!errors) {
          console.log('values', values)
          addPermission(values.descs, values.method, values.name, values.type).then(res => {
            console.info(res)
            if (res.code === 200) {
              this.initialCounter('success')
              this.$notification['success']({
                message: '添加系统权限成功',
                description: res.msg,
                duration: 8
              })
            } else {
              this.initialCounter('error')
              this.$notification['error']({
                message: '添加系统权限失败',
                description: `失败原因： ${res.msg}`,
                duration: 8
              })
            }
          })
          this.visible = false
        }
      })
    }
  }
}
</script>
