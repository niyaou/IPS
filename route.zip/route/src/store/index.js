import Vue from 'vue'
import Vuex from 'vuex'

import app from './modules/app'
import user from './modules/user'
import permission from './modules/permission'
import getters from './getters'
import createPersistedState from 'vuex-persistedstate'

Vue.use(Vuex)

export default new Vuex.Store({

  modules: {
    app,
    user,
    permission
  },
  state: {

  },
  mutations: {

  },
  actions: {

  },
  getters
  ,
  plugins: [createPersistedState({
    storage: window.sessionStorage,
    reducer: (val) => {
      return {
        user: val.user,
        app:val.app,
        permission:val.permission
      }
    }
  }
  )]
})
