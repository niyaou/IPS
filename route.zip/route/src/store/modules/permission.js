import { constantRouterMap, asyncDesayRouterMap } from '@/config/router.config'

/**
 * 过滤账户是否拥有某一个权限，并将菜单从加载列表移除
 *
 * @param permissions
 * @param route
 * @returns {boolean}
 */
function hasPermission(permissions, route) {
  // if (route.meta && route.meta.permission) {
  //   for (let i = 0, len = permissions.length; i < len; i++) {
  //     if (route.meta.permission.includes(permissions[i].method)) {
  //       return true
  //     }
  //   }
  //   return false
  // }
  return true
}

/**
 * 动态过滤权限
 * @param routerMap
 * @param permissions
 */
function filterAsyncRouter(routerMap, permissions) {
  const accessedRouters = routerMap.filter(route => {
    if (hasPermission(permissions, route)) {
      if (route.children && route.children.length) {
        route.children = filterAsyncRouter(route.children, permissions)
      }
      return true
    }
    return false
  })
  // console.info(accessedRouters)
  return accessedRouters
}

const permission = {
  state: {
    routers: constantRouterMap,
    addRouters: []
  },
  mutations: {
    SET_ROUTERS: (state, routers) => {
      state.addRouters = routers
      state.routers = constantRouterMap.concat(routers)
    }
  },
  actions: {
    GenerateRoutes({ commit }, data) {
      return new Promise(resolve => {
        const { roles } = data
        const accessedRouters = filterAsyncRouter(asyncDesayRouterMap, roles)
        commit('SET_ROUTERS', accessedRouters)
        resolve()
      })
    }
  }
}

export default permission
