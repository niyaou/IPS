import Vue from 'vue'
import { getPublicKey, login, loginByLadp, logout, tokenPerssion } from '@/api/axiosUtils'
import { ACCESS_TOKEN, ORGID } from '@/store/mutation-types'
import { dateTime, welcome } from '@/utils/util'
import { JSEncrypt } from 'jsencrypt'
const user = {
  state: {
    token: '',
    userName: '',
    nickName: '',
    welcome: '',
    avatar: '',
    orgId: '',
    roles: [],
    info: {}
  },

  mutations: {
    SET_TOKEN: (state, token) => {
      state.token = token
    },
    SET_NICKNAME: (state, { nickName, welcome }) => {
      state.nickName = nickName
      state.welcome = welcome
    },
    SET_USERNAME: (state, userName) => {
      state.userName = userName
    },
    SET_AVATAR: (state, avatar) => {
      state.avatar = avatar
    },
    SET_ROLES: (state, roles) => {
      state.roles = roles
    },
    SET_INFO: (state, info) => {
      state.info = info
    },
    SET_ORGID: (state, orgId) => {
      state.orgId = orgId
    }
  },

  actions: {
    // 登录
    // Login({ commit }, loginParams) {
    //   return new Promise((resolve, reject) => {
    //     getPublicKey().then(res => {
    //       loginParams.clientId = 'VUE201907030001'
    //       const jSEncrypt = new JSEncrypt()
    //       jSEncrypt.setPublicKey(res.data)
    //       // 获取公钥对密码进行加密：本地系统时间yyyyMMddHHmmss+明文密码
    //       if (loginParams.customActiveKey === 'tab1') {
    //         loginParams.password = jSEncrypt.encrypt(dateTime() + loginParams.password)
    //         loginParams.userName = loginParams.username
    //         if (loginParams.userName.includes('\\')) {
    //           const userinfo = loginParams.userName.split('\\')
    //           loginParams.org = userinfo[0]
    //           loginParams.userName = userinfo[1]
    //         }
    //         login(loginParams).then(response => {
    //           if (response.code === 200) {
    //             const result = response.data
    //             const userStatus = result.userStatus
    //             const status = result.status

    //             if (userStatus && status) {
    //               // Vue.ls.set(ACCESS_TOKEN, result.token, 30 * 60 * 1000)
    //               console.info(result.token)
    //               commit('SET_TOKEN', result.token)
    //               commit('SET_INFO', result)
    //               commit('SET_NICKNAME', { nickName: 'result.nickName', welcome: welcome() })
    //               commit('SET_USERNAME', result.login)
    //               commit('SET_AVATAR', result.avatar)
    //               commit('SET_ORGID', result.orgId)
    //               console.info('   login success   ')
    //               console.info(this.state.token)
    //               console.info(store.getter.token)
    //               // Vue.ls.set(ORGID, result.orgId, 30 * 60 * 1000)
    //             }
    //           }
    //           resolve(response)
    //         }).catch(error => {
    //           console.info(error)
    //           reject(error)
    //         })
    //       } else if (loginParams.customActiveKey === 'tab3') {
    //         loginParams.password = jSEncrypt.encrypt(dateTime() + loginParams.uidpassword)
    //         loginParams.username = loginParams.uid
    //         if (loginParams.username.includes('\\')) {
    //           const userinfo = loginParams.username.split('\\')
    //           loginParams.org = userinfo[0]
    //           loginParams.username = userinfo[1]
    //         }
    //         loginByLadp(loginParams).then(response => {
    //           if (response.code === 200) {
    //             const result = response.data
    //             const userStatus = result.userStatus
    //             const status = result.status
    //             if (userStatus && status) {
    //               // Vue.ls.set(ACCESS_TOKEN, result.token, 30 * 60 * 1000)
    //               commit('SET_TOKEN', result.token)
    //               commit('SET_INFO', result)
    //               commit('SET_NICKNAME', { nickName: result.nickName, welcome: welcome() })
    //               commit('SET_USERNAME', result.login)
    //               commit('SET_AVATAR', result.avatar)
    //               commit('SET_ORGID', result.orgId)
    //               // Vue.ls.set(ORGID, result.orgId, 30 * 60 * 1000)
    //             }
    //           }
    //           resolve(response)
    //         }).catch(err => {
    //           console.info(err)
    //           reject(err)
    //         })
    //       }
    //     })
    //   })
    // },

    // 获取用户信息
    GetInfo({ commit }) {
      console.info('=====GetInfo')
      return new Promise((resolve, reject) => {
        // const token = Vue.ls.get(ACCESS_TOKEN)
        console.info($store.state)
        const token = $store.user.token
        console.info(token)
        tokenPerssion(token).then(res => {
          console.info(res)
          if (res.code === 200) {
            const permissionList = res.data.permissionList.filter(item => item.type === '2')
            console.info(permissionList)
            commit('SET_ROLES', permissionList)
            console.info(permissionList)
            resolve(res)
          } else {
            reject(error)
          }
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 登出
    Logout({ commit, state }) {
      return new Promise((resolve) => {
        commit('SET_TOKEN', '')
        commit('SET_ROLES', [])
        // Vue.ls.remove(ACCESS_TOKEN)
        logout(state.token).then(() => {
          resolve()
        }).catch(() => {
          resolve()
        })
      })
    }

  }
}

export default user
